"""Observe local agent session metadata without changing or restarting agents.

Session files are read-only. Content capture is bounded and redacted; metadata-only
mode omits task text, arguments, and results. Agent log formats vary by version.
"""
from __future__ import annotations

import hashlib
import heapq
import json
import math
import os
import platform
import socket
import threading
import time
import tomllib
from datetime import datetime
from pathlib import Path

from .agent_hierarchy import canonical_agent_id, provenance
from .core import normalize_native
from .local_activity import mcp_attributes, mcp_failed, plaintext
from .local_state import RecentMap
from .native_json import loads

MAX_READ = 8 * 1024 * 1024
MAX_LINE = 2 * 1024 * 1024
MAX_SOURCES = 50
MAX_TASK_PREFIX_BYTES = 512 * 1024
MAX_TASK_PREFIX_RECORDS = 256
MAX_CONFIG_BYTES = 1024 * 1024
MAX_RECENT_TURNS = 64
MAX_RECENT_CALLS = 512
MAX_RECENT_USAGE = 256
CLAUDE_USAGE_FIELDS = ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens")


def identity(*parts, size=32):
    return hashlib.sha256("\0".join(map(str, parts)).encode()).hexdigest()[:size]


def timestamp(value):
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            return 0
        magnitude = abs(value)
        factor = 1 if magnitude >= 1e17 else 1000 if magnitude >= 1e14 else 1_000_000 if magnitude >= 1e11 else 1_000_000_000
        stamp = max(0, int(value * factor))
        return stamp if stamp <= 2**63 - 1 else 0
    if isinstance(value, str):
        try:
            stamp = max(0, int(datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp() * 1e9))
            return stamp if stamp <= 2**63 - 1 else 0
        except (ValueError, OverflowError, OSError):
            pass
    return 0


def count(value):
    try:
        return max(0, int(value or 0))
    except (ValueError, TypeError, OverflowError):
        return 0


def _server_names(data, field):
    """Return configured MCP server names without exposing their settings."""
    servers = data.get(field) if isinstance(data, dict) else None
    # OpenCode v1 places names directly under `mcp`; v2 nests them in
    # `mcp.servers`. Accept both so the inventory follows the user's config.
    if field == "mcp" and isinstance(servers, dict) and isinstance(servers.get("servers"), dict):
        servers = servers["servers"]
    if not isinstance(servers, dict):
        return []
    return [str(name).strip()[:128] for name, value in servers.items()
            if isinstance(name, str) and name.strip() and isinstance(value, dict)][:500]


def _decode_json_or_jsonc(raw, jsonc=False):
    """Parse JSONC without stripping comment markers inside quoted strings."""
    text = raw.decode("utf-8")
    if jsonc:
        output = []
        index = 0
        quoted = escaped = False
        while index < len(text):
            char = text[index]
            following = text[index + 1] if index + 1 < len(text) else ""
            if quoted:
                output.append(char)
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
                index += 1
                continue
            if char == '"':
                quoted = True
                output.append(char)
                index += 1
            elif char == "/" and following == "/":
                index += 2
                while index < len(text) and text[index] not in "\r\n":
                    index += 1
            elif char == "/" and following == "*":
                end = text.find("*/", index + 2)
                if end < 0:
                    raise ValueError("unterminated JSONC comment")
                output.extend(" " for item in text[index:end + 2] if item in "\r\n")
                index = end + 2
            else:
                output.append(char)
                index += 1
        text = "".join(output)
        # OpenCode's JSONC examples permit trailing commas.
        output = []
        index = 0
        quoted = escaped = False
        while index < len(text):
            char = text[index]
            if quoted:
                output.append(char)
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
            elif char == '"':
                quoted = True
                output.append(char)
            elif char == ",":
                lookahead = index + 1
                while lookahead < len(text) and text[lookahead].isspace():
                    lookahead += 1
                if lookahead == len(text) or text[lookahead] not in "]}":
                    output.append(char)
            else:
                output.append(char)
            index += 1
        text = "".join(output)
    return json.loads(text)


def discover_mcp_configurations(global_paths=None, project_directories=(), on_error=None):
    """Read known client config files and return names only, never server values."""
    home = Path.home()
    paths = list(global_paths) if global_paths is not None else [
        (Path(os.environ.get("CODEX_HOME", home / ".codex")) / "config.toml", "Codex", "User"),
        (home / ".claude.json", "Claude Code", "User"),
        (Path(os.environ.get("CURSOR_CONFIG_DIR", home / ".cursor")) / "mcp.json", "Cursor", "User"),
        (Path(os.environ.get("GEMINI_CLI_HOME", home / ".gemini")) / "settings.json", "Gemini CLI", "User"),
        (Path(os.environ.get("GEMINI_CLI_SYSTEM_SETTINGS_PATH", "/etc/gemini-cli/settings.json")),
         "Gemini CLI", "System"),
        (Path(os.environ.get("COPILOT_HOME", home / ".copilot")) / "mcp-config.json",
         "GitHub Copilot CLI", "User"),
    ]
    if global_paths is None:
        config_file = os.environ.get("OPENCODE_CONFIG")
        xdg_config_home = Path(os.environ.get("XDG_CONFIG_HOME") or home / ".config")
        config_dir = Path(os.environ.get("OPENCODE_CONFIG_DIR") or (xdg_config_home / "opencode"))
        if config_file:
            paths.append((Path(config_file), "OpenCode", "User"))
        else:
            paths.extend((config_dir / filename, "OpenCode", "User")
                         for filename in ("opencode.json", "opencode.jsonc"))
    candidates = [(Path(path), client, scope) for path, client, scope in paths]
    for directory in project_directories:
        if not directory:
            continue
        root = Path(directory)
        candidates.extend([
            (root / ".mcp.json", "Claude Code", "Project"),
            (root / ".cursor" / "mcp.json", "Cursor", "Project"),
            (root / ".vscode" / "mcp.json", "VS Code", "Project"),
            (root / ".gemini" / "settings.json", "Gemini CLI", "Project"),
            (root / "opencode.json", "OpenCode", "Project"),
            (root / "opencode.jsonc", "OpenCode", "Project"),
            (root / ".opencode" / "opencode.json", "OpenCode", "Project"),
            (root / ".opencode" / "opencode.jsonc", "OpenCode", "Project"),
        ])

    found, seen = [], set()
    for path, client, scope in candidates:
        try:
            if not path.is_file():
                continue
            if path.stat().st_size > MAX_CONFIG_BYTES:
                if on_error:
                    on_error()
                continue
            raw = path.read_bytes()
            if path.suffix.lower() == ".toml":
                data = tomllib.loads(raw.decode("utf-8"))
                field = "mcp_servers"
            else:
                data = _decode_json_or_jsonc(raw, path.suffix.lower() == ".jsonc")
                field = ("servers" if client == "VS Code" else
                         "mcp" if client == "OpenCode" else "mcpServers")
            for name in _server_names(data, field):
                key = (client, scope, name)
                if key in seen:
                    continue
                seen.add(key)
                found.append({"client": client, "scope": scope, "server": name,
                              "config": path.name})
        except (OSError, UnicodeError, ValueError, tomllib.TOMLDecodeError):
            if on_error:
                on_error()
            continue
    return sorted(found, key=lambda item: (item["client"].casefold(), item["scope"], item["server"].casefold()))


class Session:
    def __init__(self, store, path, runtime, capture_details=True):
        self.store, self.path, self.runtime = store, Path(path), runtime
        self.service = runtime.lower().replace(" ", "-")
        self.source_id = identity(runtime, self.path.resolve())
        self.capture_details = capture_details
        self.internal = False
        self.session_id = self.path.stem
        # Hierarchy identity is deliberately separate from the file source ID.
        # A child discovered through a spawn result and later through its own
        # transcript resolves to this same canonical node.
        self.agent_namespace = {"Codex": "codex-rollout", "Claude Code": "claude-code-projects",
                                "Pi": "pi-sessions"}.get(runtime, runtime.casefold())
        self.native_session_id = self.session_id
        self.native_worker_id = None
        self.native_root_session_id = None
        self.claude_agent_id = None
        self.claude_parent_session_id = None
        self.claude_meta = {}
        self.agent_id = canonical_agent_id(runtime, self.agent_namespace, self.session_id)
        self.parent_agent_id = None
        self.relationship_kind = "unknown"
        self.relationship_state = "unresolved"
        self.relationship_provenance = provenance(runtime, "session path; no parent metadata")
        self.discovery_state = "observed"
        self.announced_agents = RecentMap(MAX_RECENT_CALLS)
        self.spawn_calls = RecentMap(MAX_RECENT_CALLS)
        if runtime == "Claude Code":
            agent_id, parent_session, metadata = _claude_subagent_identity(self.path)
            if agent_id:
                self.claude_agent_id = agent_id
                self.claude_parent_session_id = parent_session
                self.claude_meta = metadata
                self.session_id = agent_id
                self.native_session_id = parent_session or agent_id
                self.native_worker_id = agent_id
                self.agent_id = canonical_agent_id(runtime, self.agent_namespace, agent_id)
                parent_agent = _safe_identifier(metadata.get("parentAgentId"))
                if parent_agent:
                    parent_id = canonical_agent_id(runtime, self.agent_namespace, parent_agent)
                    reference = "subagents/agent-" + agent_id[:80] + ".meta.json parentAgentId"
                elif parent_session:
                    parent_id = canonical_agent_id(runtime, self.agent_namespace, parent_session)
                    reference = "subagents transcript path parent session"
                else:
                    parent_id = None
                    reference = "subagent transcript without a parent session directory"
                self.parent_agent_id = parent_id
                self.relationship_kind = "delegated"
                self.relationship_state = "confirmed" if parent_id else "unresolved"
                self.relationship_provenance = provenance(
                    "claude-code", reference, metadata.get("toolUseId") or None)
            else:
                self.native_worker_id = None
                self.relationship_provenance = provenance(
                    "claude-code", "main transcript path; no parent metadata")
        self.offset = 0
        self.file_id = None
        self.pending = b""
        self.discarding_line = False
        self.turn = "session"
        self.model = None
        self.provider = None
        self.project = ""
        self.working_directory = ""
        self.branch = ""
        self.run_state = "unknown"
        self.state_since = 0
        self.waiting_for = ""
        self.request_id = ""
        self.request_time_ns = 0
        self.outcome_id = ""
        self.outcome_time_ns = 0
        self.pending_tools = RecentMap(MAX_RECENT_CALLS)
        self.pending_request_times = RecentMap(MAX_RECENT_CALLS)
        self.started = RecentMap(MAX_RECENT_TURNS)
        self.calls = RecentMap(MAX_RECENT_CALLS)
        self.usage = RecentMap(MAX_RECENT_USAGE)
        self.tasks = RecentMap(MAX_RECENT_TURNS)
        self.task_description = ''
        self.tool_inputs = RecentMap(MAX_RECENT_CALLS)
        self.modern_usage = False
        self.last_total = None
        self.last_heartbeat = 0
        self.last_state = None
        self.skipped = 0
        self.last_activity = None
        self.last_record_ns = 0
        self.last_success_ns = 0
        self.backlog_bytes = 0
        self.schema_errors = 0
        self.skipped_oversized = 0
        self.source_size_bytes = 0
        self.source_mtime_ns = 0
        self.records_last_poll = 0
        self.spans_last_poll = 0
        self.logs_last_poll = 0
        self.bytes_read_total = 0
        self.records_total = 0
        self.spans_total = 0
        self.logs_total = 0
        self._pending_ingest = None
        self._redaction_pending = False
        self._pending_spans_done = False
        self._pending_retry = False
        # State publication is constant-time and never holds this lock during
        # source, policy or SQLite I/O. Diagnostics must not combine fields
        # from two different batches while the collector is writing.
        self._storage_lock = threading.Lock()
        self._storage_epoch = identity(time.monotonic_ns(), id(self))
        self._storage_counter = 0
        self._storage_buffer = None
        self._storage_batch_id = None
        self._storage_started = self._storage_progress_at = None
        self._storage_progress_sequence = 0
        self._storage_attempt_in_flight = False
        self._storage_stage = 'idle'
        self._current_record_offset = 0

    @property
    def last_activity(self):
        value=self._last_activity
        return {**value,'subject':'Approval review'} if self.internal and value else value

    @last_activity.setter
    def last_activity(self,value):
        self._last_activity={**value,'subject':'Approval review'} if self.internal and value else value

    def adopt_internal_policy(self):
        self.internal=True;self.capture_details=False;self.service='codex-review'
        self.tasks.clear();self.tool_inputs.clear();self.task_description=''
        self.last_activity=self.last_activity

    def refresh_capture_policy(self):
        if hasattr(self.store,'internal_source_ids') and self.source_id in self.store.internal_source_ids([self.source_id]):
            self.adopt_internal_policy()

    def native_position(self):
        if self.file_id is None:return {}
        return {'observatory.native_file_id':':'.join(map(str,self.file_id)),
            'observatory.native_file_offset':self._current_record_offset,
            'observatory.native_mtime_ns':self.source_mtime_ns}

    def hierarchy(self):
        """Return the structural observation persisted by the receiver."""
        coverage = "partial" if (self.schema_errors or self.skipped or self.backlog_bytes or self._pending_ingest is not None) else "complete"
        return {
            "agent_id": self.agent_id, "runtime": self.runtime,
            "source_namespace": self.agent_namespace, "source_id": self.source_id,
            "native_session_id": self.native_session_id,
            "native_worker_id": self.native_worker_id,
            "parent_agent_id": self.parent_agent_id,
            "relationship_kind": self.relationship_kind,
            "relationship_state": self.relationship_state,
            "relationship_provenance": self.relationship_provenance,
            "discovery_state": self.discovery_state,
            "coverage": coverage,
            "observed_ns": max(self.last_record_ns, self.last_success_ns),
            "review": bool(self.internal),
        }

    def announce(self, child_native_id, stamp, reference, parent_agent_id=None, namespace=None,
                 runtime=None):
        """Record an exact spawn result before the child transcript arrives."""
        child_native_id = _safe_identifier(child_native_id)
        if not child_native_id:
            return None
        runtime = runtime or self.runtime
        namespace = namespace or self.agent_namespace
        parent_agent_id = parent_agent_id or self.agent_id
        try:
            child_id = canonical_agent_id(runtime, namespace, child_native_id)
        except ValueError:
            return None
        if child_id == parent_agent_id:
            return None
        item = self.announced_agents.get(child_id) or {}
        item.update({
            "agent_id": child_id, "runtime": runtime, "source_namespace": namespace,
            "source_id": "announced:" + child_id,
            "native_session_id": child_native_id, "native_worker_id": child_native_id,
            "parent_agent_id": parent_agent_id,
            "relationship_kind": "delegated", "relationship_state": "confirmed",
            "relationship_provenance": provenance("spawn-result", reference, stamp),
            "discovery_state": "announced", "coverage": "unknown",
            "observed_ns": max(item.get("observed_ns") or 0, stamp or 0),
            "review": bool(self.internal),
        })
        self.announced_agents[child_id] = item
        return item

    def finish_turn(self):
        # Roots and model usage are durable in Store. Keep only the current
        # prompt/start for status; unresolved calls have their own bounded grace
        # window and must survive completion and subsequent turns.
        for key in list(self.started):
            if key != self.turn:
                del self.started[key]
        if self.turn in self.tasks:
            task = self.tasks[self.turn]
            self.tasks.clear()
            self.tasks[self.turn] = task
        else:
            self.tasks.clear()

    def _new_storage_batch(self, spans, logs):
        now = time.monotonic()
        with self._storage_lock:
            self._pending_ingest = (spans, logs)
            self._pending_spans_done = False
            self._pending_retry = False
            self._storage_counter += 1
            self._storage_batch_id = self._storage_epoch + ':' + str(self._storage_counter)
            self._storage_buffer = self._pending_ingest
            self._storage_started = self._storage_progress_at = now
            self._storage_progress_sequence = 0
            self._storage_attempt_in_flight = True
            self._storage_stage = 'prepared'

    def _storage_step(self, stage, *, progressed=False, spans_done=False):
        now = time.monotonic()
        with self._storage_lock:
            self._storage_stage = stage
            if progressed:
                self._storage_progress_sequence += 1
                self._storage_progress_at = now
            if spans_done:
                self._pending_spans_done = True

    def storage_diagnostics(self):
        """One coherent metadata snapshot; totals remain the buffered batch size.

        A retry may include spans already committed before its logs failed.
        Empty batches may also need a capture-policy retry, so the boolean
        failure state is authoritative independently of the record count.
        A retrying attempt stays ``retry`` while its in-flight flag is true.
        Progress advances after successful steps, not merely another attempt;
        batch age never resets on retry. Unknown state cannot certify delivery.
        """
        now = time.monotonic()
        with self._storage_lock:
            pending = self._pending_ingest
            total = sum(map(len, pending)) if pending is not None else 0
            known = pending is self._storage_buffer
            retry = bool(self._pending_retry)
            running = self._storage_attempt_in_flight
            state = ('idle' if pending is None and not retry and not running else
                     'retry' if known and pending is not None and retry else
                     'writing' if known and pending is not None and running else 'unknown')
            active = pending is not None
            return dict(storage_diagnostics_version=1, storage_state=state,
                pending_storage_records=total, storage_retry_pending=retry,
                storage_attempt_in_flight=running,
                storage_retry_records=total if state == 'retry' else 0,
                storage_in_flight_records=total if state == 'writing' else 0,
                storage_unknown_records=total if state == 'unknown' else 0,
                storage_batch_id=self._storage_batch_id if active and known else None,
                storage_batch_age_seconds=max(0, now-self._storage_started)
                    if active and known and self._storage_started is not None else None if active else 0,
                storage_progress_age_seconds=max(0, now-self._storage_progress_at)
                    if active and known and self._storage_progress_at is not None else None if active else 0,
                storage_progress_sequence=self._storage_progress_sequence if active and known else 0,
                storage_stage=self._storage_stage if known else 'unknown')

    def diagnostics(self):
        storage = self.storage_diagnostics()
        return {"source_path": str(self.path), "last_success_ns": self.last_success_ns,
                "backlog_bytes": self.backlog_bytes, "skipped_records": self.skipped,
                "source_size_bytes": self.source_size_bytes, "source_mtime_ns": self.source_mtime_ns,
                "records_last_poll": self.records_last_poll,
                "spans_last_poll": self.spans_last_poll, "logs_last_poll": self.logs_last_poll,
                "bytes_read_total": self.bytes_read_total, "records_total": self.records_total,
                "spans_total": self.spans_total, "logs_total": self.logs_total,
                "bytes_read": self.offset,
                "skipped_oversized_records": self.skipped_oversized,
                "schema_errors": self.schema_errors,
                **storage,
                "cache_evictions": sum(mapping.evictions for mapping in
                    (self.started, self.tasks, self.calls, self.tool_inputs, self.usage, self.pending_tools, self.pending_request_times)),
                "cache_tracked_bytes": sum(mapping.tracked_bytes for mapping in
                    (self.started, self.tasks, self.calls, self.tool_inputs, self.usage, self.pending_tools, self.pending_request_times)),
                "cache_max_bytes": sum(mapping.max_bytes for mapping in
                    (self.started, self.tasks, self.calls, self.tool_inputs, self.usage, self.pending_tools, self.pending_request_times)),
                "cache_dropped_oversized_entries": sum(mapping.dropped_oversized for mapping in
                    (self.started, self.tasks, self.calls, self.tool_inputs, self.usage, self.pending_tools, self.pending_request_times))}

    def observe_state(self, row, stamp):
        """Track explicit lifecycle records; absence of output is not an approval wait."""
        payload = (row.get("payload") or {}) if self.runtime == "Codex" else row
        if not isinstance(payload, dict):
            return
        cwd = payload.get("cwd")
        if cwd:
            self.project = Path(cwd).name
            self.working_directory = str(cwd) if self.capture_details else ""
        git = payload.get("git") or {}
        branch = payload.get("gitBranch") or (git.get("branch") if isinstance(git, dict) else None)
        if branch and self.capture_details:
            self.branch = str(branch)
        state = self.run_state
        event = payload.get("type")
        request_key = None
        if self.runtime == "Codex":
            if row.get("type") == "event_msg":
                if event in {"task_started", "task_complete", "task_aborted", "turn_aborted"}:
                    state = {"task_started": "running", "task_complete": "completed",
                             "task_aborted": "interrupted", "turn_aborted": "interrupted"}[event]
                    self.pending_tools.clear()
                elif event in {"approval_request", "request_user_input"}:
                    state = "waiting"
                    self.waiting_for = "Approval" if event == "approval_request" else "User input"
                    request_key = payload.get('request_id') or payload.get('call_id') or payload.get('id') or row.get('ordinal') or row.get('uuid') or row.get('timestamp')
                elif event == "item_completed":
                    item = payload.get("item") or {}
                    if isinstance(item, dict):
                        if item.get("type") == "UserMessage":
                            state = "running"
                            self.pending_tools.clear()
                        elif item.get("type") == "AgentMessage" and item.get("phase") == "final_answer":
                            state = "completed"
                            self.pending_tools.clear()
            if row.get("type") == "response_item":
                key = str(payload.get("call_id") or payload.get("id"))
                if event in {"function_call", "custom_tool_call"}:
                    name = str(payload.get("name") or "Tool")
                    self.pending_tools[key] = name
                    if name.rsplit('.',1)[-1] in {'request_user_input','AskUserQuestion'}:
                        self.pending_request_times[key] = stamp
                    state = "running"
                elif event in {"function_call_output", "custom_tool_call_output"}:
                    self.pending_tools.pop(key, None)
                    if state not in {'completed', 'interrupted', 'failed', 'error', 'incomplete'}:
                        state = "running"
                        self.waiting_for = ""
        elif self.runtime == "Pi":
            message = row.get("message") or {}
            if not isinstance(message, dict):
                return
            role = message.get("role")
            if role == "user":
                state = "running"
                self.pending_tools.clear()
            elif role == "assistant":
                for block in message.get("content") or []:
                    if isinstance(block, dict) and block.get("type") == "toolCall":
                        key = str(block.get('id') or '')
                        name = str(block.get('name') or 'Tool')
                        self.pending_tools[key] = name
                        if name.rsplit('.',1)[-1] in {'request_user_input','AskUserQuestion'}:
                            self.pending_request_times[key] = stamp
                if message.get("stopReason") == "stop":
                    state = "completed"
                    self.pending_tools.clear()
                else:
                    state = "running"
            elif role == "toolResult":
                self.pending_tools.pop(str(message.get("toolCallId") or ""), None)
                state = "running"
        else:
            message = row.get("message") or {}
            if not isinstance(message, dict):
                return
            if row.get('type')=='user' and claude_local_command(row):
                return
            blocks = message.get("content")
            blocks = blocks if isinstance(blocks, list) else []
            if row.get("type") == "user" and not any(isinstance(b, dict) and b.get("type") == "tool_result" for b in blocks):
                state = "running"
                self.pending_tools.clear()
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "tool_use":
                    key = str(block.get('id'))
                    name = str(block.get('name') or 'Tool')
                    self.pending_tools[key] = name
                    if name.rsplit('.',1)[-1] in {'request_user_input','AskUserQuestion'}:
                        self.pending_request_times[key] = stamp
                    state = "running"
                elif block.get("type") == "tool_result":
                    self.pending_tools.pop(str(block.get("tool_use_id")), None)
                    state = "running"
                    self.waiting_for = ""
            if message.get("stop_reason") == "end_turn":
                state = "completed"
                self.pending_tools.clear()
        if self.pending_tools:
            names = list(self.pending_tools.values())
            if any(name.rsplit(".", 1)[-1] in {"request_user_input", "AskUserQuestion"} for name in names):
                state, self.waiting_for = "waiting", "User input"
                request_key = next(key for key, name in self.pending_tools.items()
                    if name.rsplit('.', 1)[-1] in {'request_user_input', 'AskUserQuestion'})
            else:
                mcp = mcp_attributes(names[-1])
                label = mcp["mcp.server.name"] + " / " + mcp["mcp.tool.name"] if mcp else names[-1]
                self.waiting_for = "Tool response: " + label
                if len(names) > 1:
                    self.waiting_for += f" (+{len(names)-1} pending)"
        elif state != "waiting":
            self.waiting_for = ""
        if state == 'waiting' and request_key and str(request_key) != 'None':
            request_id = identity(self.source_id, self.turn, 'request', str(request_key))
            if request_id != self.request_id:
                self.request_id, self.request_time_ns = request_id, self.pending_request_times.get(str(request_key),stamp)
        elif state != 'waiting':
            self.request_id, self.request_time_ns = '', 0
        if state in {'completed', 'interrupted', 'failed', 'error', 'incomplete'}:
            if state != self.run_state or not self.outcome_id:
                self.outcome_id = identity(self.source_id, self.turn, 'outcome', state)
                self.outcome_time_ns = stamp
        else:
            self.outcome_id, self.outcome_time_ns = '', 0
        for key in list(self.pending_request_times):
            if key not in self.pending_tools:
                del self.pending_request_times[key]
        if state != self.run_state:
            self.state_since = stamp
        self.run_state = state

    def span(self, key, name, stamp, attrs=None, *, start=None, parent=True, error=False):
        if not stamp:
            return None
        relationship = {"agent.id": self.agent_id, "agent.runtime": self.runtime,
                        "agent.discovery_state": self.discovery_state,
                        "agent.relationship.kind": self.relationship_kind,
                        "agent.relationship.state": self.relationship_state,
                        "agent.native_session.id": self.native_session_id}
        if self.capture_details and not self.internal and self.task_description:
            relationship['agent.session.task'] = self.task_description
        if self.native_worker_id:
            relationship["agent.native_worker_id"] = self.native_worker_id
        if self.parent_agent_id:
            relationship["agent.parent_id"] = self.parent_agent_id
        attributes = {"session.id": self.session_id, "observatory.project": self.project,
                      "observatory.data_source": "local-session-log", **relationship,
                      **(attrs or {}), **self.native_position()}
        return normalize_native({
            "trace_id": identity(self.source_id, self.turn),
            "span_id": identity(self.source_id, key, size=16) if parent else identity(self.source_id, self.turn, "root", size=16),
            "parent_span_id": identity(self.source_id, self.turn, "root", size=16) if parent else None,
            "name": name, "start_unix_nano": min(start or stamp, stamp), "end_unix_nano": stamp,
            "status": "ERROR" if error else "OK", "attributes": attributes,
            "resource_attributes": {"service.name": self.service, "host.name": socket.gethostname(),
                "os.type": platform.system().lower(), "observatory.source_id": self.source_id,
                "observatory.capture": "local-session-log"},
            "scope_name": "observatory.local_agents",
        }, self.service)

    def root(self, stamp, state):
        attrs = {"agent.task": "Approval review" if self.internal else self.tasks.get(self.turn) or self.runtime + (" · " + self.project if self.project else "") + " · turn",
                 "agent.run.state": state}
        if state in {"completed", "interrupted"}:
            attrs["agent.stopped_reason"] = state
        return self.span((self.turn, "root"), "agent.run", stamp,
            attrs, start=self.started.get(self.turn), parent=False)

    def model_span(self, key, usage, stamp, *, claude=False):
        if not isinstance(usage, dict):
            return None
        attrs = {"gen_ai.operation.name": "chat",
                 "gen_ai.provider.name": "anthropic" if claude else "openai",
                 "observatory.duration_unknown": True}
        input_sources = ("input_tokens", "cache_read_input_tokens", "cache_creation_input_tokens") if claude else ("input_tokens",)
        if any(name in usage for name in input_sources):
            attrs["gen_ai.usage.input_tokens"] = sum(count(usage.get(name)) for name in input_sources)
        if "output_tokens" in usage:
            attrs["gen_ai.usage.output_tokens"] = count(usage.get("output_tokens"))
        cache_read = "cache_read_input_tokens" if claude else (
            "cached_input_tokens" if "cached_input_tokens" in usage else "cache_read_input_tokens")
        if cache_read in usage:
            attrs["gen_ai.usage.cache_read.input_tokens"] = count(usage.get(cache_read))
        cache_write = "cache_creation_input_tokens" if claude else (
            "cache_write_input_tokens" if "cache_write_input_tokens" in usage else "cache_creation_input_tokens")
        if cache_write in usage:
            attrs["gen_ai.usage.cache_write.input_tokens"] = count(usage.get(cache_write))
        reasoning = "reasoning_output_tokens" if "reasoning_output_tokens" in usage else "reasoning_tokens"
        if reasoning in usage:
            attrs["gen_ai.usage.reasoning_tokens"] = count(usage.get(reasoning))
        if self.model:
            attrs["gen_ai.request.model"] = str(self.model)[:200]
        if claude:
            attrs["observatory.native_usage"] = {field: count(usage.get(field)) for field in CLAUDE_USAGE_FIELDS}
        return self.span(key, self.runtime + " · " + str(self.model or "model call")[:200], stamp, attrs)

    def pi(self, row, stamp):
        kind = row.get("type")
        if kind == "session":
            native_id = (_safe_identifier(row.get("agentId")) or
                         _safe_identifier(row.get("id")) or self.session_id)
            self.session_id = native_id
            self.native_session_id = _safe_identifier(row.get("sessionId")) or native_id
            self.native_worker_id = native_id if native_id != self.native_session_id else None
            self.agent_id = canonical_agent_id(self.runtime, self.agent_namespace, native_id)
            parent = (_safe_identifier(row.get("parentAgentId")) or
                      _safe_identifier(row.get("parentSessionId")) or
                      _safe_identifier(row.get("parent_id")))
            if parent:
                self.parent_agent_id = canonical_agent_id(
                    self.runtime, self.agent_namespace, parent)
                self.relationship_kind = "delegated"
                self.relationship_state = "confirmed"
                self.relationship_provenance = provenance(
                    "pi-session", "explicit parentAgentId/parentSessionId", timestamp(row.get("timestamp")))
            else:
                self.relationship_kind = "unknown"
                self.relationship_state = "unresolved"
                self.relationship_provenance = provenance(
                    "pi-session", "no verified parent metadata", timestamp(row.get("timestamp")))
            cwd = row.get("cwd")
            if cwd:
                self.project = Path(cwd).name
                self.working_directory = str(cwd) if self.capture_details else ""
            return []
        if kind == "model_change":
            self.model = row.get("modelId") or self.model
            self.provider = row.get("provider") or self.provider
            return []
        if kind != "message":
            return []
        message = row.get("message") or {}
        if not isinstance(message, dict):
            return []
        role = message.get("role")
        if role == "user":
            self.turn = str(row.get("id") or stamp or self.turn)
            self.started[self.turn] = stamp
            text = plaintext(message.get("content")) if self.capture_details else ""
            if text:
                from .session_text import remember_task
                remember_task(self, message.get("content"))
            return [self.root(stamp, "running")]
        if role == "assistant":
            self.model = message.get("model") or self.model
            self.provider = message.get("provider") or self.provider
            result = []
            usage = message.get("usage")
            if isinstance(usage, dict):
                usage_fields = {
                    "input": "input_tokens", "output": "output_tokens",
                    "cacheRead": "cache_read_input_tokens", "cacheWrite": "cache_write_input_tokens",
                    "reasoning": "reasoning_tokens",
                }
                normalized = {target: usage[source] for source, target in usage_fields.items()
                              if source in usage}
                span = self.model_span(("pi-model", row.get("id") or stamp), normalized, stamp)
                if span:
                    span["attributes"]["gen_ai.provider.name"] = str(self.provider or "unknown")[:128]
                    result.append(span)
            for block in message.get("content") or []:
                if not isinstance(block, dict) or block.get("type") != "toolCall":
                    continue
                call_id = str(block.get("id") or "")
                name = str(block.get("name") or "Tool")
                if call_id:
                    self.calls[call_id] = (name, stamp, self.turn)
            if message.get("stopReason") == "stop":
                result.append(self.root(stamp, "completed"))
            elif message.get("stopReason") == "error":
                result.append(self.root(stamp, "interrupted"))
            return result
        if role == "toolResult":
            call_id = str(message.get("toolCallId") or "")
            pending = self.calls.pop(call_id, None)
            name = str(message.get("toolName") or (pending[0] if pending else "Tool"))
            start = pending[1] if pending else stamp
            turn = pending[2] if pending else self.turn
            previous, self.turn = self.turn, turn
            span = self.span(("tool", call_id), name, stamp,
                {"gen_ai.operation.name": "execute_tool", "tool.name": name},
                start=start, error=bool(message.get("isError")))
            self.turn = previous
            return [span] if span else []
        return []

    def codex(self, row, stamp):
        kind, payload = row.get("type"), row.get("payload") or {}
        if not isinstance(payload, dict):
            return []
        if kind == "session_meta":
            thread_id = _safe_identifier(payload.get("id")) or self.session_id
            self.session_id = thread_id
            self.native_session_id = _safe_identifier(payload.get("session_id")) or thread_id
            self.native_root_session_id = self.native_session_id
            self.native_worker_id = thread_id if thread_id != self.native_session_id else None
            self.agent_id = canonical_agent_id(self.runtime, self.agent_namespace, thread_id)
            source = payload.get("source")
            spawn = {}
            if isinstance(source, dict):
                nested = source.get("subagent")
                if isinstance(nested, dict):
                    spawn = nested.get("thread_spawn") if isinstance(nested.get("thread_spawn"), dict) else {}
            parent_native = (_safe_identifier(payload.get("parent_thread_id")) or
                             _safe_identifier(spawn.get("parent_thread_id")))
            if parent_native:
                self.parent_agent_id = canonical_agent_id(
                    self.runtime, self.agent_namespace, parent_native)
                self.relationship_kind = "delegated"
                self.relationship_state = "confirmed"
                self.relationship_provenance = provenance(
                    "codex-session-meta", "payload.parent_thread_id/source.subagent.thread_spawn",
                    timestamp(payload.get("timestamp")))
            elif _safe_identifier(payload.get("forked_from_id")):
                fork = _safe_identifier(payload.get("forked_from_id"))
                self.parent_agent_id = canonical_agent_id(
                    self.runtime, self.agent_namespace, fork)
                self.relationship_kind = "forked"
                self.relationship_state = "confirmed"
                self.relationship_provenance = provenance(
                    "codex-session-meta", "payload.forked_from_id is a fork, not delegation",
                    timestamp(payload.get("timestamp")))
            elif (isinstance(source, dict) and "subagent" in source) or \
                    str(payload.get("thread_source") or "").casefold() == "subagent":
                self.relationship_kind = "delegated"
                self.relationship_state = "unresolved"
                self.relationship_provenance = provenance(
                    "codex-session-meta", "subagent source without parent_thread_id",
                    timestamp(payload.get("timestamp")))
            elif isinstance(source, str) and source.casefold() in {"cli", "vscode", "exec", "mcp"}:
                self.relationship_kind = "unknown"
                self.relationship_state = "confirmed"
                self.relationship_provenance = provenance(
                    "codex-session-meta", "top-level source=" + source.casefold(),
                    timestamp(payload.get("timestamp")))
            else:
                self.relationship_kind = "unknown"
                self.relationship_state = "unresolved"
                self.relationship_provenance = provenance(
                    "codex-session-meta", "no parent or root marker",
                    timestamp(payload.get("timestamp")))
            self.project = Path(payload["cwd"]).name if payload.get("cwd") else self.project
        elif kind == "turn_context":
            self.turn = str(payload.get("turn_id") or self.turn)
            self.model = payload.get("model") or self.model
            if self.model == "codex-auto-review" and not self.internal:
                self.adopt_internal_policy()
                self._redaction_pending = True
            self.project = Path(payload["cwd"]).name if payload.get("cwd") else self.project
        elif kind == "token_usage_record":
            self.modern_usage = True
            self.turn = str(payload.get("turn_id") or self.turn)
            key = payload.get("response_id") or row.get("ordinal") or row.get("timestamp")
            return [self.model_span(("model", key), payload.get("usage"), stamp)]
        elif kind == "response_item":
            event = payload.get("type")
            key = str(payload.get("call_id") or payload.get("id"))
            if event in {"function_call", "custom_tool_call"}:
                name = str(payload.get("name") or "Tool")
                if name == "spawn_agent":
                    self.spawn_calls[key] = (name, stamp, self.turn)
                if mcp_attributes(name):
                    self.calls[key] = (name, stamp, self.turn)
            elif event in {"function_call_output", "custom_tool_call_output"} and key in self.spawn_calls:
                self.spawn_calls.pop(key, None)
                child = _spawned_agent_id(payload.get("output"))
                if child:
                    self.announce(child, stamp, "function_call_output spawn_agent agent_id")
                if key not in self.calls:
                    return []
            if event in {"function_call_output", "custom_tool_call_output"} and key in self.calls:
                name, start, turn = self.calls[key]
                previous, self.turn = self.turn, turn
                span = self.span(("tool", key), name, stamp,
                    {"gen_ai.operation.name": "execute_tool", "tool.name": name, **mcp_attributes(name)},
                    start=start, error=mcp_failed(payload.get("output")))
                self.turn = previous
                return [span]
        elif kind == "event_msg":
            event = payload.get("type")
            self.turn = str(payload.get("turn_id") or self.turn)
            if event == "task_started":
                self.started[self.turn] = timestamp(payload.get("started_at")) or stamp
                return [self.root(stamp, "running")]
            if event in {"task_complete", "task_aborted", "turn_aborted"}:
                return [self.root(stamp, "completed" if event == "task_complete" else "interrupted")]
            if event == "token_count" and not self.modern_usage:
                info = payload.get("info") or {}
                total = info.get("total_token_usage")
                if not isinstance(total, dict) or total == self.last_total:
                    return []
                usage = info.get("last_token_usage")
                self.last_total = total
                return [self.model_span(("usage", self.turn, json.dumps(total, sort_keys=True)), usage, stamp)]
            if event == "item_completed":
                item = payload.get("item") or {}
                tool_type = item.get("type")
                if tool_type == "AgentMessage" and item.get("phase") == "final_answer":
                    return [self.root(stamp, "completed")]
                names = {"CommandExecution": "Shell command", "FileChange": "File changes",
                         "McpToolCall": "MCP tool", "Extension": "Extension tool"}
                if tool_type in names:
                    attrs = {"gen_ai.operation.name": "execute_tool", "tool.name": names[tool_type]}
                    if tool_type == "McpToolCall":
                        attrs["tool.name"] = str(item.get("tool") or "MCP tool")[:128]
                        attrs["mcp.tool.name"] = attrs["tool.name"]
                        attrs["mcp.server.name"] = str(item.get("server") or "")[:128]
                        attrs["mcp.method.name"] = "tools/call"
                    code = item.get("exit_code")
                    if isinstance(code, int):
                        attrs["process.exit.code"] = code
                    error = item.get("status") in {"failed", "error"} or isinstance(code, int) and code != 0 or (tool_type == "McpToolCall" and mcp_failed(item.get("result")))
                    end = timestamp(payload.get("completed_at_ms")) or stamp
                    start = timestamp(payload.get("started_at_ms"))
                    from .local_activity import duration
                    elapsed = duration(item)
                    if not start and elapsed is not None:
                        start = max(0, end-int(elapsed*1e6))
                    if not start:
                        attrs["observatory.duration_unknown"] = True
                    name = (attrs["mcp.server.name"] + " / " + attrs["tool.name"]) if tool_type == "McpToolCall" else str(attrs["tool.name"])
                    return [self.span(("tool", item.get("id") or row.get("ordinal") or stamp),
                        name, end, attrs, start=start, error=error)]
        return []

    def claude(self, row, stamp, prior_models=None):
        row_session = _safe_identifier(row.get("sessionId"))
        row_agent = _safe_identifier(row.get("agentId"))
        if self.claude_agent_id:
            # Shared-session workers keep their own evidence identity even when
            # every record repeats the root sessionId.
            self.session_id = row_agent or self.claude_agent_id
            self.native_session_id = row_session or self.claude_parent_session_id or self.session_id
            self.native_worker_id = self.claude_agent_id
        elif row_session:
            self.session_id = row_session
            self.native_session_id = row_session
            if not self.native_root_session_id:
                self.native_root_session_id = row_session
            self.agent_id = canonical_agent_id(self.runtime, self.agent_namespace, row_session)
            if not row_agent and not self.parent_agent_id:
                self.relationship_kind = "unknown"
                self.relationship_state = "unresolved"
                self.relationship_provenance = provenance(
                    "claude-code", "main transcript; no parent metadata")
        self.project = Path(row["cwd"]).name if row.get("cwd") else self.project
        message = row.get("message") or {}
        if not isinstance(message, dict):
            return []
        if row.get('type')=='user' and claude_local_command(row):
            return []
        content = message.get("content") or []
        blocks = content if isinstance(content, list) else []
        result = []
        if row.get("type") == "user":
            tools = [block for block in blocks if isinstance(block, dict) and block.get("type") == "tool_result"]
            if not tools:
                self.turn = str(row.get("uuid") or stamp)
                self.started[self.turn] = stamp
                result.append(self.root(stamp, "running"))
            for block in tools:
                key = block.get("tool_use_id")
                if key in self.spawn_calls:
                    self.spawn_calls.pop(key, None)
                    if not block.get("is_error"):
                        child = _spawned_agent_id(row.get("toolUseResult"))
                        if child:
                            self.announce(child, stamp,
                                          "tool_result.toolUseResult.agentId (Claude Task/Agent)")
                name, start, turn = self.calls.get(key, ("Claude tool", stamp, self.turn))
                previous, self.turn = self.turn, turn
                result.append(self.span(("tool", key), name, stamp,
                    {"gen_ai.operation.name": "execute_tool", "tool.name": name, **mcp_attributes(name)},
                    start=start, error=bool(block.get("is_error"))))
                self.turn = previous
        elif row.get("type") == "assistant":
            self.model = message.get("model") or self.model
            key = message.get("id") or row.get("uuid") or stamp
            usage = message.get("usage")
            if isinstance(usage, dict):
                previous = self.usage.get(key)
                if previous is None:
                    previous = {}
                    # Evicting maxima must not lower a persisted model span if
                    # an old streaming update arrives after the cache window.
                    if self.usage.evictions or self.usage.dropped_oversized:
                        span_id = identity(self.source_id, ("model", key), size=16)
                        span = (prior_models or {}).get((identity(self.source_id, self.turn), span_id))
                        if span:
                            previous = span["attributes"].get("observatory.native_usage", previous)
                        elif hasattr(self.store, "_connect"):
                            with self.store._connect() as db:
                                saved = db.execute("SELECT attributes FROM spans WHERE trace_id=? AND span_id=?",
                                    (identity(self.source_id, self.turn), span_id)).fetchone()
                            if saved:
                                previous = json.loads(saved[0]).get("observatory.native_usage", {})
                for field in CLAUDE_USAGE_FIELDS:
                    previous[field] = max(count(previous.get(field)), count(usage.get(field)))
                self.usage[key] = previous
                result.append(self.model_span(("model", key), previous, stamp, claude=True))
            for block in blocks:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    name = str(block.get("name") or "Claude tool")
                    self.calls[block.get("id")] = (name, stamp, self.turn)
                    if name in SPAWN_TOOLS:
                        self.spawn_calls[block.get("id")] = (name, stamp, self.turn)
            if message.get("stop_reason") == "end_turn":
                result.append(self.root(stamp, "completed"))
        return result

    def read_initial_task(self, stream):
        """Read a bounded prefix for identity only; never replay old work or state."""
        if not self.capture_details or self.internal:
            return
        from .local_activity import safe
        from .session_text import task_description
        prefix = stream.read(min(MAX_TASK_PREFIX_BYTES, MAX_READ))
        self.bytes_read_total += len(prefix)
        # The last fragment may be an incomplete record at the byte boundary.
        for line in prefix.split(b'\n')[:-1][:MAX_TASK_PREFIX_RECORDS]:
            try:
                row = loads(line)
                if not isinstance(row, dict):
                    continue
                content = None
                if self.runtime == 'Codex':
                    payload = row.get('payload') or {}
                    if not isinstance(payload, dict):
                        continue
                    if row.get('type') == 'turn_context' and payload.get('model') == 'codex-auto-review':
                        # Privacy classification is the only prefix state we
                        # replay. It must survive a jump over the old context.
                        self.codex(row, timestamp(row.get('timestamp')))
                        return
                    item = payload.get('item') or {}
                    if row.get('type') == 'event_msg' and isinstance(item, dict) and item.get('type') == 'UserMessage':
                        content = item.get('content')
                    elif row.get('type') == 'event_msg' and payload.get('type') == 'user_message':
                        content = payload.get('message')
                    elif row.get('type') == 'response_item' and payload.get('type') == 'message' and payload.get('role') == 'user':
                        content = payload.get('content')
                elif self.runtime == 'Claude Code' and row.get('type') == 'user':
                    message = row.get('message') or {}
                    if isinstance(message, dict):
                        content = message.get('content')
                elif self.runtime == 'Pi' and row.get('type') == 'message':
                    message = row.get('message') or {}
                    if isinstance(message, dict) and message.get('role') == 'user':
                        content = message.get('content')
                if isinstance(content, list):
                    content = [block for block in content if isinstance(block, dict)
                               and block.get('type') in {'text','input_text','output_text'}]
                title = task_description(content)
                if title and not self.task_description:
                    self.task_description = safe(title, 500)
                    if self.runtime != 'Codex':
                        return
            except (ValueError, TypeError, AttributeError, OverflowError, RecursionError):
                continue

    def poll(self):
        # Parsing advances bounded reader state. Retry the same idempotent
        # batch before reading more bytes if either storage transaction failed.
        if self._pending_ingest is not None:
            self.flush_pending_ingest()
        stat = self.path.stat()
        self.source_size_bytes = stat.st_size
        self.source_mtime_ns = stat.st_mtime_ns
        self.records_last_poll = self.spans_last_poll = self.logs_last_poll = 0
        file_id = stat.st_dev, stat.st_ino
        if self.file_id != file_id or stat.st_size < self.offset:
            self.offset, self.pending = 0, b""
            self.discarding_line = False
            self.file_id = file_id
            self.last_total = None
            self.modern_usage = False
            self.turn = 'session'
            self.started.clear()
            self.calls.clear()
            self.usage.clear()
            self.tasks.clear()
            self.task_description = ''
            self.tool_inputs.clear()
            self.pending_tools.clear()
            self.pending_request_times.clear()
            self.spawn_calls.clear()
            self.announced_agents.clear()
            self.run_state, self.waiting_for, self.state_since = "unknown", "", 0
            self.request_id, self.request_time_ns = '', 0
            self.outcome_id, self.outcome_time_ns = '', 0
            self.last_record_ns = 0
        with self.path.open("rb") as stream:
            if self.offset == 0 and stat.st_size > MAX_READ:
                # Recover session identity from the header, then import a bounded tail.
                header = stream.readline(MAX_LINE)
                try:
                    row = loads(header)
                    if self.runtime == "Codex":
                        self.codex(row, timestamp(row.get("timestamp")))
                except (ValueError, TypeError, AttributeError, OverflowError, RecursionError):
                    self.skipped += 1
                    self.schema_errors += 1
                stream.seek(0)
                self.read_initial_task(stream)
                stream.seek(stat.st_size - MAX_READ)
                # Skip only the partial first record, without allocating an
                # arbitrarily large line from a malformed session file.
                while True:
                    fragment = stream.readline(MAX_LINE)
                    if not fragment or fragment.endswith(b"\n"):
                        break
                self.offset = stream.tell()
            stream.seek(self.offset)
            data = stream.read(MAX_READ)
            self.offset = stream.tell()
        self.bytes_read_total += len(data)
        self.backlog_bytes = max(0, stat.st_size - self.offset)
        if self.discarding_line:
            _, separator, data = data.partition(b"\n")
            self.discarding_line = not bool(separator)
        line_offset=self.offset-len(data)-len(self.pending)
        chunks = (self.pending + data).split(b"\n")
        self.pending = chunks.pop()
        if len(self.pending) > MAX_LINE:
            self.pending = b""
            self.discarding_line = True
            self.skipped += 1
            self.skipped_oversized += 1
        records = [];record_offsets=[]
        for line in chunks:
            line_offset+=len(line)+1
            if len(line) > MAX_LINE:
                self.skipped += 1
                self.skipped_oversized += 1
                continue
            try:
                row = loads(line)
                if isinstance(row, dict):
                    records.append(row)
                    record_offsets.append(line_offset)
                else:
                    self.skipped += 1
                    self.schema_errors += 1
            except (ValueError, UnicodeDecodeError, OverflowError, RecursionError):
                self.skipped += 1
                self.schema_errors += 1
        if self.runtime == "Codex" and any(row.get("type") == "token_usage_record" for row in records):
            self.modern_usage = True
        self.records_last_poll = len(records)
        self.records_total += len(records)
        spans = []
        # Poll-local references only (bounded by MAX_READ), discarded on return.
        # Avoid scanning the entire batch for late streaming usage updates.
        prior_models = {}
        logs = []
        from .local_activity import codex_activity, claude_activity
        for row,source_offset in zip(records,record_offsets):
            self._current_record_offset=source_offset
            current_turn = self.turn
            historical_outcome = False
            try:
                payload = row.get('payload') or {}
                terminal_event = (isinstance(payload, dict) and (payload.get('type') in {'task_complete','task_aborted','turn_aborted'}
                    or (payload.get('type') == 'item_completed' and isinstance(payload.get('item'), dict)
                        and payload['item'].get('type') == 'AgentMessage' and payload['item'].get('phase') == 'final_answer')))
                historical_outcome = (self.runtime == 'Codex' and row.get('type') == 'event_msg'
                    and terminal_event and payload.get('turn_id') and current_turn != 'session'
                    and str(payload['turn_id']) != current_turn)
                stamp = timestamp(row.get("timestamp"))
                self.last_record_ns = max(self.last_record_ns, stamp)
                if self.runtime == "Codex":
                    new_spans = self.codex(row, stamp)
                elif self.runtime == "Pi":
                    new_spans = self.pi(row, stamp)
                else:
                    new_spans = self.claude(row, stamp, prior_models)
                for span in new_spans:
                    if span:
                        spans.append(span)
                        if "observatory.native_usage" in span["attributes"]:
                            prior_models[(span["trace_id"], span["span_id"])] = span
                if self.runtime == "Codex":
                    activity=codex_activity(self, row, stamp)
                elif self.runtime == "Pi":
                    from .local_activity import pi_activity
                    activity=pi_activity(self, row, stamp)
                else:
                    activity=claude_activity(self, row, stamp)
                for event in activity:event['attributes'].update(self.native_position())
                logs.extend(activity)
                if historical_outcome:
                    # Keep the historical event and trace, without closing a
                    # newer turn or clearing its pending requests and tools.
                    continue
                self.observe_state(row, stamp)
                if self.capture_details and self.turn in self.tasks and self.turn in self.started:
                    payload = row.get("payload") or {}
                    if (self.runtime == "Codex" and isinstance(payload, dict) and (payload.get("item") or {}).get("type") == "UserMessage") or (self.runtime == "Claude Code" and row.get("type") == "user" and plaintext_task(row) and not claude_local_command(row)):
                        spans.append(self.root(stamp, "running"))
                if self.run_state in {"completed", "interrupted"}:
                    self.finish_turn()
            except (ValueError, TypeError, KeyError, AttributeError, OverflowError, RecursionError):
                self.skipped += 1
                self.schema_errors += 1
            finally:
                if historical_outcome:
                    self.turn = current_turn
        if self.internal:
            from .native_policy import internal_review_attrs, internal_review_events
            for span in spans:
                span['service'] = self.service
                span['resource_attributes']['service.name'] = self.service
                span['attributes']=internal_review_attrs(span['attributes'])
                span['events']=internal_review_events(span.get('events') or [])
                span['links']=[]
                if span['name'] == 'agent.run':
                    span['attributes']['agent.task'] = 'Approval review'
                else:span['name']='Approval review'
            for log in logs:
                log['service'] = self.service
                log['body'] = ''
                log['attributes']=internal_review_attrs(log['attributes'])
        self._new_storage_batch(spans, logs)
        self.flush_pending_ingest()
        state = "running" if time.time() - stat.st_mtime < 35 else "stopped"
        if time.monotonic() - self.last_heartbeat > 10 or state != self.last_state:
            self.store.register_connection({"source_id": self.source_id, "service": self.service,
                "runtime": self.runtime + " local sessions", "integrations": ["local-session-log"],
                "capture_content": self.capture_details, "state": state})
            self.last_heartbeat, self.last_state = time.monotonic(), state
        return len(spans)

    def flush_pending_ingest(self):
        with self._storage_lock:
            spans,logs=self._pending_ingest
            # Directly restored/legacy buffered batches have no current state
            # publication until a real delivery attempt starts here.
            if self._pending_ingest is not self._storage_buffer:
                now = time.monotonic()
                self._storage_counter += 1
                self._storage_batch_id = self._storage_epoch + ':' + str(self._storage_counter)
                self._storage_buffer = self._pending_ingest
                self._storage_started = self._storage_progress_at = now
                self._storage_progress_sequence = 0
            self._storage_attempt_in_flight = True
            self._storage_stage = 'capture_policy'
        try:
            try:
                if spans or logs or self._redaction_pending:
                    self.refresh_capture_policy()
                    self._storage_step('capture_policy', progressed=True)
                if self.internal:
                    from .native_policy import scrub_record
                    spans=[scrub_record(row,'span') for row in spans]
                    logs=[scrub_record(row,'log') for row in logs]
                    with self._storage_lock:
                        self._pending_ingest=(spans,logs)
                        self._storage_buffer=self._pending_ingest
                if self._redaction_pending:
                    self._storage_step('redaction')
                    self.store.redact_internal_source(self.source_id)
                    self._redaction_pending=False
                    self._storage_step('redaction', progressed=True)
                if spans and not self._pending_spans_done:
                    self._storage_step('spans')
                    self.store.ingest(spans,native_retry=self._pending_retry,native_source_path=self.path)
                    self._storage_step('spans', progressed=True, spans_done=True)
                if logs:
                    self._storage_step('logs')
                    self.store.ingest_logs(logs,native_retry=self._pending_retry,native_source_path=self.path)
                    self._storage_step('logs', progressed=True)
                if spans or logs:
                    self._storage_step('capture_policy')
                    self.refresh_capture_policy()
                    self._storage_step('capture_policy', progressed=True)
            except Exception:
                with self._storage_lock:self._pending_retry=True
                raise
            self._storage_step('collector_metadata')
            if logs:
                last = logs[-1]
                self.last_activity = {"time_unix_nano": last["time_unix_nano"],
                                      "domain": last["attributes"].get("agent.activity.domain"),
                                      "action": last["attributes"].get("agent.activity.action"),
                                      "subject": last["attributes"].get("agent.activity.subject"),
                                      "result": last["attributes"].get("agent.activity.result")}
            self.spans_last_poll = len(spans)
            self.logs_last_poll = len(logs)
            self.spans_total += len(spans)
            self.logs_total += len(logs)
            self.last_success_ns = time.time_ns()
            with self._storage_lock:
                self._pending_ingest=None
                self._pending_retry=False
                self._storage_buffer=None
                self._storage_batch_id=None
                self._storage_started=self._storage_progress_at=None
                self._storage_progress_sequence=0
                self._storage_stage='idle'
                self._storage_attempt_in_flight=False
        finally:
            with self._storage_lock:self._storage_attempt_in_flight=False


CLAUDE_META_BYTES = 64 * 1024
SPAWN_TOOLS = {"spawn_agent", "Task", "Agent"}


def _claude_subagent_identity(path):
    """Return (agent_id, parent_session_id, sidecar) for a subagent transcript."""
    parts = path.parts
    if "subagents" not in parts:
        return None, None, {}
    index = parts.index("subagents")
    name = path.name
    if not name.startswith("agent-") or path.suffix != ".jsonl":
        return None, None, {}
    agent_id = name[len("agent-"):-len(".jsonl")]
    if not agent_id or len(agent_id) > 256:
        return None, None, {}
    parent_session = parts[index - 1] if index else None
    metadata = {}
    meta_path = path.with_name(name[:-len(".jsonl")] + ".meta.json")
    try:
        if meta_path.is_file() and meta_path.stat().st_size <= CLAUDE_META_BYTES:
            value = loads(meta_path.read_bytes())
            if isinstance(value, dict):
                metadata = value
    except (OSError, ValueError, TypeError, OverflowError, RecursionError):
        metadata = {}
    return agent_id, parent_session, metadata


def _spawned_agent_id(value):
    """Extract only an exact child identity from a successful spawn result."""
    if isinstance(value, str):
        try:
            value = loads(value)
        except (ValueError, TypeError, OverflowError, RecursionError):
            return None
    if not isinstance(value, dict):
        return None
    if value.get("is_error") or value.get("isError") or value.get("error"):
        return None
    for key in ("agent_id", "agentId", "thread_id"):
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate.strip() and len(candidate) <= 256:
            return candidate.strip()
    return None


def _safe_identifier(value, limit=256):
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value if value and len(value) <= limit else None


def claude_local_command(row):
    from .session_text import local_command_only
    message=row.get('message') or {}
    return isinstance(message,dict) and local_command_only(message.get('content'))


def plaintext_task(row):
    message = row.get("message") or {}
    if not isinstance(message, dict):
        return False
    content = message.get("content")
    return isinstance(content, str) or isinstance(content, list) and any(isinstance(block, dict) and block.get("type") == "text" for block in content)


class LocalAgents:
    def __init__(self, store, capture_details=True):
        self.store = store
        self.capture_details = capture_details
        self.stop = threading.Event()
        self.sessions = {}
        self.discovered_sources = 0
        self.omitted_sources = 0
        self.errors = 0
        self.last_error = None
        self.runtime_snapshot = {}
        self.runtime_updated = 0
        self.process_samples = {}
        self.mcp_configurations = []
        self.mcp_config_errors = 0
        self.mcp_config_updated = 0
        self.hierarchy_revision = ""
        self.hierarchy_facts_revision = ""
        self.hierarchy_write_errors = 0
        from .opencode import OpenCodeReader
        self.opencode = OpenCodeReader(store, capture_details=capture_details)
        self.initial_poll_complete = False
        self.thread = threading.Thread(target=self.loop, name="observatory-local-agents", daemon=True)

    def record_error(self, error, operation):
        from .findings import _safe_text
        self.errors+=1
        self.last_error={'kind':type(error).__name__,'operation':operation,
            'message':_safe_text(str(error))[:300],'at_ns':time.time_ns()}

    def discover(self):
        roots = [(Path(os.environ.get("CODEX_HOME", str(Path.home()/".codex")))/"sessions", "Codex"),
                 (Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home()/".claude")))/"projects", "Claude Code"),
                 (Path(os.environ.get("PI_CODING_AGENT_DIR", str(Path.home()/".pi"/"agent")))/"sessions", "Pi")]
        cutoff = time.time() - 86400
        self.discovered_sources = 0
        pending_sources={path for path,session in self.sessions.items() if session._pending_ingest is not None}
        discovered_pending=set()
        def recent():
            for root, runtime in roots:
                if not root.is_dir():
                    continue
                # One directory pass; DirEntry reuses directory type metadata.
                # Path.rglob traverses directories separately from matching files
                # and constructs Paths for the entire (mostly old) history.
                pending = [root]
                while pending:
                    if self.stop.is_set():
                        return
                    try:
                        with os.scandir(pending.pop()) as entries:
                            for entry in entries:
                                if self.stop.is_set():
                                    return
                                try:
                                    if entry.is_dir(follow_symlinks=False):
                                        pending.append(entry.path)
                                    elif entry.name.endswith('.jsonl') and entry.is_file():
                                        modified = entry.stat().st_mtime
                                        if modified >= cutoff:
                                            self.discovered_sources += 1
                                            if Path(entry.path) in pending_sources:discovered_pending.add(Path(entry.path))
                                            yield modified, Path(entry.path), runtime
                                except OSError as exc:
                                    self.record_error(exc,'Inspecting native source entry')
                    except OSError as exc:
                        self.record_error(exc,'Discovering native source directory')
        selected = heapq.nlargest(MAX_SOURCES, recent(), key=lambda row: row[0])
        selected=[row for row in selected if row[1] not in pending_sources][:max(0,MAX_SOURCES-len(pending_sources))]
        keys={path for _,path,_ in selected}|pending_sources
        self.omitted_sources=max(0,self.discovered_sources-len(selected)-len(discovered_pending))
        self.sessions = {path: session for path, session in self.sessions.items() if path in keys}
        for _, path, runtime in selected:
            if path not in self.sessions:
                self.sessions[path] = Session(self.store, path, runtime, capture_details=self.capture_details)

    def poll(self):
        accepted = 0
        for session in list(self.sessions.values()):
            if self.stop.is_set():
                break
            try:
                accepted += session.poll()
            except OSError as exc:
                self.record_error(exc,'Reading native source')
        return accepted

    def loop(self):
        discovered = 0
        while not self.stop.is_set():
            try:
                if time.monotonic() - discovered >= 10:
                    self.discover()
                    project_directories = {session.working_directory for session in self.sessions.values()
                                           if session.working_directory}
                    from .local_runtime import project_directories as runtime_project_directories
                    project_directories.update(runtime_project_directories({"gemini", "cursor", "opencode"}))
                    config_errors = [0]
                    def note_config_error():
                        config_errors[0] += 1
                    self.mcp_configurations = discover_mcp_configurations(
                        project_directories=project_directories,
                        on_error=note_config_error)
                    self.opencode.set_mcp_servers(
                        item["server"] for item in self.mcp_configurations
                        if item["client"] == "OpenCode")
                    self.mcp_config_errors = config_errors[0]
                    self.mcp_config_updated = time.monotonic()
                    discovered = time.monotonic()
                self.poll()
                if not self.stop.is_set():
                    self.opencode.poll()
                    self.initial_poll_complete = True
            except Exception as exc:
                self.record_error(exc,'Polling native sources')
            self.stop.wait(1)

    def start(self):
        self.thread.start()
        return self

    def hierarchy_nodes(self, sessions=None):
        """Collect observed and announced nodes, deduplicated by canonical identity."""
        sessions = list(self.sessions.values()) if sessions is None else list(sessions)
        observed = {session.agent_id: session.hierarchy() for session in sessions}
        announced = {}
        for session in sessions:
            for child_id, item in session.announced_agents.items():
                if child_id not in observed:
                    announced[child_id] = dict(item)
        nodes = [*observed.values(), *announced.values()]
        return nodes, announced

    def status(self):
        sessions = list(self.sessions.values())
        internal=(self.store.internal_source_ids([session.source_id for session in sessions])
                  if hasattr(self.store,'internal_source_ids') else set())
        for session in sessions:
            if session.source_id in internal:session.adopt_internal_policy()
        if time.monotonic() - self.runtime_updated >= 5:
            from .local_runtime import snapshot
            self.runtime_snapshot = snapshot({session.path: session.source_id for session in sessions})
            now_ns = time.time_ns()
            samples = self.runtime_snapshot.get('sessions', {})
            for source, sample in samples.items():
                previous = self.process_samples.get(source, {})
                same_process = previous.get('identity') == sample['identity']
                progressed = (sample.get("progress_attributed", True) and same_process and
                              (sample['cpu_seconds'] > previous.get('cpu_seconds', 0) or
                               sample['io_chars'] > previous.get('io_chars', 0)))
                sample['observed_since_ns'] = previous.get('observed_since_ns', now_ns) if same_process else now_ns
                sample['last_progress_ns'] = (now_ns if progressed else previous.get('last_progress_ns', 0) if same_process else 0) if sample.get('progress_attributed', True) else 0
                sample['observed_at_ns'] = now_ns
            self.process_samples = samples
            self.runtime_updated = time.monotonic()
        observed = [{"source_id": session.source_id, "runtime": session.runtime,
                     "service": session.service, "session_id": session.session_id,
                     "project": session.project, "model": session.model,
                     "working_directory": session.working_directory, "branch": session.branch,
                     "run_state": session.run_state, "state_since_ns": session.state_since,
                     "trace_id": identity(session.source_id, session.turn) if session.turn != 'session' else '',
                     "run_start_ns": session.started.get(session.turn) or None,
                     "request_id": session.request_id, "request_time_ns": session.request_time_ns,
                     "outcome_id": session.outcome_id, "outcome_time_ns": session.outcome_time_ns,
                     "waiting_for": session.waiting_for,
                     "task": "Approval review" if session.internal else (session.task_description or session.tasks.get(session.turn) or "")[:500],
                     "initial_task": session.task_description if session.capture_details and not session.internal else "",
                     "capture_content": session.capture_details,
                     "last_activity": session.last_activity,
                     "last_record_ns": session.last_record_ns,
                     "process": self.process_samples.get(session.source_id, {}),
                     "diagnostics": session.diagnostics(),
                     **session.hierarchy(),
                     "bytes_read": session.offset} for session in sessions]
        opencode_observed = self.opencode.status_sessions()
        observed.extend(opencode_observed)
        nodes, announced = self.hierarchy_nodes(sessions)
        observed_ids = {item.get("agent_id") for item in observed}
        nodes.extend(item for item in opencode_observed
                     if item.get("agent_id") and item.get("agent_id") not in
                     {node.get("agent_id") for node in nodes})
        facts = tuple(sorted(
            (node.get("agent_id"), node.get("parent_agent_id"), node.get("relationship_kind"),
             node.get("relationship_state"), node.get("relationship_provenance"),
             node.get("discovery_state"), node.get("coverage"), bool(node.get("review")))
            for node in nodes))
        facts_revision = identity("hierarchy", *facts) if facts else ""
        if facts_revision != self.hierarchy_facts_revision:
            upsert = getattr(self.store, "upsert_agent_nodes", None)
            if upsert:
                try:
                    upsert(nodes)
                except (ValueError, TypeError, OSError):
                    self.hierarchy_write_errors += 1
                else:
                    self.hierarchy_facts_revision = facts_revision
            else:
                self.hierarchy_facts_revision = facts_revision
        persisted = getattr(self.store, "hierarchy_revision", None)
        if persisted:
            self.hierarchy_revision = persisted()
        elif not self.hierarchy_revision:
            self.hierarchy_revision = facts_revision
        for child_id, node in announced.items():
            if child_id in observed_ids:
                continue
            observed.append({
                **node, "source_id": node.get("source_id") or "announced:" + child_id,
                "id": node.get("source_id") or "announced:" + child_id,
                "session_id": node.get("native_worker_id") or node.get("native_session_id"),
                "service": node.get("runtime", "").casefold().replace(" ", "-"),
                "project": "", "model": "", "working_directory": "", "branch": "",
                "run_state": "announced", "state_since_ns": node.get("observed_ns", 0),
                "waiting_for": "", "task": "Spawn recorded", "capture_content": self.capture_details,
                "last_activity": {}, "last_record_ns": node.get("observed_ns", 0),
                "diagnostics": {}, "bytes_read": 0,
            })
        node_ids = {item.get("agent_id") for item in nodes}
        missing_parents = {item.get("parent_agent_id") for item in observed
                           if item.get("parent_agent_id") and
                           item.get("parent_agent_id") not in node_ids}
        context_lookup = getattr(self.store, "agent_node_contexts", None)
        if missing_parents and context_lookup:
            try:
                contexts = context_lookup(missing_parents)
            except (ValueError, TypeError, OSError):
                contexts = {}
                self.hierarchy_write_errors += 1
            for item in observed:
                context = contexts.get(item.get("parent_agent_id"))
                if context:
                    item["parent_context"] = context
        return {"enabled": True, "initial_poll_complete": self.initial_poll_complete, "sources": len(sessions), "discovered_sources": self.discovered_sources,
                "omitted_sources": self.omitted_sources, "read_errors": self.errors,
                "last_read_error": self.last_error,
                "skipped_records": sum(session.skipped for session in sessions),
                "backlog_bytes": sum(session.backlog_bytes for session in sessions),
                "schema_errors": sum(session.schema_errors for session in sessions),
                "skipped_oversized_records": sum(session.skipped_oversized for session in sessions),
                "capture_content": self.capture_details, "lookback_hours": 24, "max_sources": MAX_SOURCES,
                "opencode_discovered_sessions": self.opencode.discovered_sessions,
                "opencode_omitted_sessions": self.opencode.omitted_sessions,
                "opencode_diagnostics": self.opencode.diagnostics(),
                "runtime": self.runtime_snapshot,
                "mcp_configurations": list(self.mcp_configurations),
                "mcp_config_errors": self.mcp_config_errors,
                "mcp_config_updated": self.mcp_config_updated,
                "hierarchy": {"revision": self.hierarchy_revision or facts_revision,
                              "nodes": len(nodes), "announced": len(announced),
                              "coverage": ("partial" if any(
                                  node.get("discovery_state") == "announced" or
                                  node.get("coverage") in {"partial", "unknown"}
                                  for node in nodes) else "complete"),
                              "write_errors": self.hierarchy_write_errors},
                "sessions": observed,
                "opencode_read_errors": self.opencode.errors}

    def close(self):
        self.stop.set()
        # Ctrl-C can arrive while the main thread is joining this worker.
        # The stop flag is already set, so consume interrupts during the
        # bounded shutdown wait rather than leaking a traceback on exit.
        deadline = time.monotonic() + 15
        while self.thread.is_alive() and time.monotonic() < deadline:
            try:
                self.thread.join(timeout=min(1, max(0, deadline - time.monotonic())))
            except KeyboardInterrupt:
                continue
