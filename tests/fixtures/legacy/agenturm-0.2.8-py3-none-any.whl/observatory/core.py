"""Normalize native JSONL and OTLP/JSON spans into one queryable store."""
from __future__ import annotations

import json
import uuid
import hashlib
import heapq
import math
import os
import re
import sqlite3
import time
import base64
import threading
from contextlib import contextmanager, nullcontext
from pathlib import Path

from .agent_hierarchy import (AGENT_ID, HierarchyGraph, canonical_agent_id, normalize_node,
                              provenance)
from .findings import _safe_text, analyze, mcp_result_error

TRACE_ID = re.compile(r"^[0-9a-fA-F]{32}$")
SPAN_ID = re.compile(r"^[0-9a-fA-F]{16}$")
SESSION_KEYS = ("gen_ai.conversation.id", "session.id", "agent.session_id",
                "session_id", "conversation_id", "thread_id", "langgraph.thread_id",
                "langchain.session_id", "cursor.conversation.id")
INPUT_TOKEN_KEYS = ("gen_ai.usage.input_tokens", "llm.usage.input_tokens", "llm.token_count.prompt")
OUTPUT_TOKEN_KEYS = ("gen_ai.usage.output_tokens", "llm.usage.output_tokens", "llm.token_count.completion")
TOKEN_BREAKDOWN_KEYS = {
    "cache_read_input_tokens": (
        "gen_ai.usage.cache_read.input_tokens", "gen_ai.usage.cached_input_tokens",
        "llm.usage.cache_read_input_tokens", "cache_read_input_tokens", "cached_input_tokens"),
    "cache_write_input_tokens": (
        "gen_ai.usage.cache_write.input_tokens", "gen_ai.usage.cache_creation.input_tokens",
        "gen_ai.usage.cache_write_input_tokens", "gen_ai.usage.cache_creation_input_tokens",
        "llm.usage.cache_creation_input_tokens", "cache_creation_input_tokens"),
    "reasoning_output_tokens": (
        "gen_ai.usage.reasoning.output_tokens", "gen_ai.usage.reasoning_tokens",
        "llm.usage.reasoning_tokens", "reasoning_tokens"),
}
ENDPOINT_ID_KEYS = ("host.id", "host.name", "device.id", "service.instance.id")
ENDPOINT_RESOURCE_KEYS = frozenset((*ENDPOINT_ID_KEYS, "host.arch", "os.type", "os.name",
                                    "os.description", "os.version", "user.name", "user.id",
                                    "deployment.environment.name", "cloud.region"))


def _session_sql_expression(alias=""):
    prefix = f"{alias}." if alias else ""
    return "COALESCE(" + ",".join(
        f"NULLIF(json_extract({prefix}{column}, '$.\"{key}\"'), '')"
        for key in SESSION_KEYS
        for column in ("attributes", "resource_attributes")
    ) + ")"


def _id(value, pattern, label):
    if not isinstance(value, str) or not pattern.fullmatch(value):
        raise ValueError(f"invalid {label}")
    if not any(c != "0" for c in value):
        raise ValueError(f"invalid zero {label}")
    return value.lower()


def _session_value(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value if value and len(value) <= 512 else None


def _activity_session(attrs,resource=None):
    # An explicit alias family overrides the resource family, including malformed
    # claims. Contradictory aliases cannot prove a source's session ownership.
    family=attrs if any(key in attrs for key in SESSION_KEYS) else resource or {}
    values=[_session_value(family[key]) for key in SESSION_KEYS if key in family]
    return values[0] if values and values[0] is not None and all(value==values[0] for value in values) else None


def _agent_id_from_attributes(attrs, resource=None, service=None):
    if not isinstance(attrs, dict):
        return None
    raw = attrs.get("agent.id")
    if not raw and isinstance(resource, dict):
        raw = resource.get("agent.id")
    if isinstance(raw, str) and AGENT_ID.fullmatch(raw):
        return raw.lower()
    node = _agent_node_from_attributes(attrs, resource, service, 0, None)
    return node["agent_id"] if node else None


def _agent_node_from_attributes(attrs, resource, service, observed_ns, reference):
    """Read the additive SDK/OTLP agent hierarchy convention."""
    if not isinstance(attrs, dict):
        return None
    resource = resource if isinstance(resource, dict) else {}
    native = attrs.get("agent.id") or resource.get("agent.id")
    if not isinstance(native, str) or not native.strip() or len(native) > 256:
        return None
    runtime = str(attrs.get("agent.runtime") or resource.get("service.name") or service or "SDK")
    namespace = str(attrs.get("agent.namespace") or resource.get("service.name") or service or runtime)
    worker = attrs.get("agent.worker_id") or resource.get("agent.worker_id")
    worker = str(worker)[:256] if worker else None
    parent_native = attrs.get("agent.parent_id") or resource.get("agent.parent_id")
    parent_native = str(parent_native)[:256] if isinstance(parent_native, str) and parent_native else None
    try:
        agent_id = (native.lower() if AGENT_ID.fullmatch(native)
                    else canonical_agent_id(runtime, namespace, native))
        parent_id = None
        if parent_native:
            parent_id = (parent_native.lower() if AGENT_ID.fullmatch(parent_native)
                         else canonical_agent_id(runtime, namespace, parent_native))
    except ValueError:
        return None
    kind = str(attrs.get("agent.relationship.kind") or "unknown").casefold()
    if kind not in {"delegated", "forked", "unknown"}:
        kind = "unknown"
    state = str(attrs.get("agent.relationship.state") or "").casefold()
    if state not in {"confirmed", "unresolved", "conflicted", "invalid"}:
        state = "confirmed" if parent_native else "unresolved"
    if parent_native:
        kind = "delegated" if kind == "unknown" else kind
    native_session = next((attrs.get(key) or resource.get(key) for key in SESSION_KEYS
                           if isinstance(attrs.get(key) or resource.get(key), str)), None)
    observed_ns = _nonnegative_int(observed_ns)
    return {
        "agent_id": agent_id, "runtime": runtime, "source_namespace": namespace,
        "source_id": str(attrs.get("observatory.source_id") or
                         resource.get("observatory.source_id") or reference or "")[:128] or None,
        "native_session_id": native_session, "native_worker_id": worker,
        "parent_agent_id": parent_id, "relationship_kind": kind,
        "relationship_state": state,
        "relationship_provenance": provenance(
            "sdk-otlp", "agent.id/agent.parent_id telemetry attributes"),
        "discovery_state": "observed",
        "coverage": str(attrs.get("agent.coverage") or "complete"),
        "review": bool(attrs.get("agent.review") or resource.get("agent.review")),
        "observed_ns": observed_ns,
    }


def _nonnegative_int(value):
    try:
        return max(0, int(value)) if not isinstance(value, bool) else 0
    except (TypeError, ValueError, OverflowError):
        return 0


def _waiting_for(attrs):
    if not isinstance(attrs, dict):
        return None
    for key in ("agent.waiting_for", "agent.wait.reason", "waiting_for", "wait_reason"):
        value = attrs.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()[:500]
    if str(attrs.get("agent.run.state") or attrs.get("agent.state") or "").casefold() == "waiting":
        return "Waiting"
    stage = str(attrs.get("agent.progress.stage") or attrs.get("progress.stage") or "")
    stage = stage.casefold().replace("-", "_").replace(" ", "_")
    if stage in {"waiting", "waiting_for_user", "awaiting_user", "waiting_for_input",
                 "awaiting_input", "waiting_for_approval", "awaiting_approval"}:
        if stage in {"waiting_for_approval", "awaiting_approval"}:
            return "Approval"
        if stage in {"waiting_for_user", "awaiting_user", "waiting_for_input", "awaiting_input"}:
            return str(attrs.get("agent.progress.message") or attrs.get("progress.message") or
                       "User input")[:500]
        return str(attrs.get("agent.progress.message") or attrs.get("progress.message") or
                   "Waiting")[:500]
    return None


def _endpoint_identity(resource):
    if not isinstance(resource, dict):
        return None
    for key in ENDPOINT_ID_KEYS:
        value = resource.get(key)
        if isinstance(value, str) and value.strip():
            return key, value.strip()[:512]
    return None


def _session_for(spans, progress, logs):
    ordered_spans = sorted(spans, key=lambda span: (bool(span["parent_span_id"]), span["start_unix_nano"]))
    for key in SESSION_KEYS:
        for span in ordered_spans:
            value = _session_value(span["attributes"].get(key) or span["resource_attributes"].get(key))
            if value:
                return value
            for event in span["events"]:
                value = _session_value(event.get("attributes", {}).get(key))
                if value:
                    return value
        for log in logs:
            value = _session_value(log["attributes"].get(key) or log["resource_attributes"].get(key))
            if value:
                return value
        if key == "session.id":
            for event in progress:
                value = _session_value(event.get("session_id"))
                if value:
                    return value
    return None


def _activity_row(attrs, time_ns, source, source_id, span_id=None, service="unknown", body=None,
                  resource_attributes=None):
    """Normalize the shared agent.activity event vocabulary for the trace ledger."""
    attrs = attrs if isinstance(attrs, dict) else {}
    def value(*keys):
        for key in keys:
            item = attrs.get(key)
            if item is not None and item != "":
                return str(item)
        return ""
    try:
        time_ns = int(time_ns or 0)
    except (TypeError, ValueError, OverflowError):
        time_ns = 0
    resource_attributes = resource_attributes if isinstance(resource_attributes, dict) else {}
    cursor_metadata = {key: item for key, item in {**resource_attributes, **attrs}.items()
                       if key.startswith("cursor.") and not key.startswith("cursor.user.")
                       and key != "cursor.team.id" and item is not None}
    row={"activity_scope_version": 1, "time_unix_nano": max(0, time_ns),
            "domain": value("agent.activity.domain", "activity.domain") or "other",
            "action": value("agent.activity.action", "activity.action") or "activity",
            "subject": value("agent.activity.subject", "agent.activity.target",
                             "activity.subject", "activity.target"),
            "result": value("agent.activity.result", "activity.result") or "unknown",
            "actor": value("agent.activity.actor", "agent.actor"),
            "agent_id": (_agent_id_from_attributes(attrs, resource_attributes, service)
                         if 'agent.id' not in attrs or isinstance(attrs['agent.id'],str) else None),
            "session_id": _activity_session(attrs,resource_attributes),
            "service": str(service), "source": source, "source_id": str(source_id),
            "span_id": span_id, "turn_id": _session_value(attrs.get('agent.turn.id')) or '', "detail": value("agent.activity.detail") or (body if isinstance(body, str) else ""),
            "mcp_server": value("mcp.server.name"), "mcp_tool": value("mcp.tool.name"),
            "duration_ms": attrs.get("duration_ms"), "metadata": cursor_metadata}
    if type(attrs.get('observatory.operation.schema')) is int and attrs['observatory.operation.schema']==1:
        row['detail_role']='operation_v1'
    elif row['domain'] in {'shell','tool','mcp'}:
        from .operation_facts import activity_evidence,evidence_detail
        evidence=activity_evidence(attrs,row['detail'],row['domain'],row['subject'],body=body)
        if evidence['qualified_detail']:
            row.update(detail=evidence_detail(evidence),detail_role='operation_v1')
    from .operation_facts import normalize_operation_result
    if type(attrs.get('observatory.native.schema')) is int and attrs['observatory.native.schema']==1:
        from .native_lifecycle import native_metadata
        native=native_metadata(attrs,resource_attributes)
        if native is not None:row['native_lifecycle']=native
    return normalize_operation_result(row)


def _task_outcome_from_log(attrs, event_name):
    from .session_status import task_outcome
    state = task_outcome({'attributes': attrs})
    if state != 'unknown':
        return state
    source_event = attrs.get('observatory.source.event_name')
    event = (source_event.strip() if isinstance(source_event,str) else '') or event_name
    if event == 'gemini_cli.agent.start':
        return 'running'
    if event == 'gemini_cli.agent.finish':
        return 'completed'
    if event == 'cursor.grok_bot.routine_run':
        result = str(attrs.get('agent.activity.result') or '').casefold()
        return ('failed' if result in {'error', 'failed'} else
                'interrupted' if result in {'cancelled', 'canceled'} else
                'completed' if result in {'success', 'completed', 'ok'} else 'unknown')
    return 'waiting' if _waiting_for(attrs) else None


def _progress_from_log(log):
    attrs = log.get("attributes") if isinstance(log.get("attributes"), dict) else {}
    event_name = log.get("event_name") or attrs.get("event.name")
    runtime_event = attrs.get("observatory.source.event_name")
    gemini_lifecycle = runtime_event in {"gemini_cli.agent.start", "gemini_cli.agent.finish"}
    if event_name not in {"agent.progress", "progress"} and not gemini_lifecycle:
        return None
    body = log.get("body")
    body_map = body if isinstance(body, dict) else {}
    def first(*values):
        return next((value for value in values if value is not None and value != ""), None)
    percent = first(attrs.get("agent.progress.percent"), attrs.get("progress.percent"),
                    body_map.get("percent"))
    try:
        percent = None if isinstance(percent, bool) else (float(percent) if percent is not None else None)
        if percent is not None and (not math.isfinite(percent) or not 0 <= percent <= 100):
            percent = None
    except (TypeError, ValueError, OverflowError):
        percent = None
    if isinstance(body, str):
        body_message = body
    elif body_map:
        body_message = first(body_map.get("message"), body_map.get("detail"), "")
    else:
        body_message = ""
    session_id = first(*(attrs.get(key) for key in SESSION_KEYS),
                       *(log.get("resource_attributes", {}).get(key) for key in SESSION_KEYS))
    lifecycle_started = runtime_event == "gemini_cli.agent.start"
    return {"time_ns": log.get("time_unix_nano", 0),
            "stage": str(first("Agent started" if lifecycle_started else "Agent finished" if gemini_lifecycle else None,
                               attrs.get("agent.progress.stage"), attrs.get("progress.stage"),
                               body_map.get("stage"), "progress")),
            "message": str(first(attrs.get("agent.progress.message"), attrs.get("progress.message"),
                                 attrs.get("agent_name") if gemini_lifecycle else None,
                                 body_message, "")),
            "percent": percent, "session_id": _session_value(session_id),
            "service": log.get("service"),
            "status": "RUNNING" if lifecycle_started else "OK" if gemini_lifecycle else None}


def _tool_activity(span):
    attrs = span.get("attributes") if isinstance(span.get("attributes"), dict) else {}
    from .operation_facts import attribute_evidence,decode,evidence_detail
    evidence=attribute_evidence(attrs)
    operation = str(attrs.get("gen_ai.operation.name") or "").lower()
    openinference_tool = attrs.get("openinference.span.kind") == "TOOL"
    tool_name = (attrs.get("gen_ai.tool.name") or attrs.get("mcp.tool.name") or
                 attrs.get("tool.name"))
    if not tool_name and operation != "execute_tool" and not openinference_tool:
        return None
    tool_name = str(tool_name or span.get("name") or "tool call")
    domain = (attrs.get("gen_ai.tool.type") or attrs.get("tool.type") or
              ("mcp" if attrs.get("mcp.server.name") or attrs.get("mcp.method.name") else
               "openinference" if openinference_tool else "tool"))
    action = (attrs.get("tool.action") or attrs.get("mcp.method.name") or
              operation or "call")
    status = str(attrs.get("tool.result_status") or "").lower()
    if (span.get("status") == "ERROR" or attrs.get("error.type") or attrs.get("tool.error")
            or evidence['is_error']):
        result = "error"
    elif status in {"error", "failed", "failure"}:
        result = "error"
    elif status in {"success", "ok", "completed"} or span.get("status") == "OK":
        result = "success"
    else:
        result = "unknown"
    normalized = {
        "agent.activity.domain": str(domain),
        "agent.activity.action": str(action),
        "agent.activity.subject": tool_name,
        "agent.activity.result": result,
        "agent.activity.actor": str(attrs.get("gen_ai.agent.name") or attrs.get("agent.name") or ""),
    }
    native_opencode=(span.get('scope_name')=='observatory.opencode' and
                     span.get('service')=='opencode' and attrs.get('agent.runtime')=='OpenCode')
    current_native=(type(attrs.get('observatory.operation.capture_version')) is int and
                    attrs['observatory.operation.capture_version']==1)
    if native_opencode and not current_native:
        legacy=decode(attrs.get('agent.activity.detail'))
        if isinstance(legacy,dict) and str(domain).casefold()=='shell':
            if isinstance(legacy.get('command'),str):evidence['commands'].append(('opencode.command',legacy['command']))
            if 'exit_code' in legacy:evidence['exits'].append(('opencode.metadata.exit',legacy['exit_code']))
        evidence.update(input_clipped=True,output_clipped=True)
    if 'agent.activity.detail' in attrs and not (native_opencode and current_native):
        evidence['outputs'].append(('activity.detail','output',attrs['agent.activity.detail']))
    normalized.update({key:attrs[key] for key in attrs if key.startswith("agent.activity.")})
    row=_activity_row({**_span_activity_identity(span), **normalized}, span.get("end_unix_nano") or span.get("start_unix_nano"),
                         "span", span["span_id"], span["span_id"], span.get("service", "unknown"),
                         resource_attributes=span.get("resource_attributes"))
    if any(evidence[key] for key in ('inputs','commands','exits','outputs')):
        row.update(detail=evidence_detail(evidence),detail_role='operation_v1')
    from .operation_facts import normalize_operation_result
    return normalize_operation_result(row)


def _native_event_activity(span, event, index):
    """Expose useful runtime lifecycle events in the activity ledger safely."""
    if not isinstance(event, dict):
        return None
    name = str(event.get("name") or "")
    attrs = event.get("attributes") if isinstance(event.get("attributes"), dict) else {}
    mappings = {
        "github.copilot.hook.start": ("hook", "start", "started", "github.copilot.hook.type"),
        "github.copilot.hook.end": ("hook", "complete", "success", "github.copilot.hook.type"),
        "github.copilot.hook.error": ("hook", "fail", "error", "github.copilot.hook.type"),
        "github.copilot.skill.invoked": ("skill", "invoke", "observed", "github.copilot.skill.name"),
        "github.copilot.session.compaction_start": ("conversation", "compact", "started", "conversation history"),
        "github.copilot.session.compaction_complete": ("conversation", "compact", "observed", "conversation history"),
        "github.copilot.session.truncation": ("conversation", "truncate", "observed", "conversation history"),
        "github.copilot.session.shutdown": ("session", "shutdown", "observed", "github.copilot.shutdown_type"),
        "github.copilot.session.abort": ("session", "abort", "cancelled", "agent operation"),
        "exception": ("error", "raise", "error", "exception.type"),
    }
    mapping = mappings.get(name)
    if mapping is None:
        return None
    domain, action, result, subject_key = mapping
    if name.endswith("compaction_complete"):
        succeeded = attrs.get("github.copilot.success")
        result = "success" if succeeded is True or succeeded == "true" else "error" if succeeded is False or succeeded == "false" else "observed"
    subject = attrs.get(subject_key) if subject_key.startswith("github.") or subject_key == "exception.type" else subject_key
    if not subject:
        subject = subject_key if subject_key in {"conversation history", "agent operation"} else action
    detail = ""
    if name.endswith("session.truncation"):
        removed = []
        for key, label in (("github.copilot.tokens_removed", "tokens"),
                           ("github.copilot.messages_removed", "messages")):
            if attrs.get(key) is not None:
                removed.append(f"{attrs[key]} {label} removed")
        detail = ", ".join(removed)
    normalized = {"agent.activity.domain": domain, "agent.activity.action": action,
                  "agent.activity.subject": str(subject), "agent.activity.result": result}
    actor=attrs.get('gen_ai.agent.name') or attrs.get('agent.name')
    if actor:
        normalized["agent.activity.actor"] = str(actor)
    identity,resource=_event_activity_identity(span,attrs)
    if name=='exception' and isinstance(attrs.get('exception.message'),str) and attrs['exception.message']:
        from .operation_facts import attribute_evidence,evidence_detail
        evidence=attribute_evidence({})
        evidence['outputs']=[('event.exception','error',{'type':attrs.get('exception.type'),
                                                       'message':attrs['exception.message']})]
        detail=evidence_detail(evidence)
        normalized['observatory.operation.schema']=1
    return _activity_row({**identity, **normalized}, event.get("time_unix_nano") or span.get("start_unix_nano"),
                         "span", f"{span['span_id']}:event:{index}", span["span_id"],
                         span.get("service", "unknown"), detail,
                         resource)


def _span_activity_identity(span):
    attrs = span.get('attributes') or {}
    return {key: attrs[key] for key in (*SESSION_KEYS, 'agent.id', 'agent.runtime',
            'agent.namespace', 'agent.worker_id','agent.turn.id') if key in attrs}


def _event_activity_identity(span,event_attrs):
    """Explicit event identity claims override inherited alias families."""
    inherited=_span_activity_identity(span)
    resource=dict(span.get('resource_attributes') or {})
    parent=_agent_id_from_attributes(span.get('attributes') or {},resource,span.get('service'))
    claimed=any(key in event_attrs for key in ('agent.id','agent.runtime','agent.namespace'))
    candidate={**inherited,**event_attrs}
    if 'agent.id' in event_attrs:resource.pop('agent.id',None)
    owner=_agent_id_from_attributes(candidate,resource,span.get('service'))
    changed=claimed and (owner!=parent or any(not isinstance(event_attrs[key],str) or not event_attrs[key]
        for key in ('agent.id','agent.runtime','agent.namespace') if key in event_attrs))
    session_claim=any(key in event_attrs for key in SESSION_KEYS)
    parent_attrs=span.get('attributes') or {}
    parent_session=_activity_session(parent_attrs,resource)
    claims=[_session_value(event_attrs[key]) for key in SESSION_KEYS if key in event_attrs]
    event_session=claims[0] if claims and all(value is not None and value==claims[0] for value in claims) else None
    if changed or session_claim:
        for key in SESSION_KEYS:
            inherited.pop(key,None);resource.pop(key,None)
    if changed or session_claim and event_session!=parent_session:
        for key in ('agent.turn.id','agent.worker_id'):
            inherited.pop(key,None);resource.pop(key,None)
    # Only identity metadata is inherited. Command/result/input fields always
    # come from this exact event, never the containing span.
    identity={**inherited,**event_attrs}
    if session_claim and event_session is None:
        for key in SESSION_KEYS:identity.pop(key,None)
    return identity,resource


def _recorded_activity_agents(spans, logs=()):
    """Canonical recorded owners, including explicit owners on span events."""
    agents=set()
    for record in (*spans,*logs):
        attrs=record.get('attributes') or {};resource=record.get('resource_attributes') or {}
        agent=_agent_id_from_attributes(attrs,resource,record.get('service'))
        if agent:agents.add(agent)
    for span in spans:
        for event in span.get('events') or ():
            attrs=event.get('attributes') if isinstance(event,dict) else None
            if not isinstance(attrs,dict) or not any(key in attrs for key in ('agent.id','agent.runtime','agent.namespace')):continue
            identity,resource=_event_activity_identity(span,attrs)
            agent=_agent_id_from_attributes(identity,resource,span.get('service'))
            if agent:agents.add(agent)
    return agents


def _review_owner(spans, logs, activity, *, complete):
    """Conservative whole-trace allocation proof; missing identity stays unknown."""
    if not complete:return None
    owners=set()
    for record in (*spans,*logs):
        attrs=record.get('attributes') or {};resource=record.get('resource_attributes') or {}
        owner=_agent_id_from_attributes(attrs,resource,record.get('service'))
        session=_activity_session(attrs,resource)
        owners.add((record.get('service'),owner,session))
    owners.update((event.get('service'),event.get('agent_id'),event.get('session_id')) for event in activity)
    if len(owners)==1:
        producer,owner,session=next(iter(owners))
        if producer and owner and session:return dict(producer=producer,agent_id=owner,session_id=session)
    return None


def _activity_for(spans, logs):
    activity = []
    replacements={}
    from .operation_facts import supersedes_operation
    for span in spans:
        for index, event in enumerate(span["events"]):
            if not isinstance(event, dict) or event.get("name") != "agent.activity":
                native = _native_event_activity(span, event, index)
                if native is not None:
                    activity.append(native)
                continue
            event_attrs=event.get("attributes") if isinstance(event.get("attributes"),dict) else {}
            identity,resource=_event_activity_identity(span,event_attrs)
            row=_activity_row(identity,
                                          event.get("time_unix_nano") or span["start_unix_nano"],
                                          "span", f"{span['span_id']}:event:{index}", span["span_id"], span["service"],
                                          resource_attributes=resource)
            activity.append(row)
            replacements.setdefault((span.get('trace_id'),span['span_id']),[]).append(row)
    for log in logs:
        if log['event_name']!='agent.activity':continue
        row=_activity_row(log['attributes'],log['time_unix_nano'],'log',log['id'],
            log.get('span_id'),log['service'],log['body'],
            log.get('resource_attributes'))
        activity.append(row)
        replacements.setdefault((log.get('trace_id'),log.get('span_id')),[]).append(row)
    for span in spans:
        inferred=_tool_activity(span)
        if (inferred is not None and not inferred.get('detail_role') and not inferred.get('detail')
                and inferred.get('result')=='unknown'
                and (span.get('trace_id'),span['span_id']) in replacements):
            # A generic label with no operation/result facts adds no evidence
            # beside the explicit records. Typed fields always take the guarded
            # ownership/coverage path below.
            continue
        if inferred is not None and not any(supersedes_operation(inferred,row)
                for row in replacements.get((span.get('trace_id'),span['span_id']),())):
            activity.append(inferred)
    return sorted(activity, key=lambda item: (item["time_unix_nano"], item["source_id"]))


def _attrs(items):
    result = {}
    for item in items or []:
        result[item["key"]] = _value(item.get("value", {}))
    return result


def _value(value):
    if "arrayValue" in value:
        return [_value(x) for x in value["arrayValue"].get("values", [])]
    if "kvlistValue" in value:
        return _attrs(value["kvlistValue"].get("values", []))
    for key in ("stringValue", "intValue", "doubleValue", "boolValue", "bytesValue"):
        if key in value:
            v = value[key]
            return int(v) if key == "intValue" else v
    return None


def _normalize_openllmetry_mcp(attrs, span_name, scope_name):
    """Adapt OpenLLMetry's Python MCP client spans to the shared MCP fields."""
    if "opentelemetry.instrumentation.mcp" not in scope_name:
        return
    name = str(span_name)
    if name.endswith(".tool"):
        tool = attrs.get("traceloop.entity.name") or name[:-5]
        attrs.setdefault("rpc.system", "mcp")
        attrs.setdefault("mcp.method.name", "tools/call")
        attrs.setdefault("mcp.tool.name", tool)
        attrs.setdefault("gen_ai.tool.type", "MCPTool")
        attrs.setdefault("gen_ai.tool.name", tool)
        attrs.setdefault("tool.name", tool)
        if "traceloop.entity.input" in attrs:
            attrs.setdefault("gen_ai.tool.call.arguments", attrs["traceloop.entity.input"])
        if "traceloop.entity.output" in attrs:
            attrs.setdefault("gen_ai.tool.call.result", attrs["traceloop.entity.output"])
    elif name.endswith(".mcp"):
        attrs.setdefault("rpc.system", "mcp")
        attrs.setdefault("mcp.method.name", name[:-4])


def normalize_native(raw, service="agent-harness"):
    trace_id = _id(raw.get("trace_id"), TRACE_ID, "trace_id")
    span_id = _id(raw.get("span_id"), SPAN_ID, "span_id")
    parent = raw.get("parent_span_id")
    if parent:
        parent = _id(parent, SPAN_ID, "parent_span_id")
    start, end = int(raw["start_unix_nano"]), int(raw["end_unix_nano"])
    if start < 0 or end < start or end > 2**63 - 1:
        raise ValueError("invalid span timestamps")
    attrs = raw.get("attributes") or {}
    events = raw.get("events") or []
    links = raw.get("links") or []
    resource = raw.get("resource_attributes") or {}
    if not isinstance(attrs, dict) or not isinstance(events, list) or not isinstance(links, list) or not isinstance(resource, dict):
        raise ValueError("attributes/resource must be objects and events/links arrays")
    attrs = dict(attrs)
    name = str(raw["name"])
    scope_name = str(raw.get("scope_name") or "")
    _normalize_openllmetry_mcp(attrs, name, scope_name)
    normalized_links = []
    for link in links:
        normalized_links.append({"trace_id": _id(link.get("trace_id"), TRACE_ID, "link trace_id"),
                                 "span_id": _id(link.get("span_id"), SPAN_ID, "link span_id"),
                                 "attributes": link.get("attributes") or {}})
    return {"trace_id": trace_id, "span_id": span_id, "parent_span_id": parent,
            "name": name, "start_unix_nano": start,
            "end_unix_nano": end, "status": str(raw.get("status", "UNSET")),
            "service": service, "attributes": attrs, "events": events,
            "links": normalized_links, "resource_attributes": resource,
            "scope_name": scope_name}


def normalize_otlp(body):
    spans = []
    for group in body.get("resourceSpans", []):
        resource = _attrs(group.get("resource", {}).get("attributes"))
        service = str(resource.get("service.name") or "unknown")
        for scope in group.get("scopeSpans", []):
            for raw in scope.get("spans", []):
                status_code = int(raw.get("status", {}).get("code", 0))
                native = {
                    "trace_id": raw.get("traceId"), "span_id": raw.get("spanId"),
                    "parent_span_id": raw.get("parentSpanId") or None,
                    "name": raw.get("name", "unnamed"),
                    "start_unix_nano": raw.get("startTimeUnixNano"),
                    "end_unix_nano": raw.get("endTimeUnixNano"),
                    "status": {0: "UNSET", 1: "OK", 2: "ERROR"}.get(status_code, "UNSET"),
                    "attributes": _attrs(raw.get("attributes")),
                    "resource_attributes": resource,
                    "scope_name": scope.get("scope", {}).get("name", ""),
                    "events": [{"name": e.get("name", "event"),
                                "time_unix_nano": int(e.get("timeUnixNano", 0)),
                                "attributes": _attrs(e.get("attributes"))}
                               for e in raw.get("events", [])],
                    "links": [{"trace_id": link.get("traceId"),
                               "span_id": link.get("spanId"),
                               "attributes": _attrs(link.get("attributes"))}
                              for link in raw.get("links", [])],
                }
                spans.append(normalize_native(native, service))
    return spans


class IndexNotReady(RuntimeError):
    """A retryable read cannot certify its derived source snapshot yet."""
    def __init__(self, indexing, *, repair_traces=()):
        self.indexing = dict(indexing)
        self.repair_traces = tuple(repair_traces)
        super().__init__('History index is not ready')


class Store:
    def __init__(self, path, async_derived_refresh=False, workflow_patterns=None):
        self.path = str(path)
        from .read_connections import ReadConnections
        self._read_connections = ReadConnections(path)
        self.workflow_patterns = (os.environ.get("AGENTURM_WORKFLOW_PATTERNS", "0") == "1"
                                  if workflow_patterns is None else bool(workflow_patterns))
        self._async_derived_refresh = bool(async_derived_refresh)
        self._derived_condition = threading.Condition()
        # Refresh reads and cache writes must not straddle a retention delete.
        self._derived_lock = threading.RLock()
        # Coordinate local writer admission per transaction, never across the
        # history-wide derivation lock or its inter-chunk fairness sleeps.
        self._writer_gate = threading.RLock()
        self._derived_pending = {}
        self._derived_inflight = set()
        self._compat_cursor = ''
        self._derived_demand_until = 0.0
        self._derived_generation = 0
        self._derived_stopping = False
        self._derived_thread = None
        self.last_derived_error = None
        self._migration_stop=threading.Event()
        self._migration_thread=None
        self.migration_status={"ready":False,"stage":"Preparing indexed history","processed":0}
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        # SQLite otherwise creates the file using the process umask, exposing
        # captured content until the chmod at the end of initialization.
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            self.created_new=False
        else:
            self.created_new=True
            os.close(fd)
        os.chmod(self.path, 0o600)
        with self._connect() as db:
            # Readers bind ownership and content to one snapshot while native
            # ingestion continues; SQLite manages checkpointing and sidecars.
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS spans (
                    trace_id TEXT NOT NULL, span_id TEXT NOT NULL,
                    parent_span_id TEXT, name TEXT NOT NULL,
                    start_ns INTEGER NOT NULL, end_ns INTEGER NOT NULL,
                    status TEXT NOT NULL, service TEXT NOT NULL,
                    attributes TEXT NOT NULL, events TEXT NOT NULL,
                    links TEXT NOT NULL DEFAULT '[]',
                    resource_attributes TEXT NOT NULL DEFAULT '{}',
                    scope_name TEXT NOT NULL DEFAULT '',
                    agent_id TEXT,
                    PRIMARY KEY (trace_id, span_id));
                CREATE INDEX IF NOT EXISTS spans_time ON spans(end_ns DESC);
                CREATE INDEX IF NOT EXISTS spans_service_time ON spans(service,end_ns);
                CREATE INDEX IF NOT EXISTS spans_trace_start ON spans(trace_id,start_ns,span_id);
                CREATE TABLE IF NOT EXISTS agent_connections (
                    source_id TEXT PRIMARY KEY, service TEXT NOT NULL, runtime TEXT NOT NULL,
                    integrations TEXT NOT NULL, capture_content INTEGER NOT NULL,
                    process_id INTEGER, started_ns INTEGER NOT NULL, last_seen_ns INTEGER NOT NULL,
                    state TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS progress (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, trace_id TEXT NOT NULL,
                    time_ns INTEGER NOT NULL, stage TEXT NOT NULL,
                    message TEXT NOT NULL, percent REAL, session_id TEXT, service TEXT);
                CREATE INDEX IF NOT EXISTS progress_trace ON progress(trace_id, time_ns);
                CREATE TABLE IF NOT EXISTS logs (
                    digest TEXT PRIMARY KEY, trace_id TEXT, span_id TEXT,
                    time_ns INTEGER NOT NULL, service TEXT NOT NULL,
                    severity_number INTEGER NOT NULL, severity_text TEXT NOT NULL,
                    event_name TEXT NOT NULL, body TEXT NOT NULL,
                    attributes TEXT NOT NULL, resource_attributes TEXT NOT NULL,
                    scope_name TEXT NOT NULL, agent_id TEXT);
                CREATE INDEX IF NOT EXISTS logs_trace ON logs(trace_id,time_ns);
                CREATE INDEX IF NOT EXISTS logs_time ON logs(time_ns DESC);
                CREATE INDEX IF NOT EXISTS logs_native_record ON logs(json_extract(attributes,'$."observatory.record_id"'))
                    WHERE scope_name='observatory.local_agents';
                CREATE TABLE IF NOT EXISTS metric_points (
                    digest TEXT PRIMARY KEY, time_ns INTEGER NOT NULL,
                    start_ns INTEGER NOT NULL, service TEXT NOT NULL,
                    name TEXT NOT NULL, description TEXT NOT NULL,
                    unit TEXT NOT NULL, kind TEXT NOT NULL,
                    temporality INTEGER NOT NULL, attributes TEXT NOT NULL,
                    resource_attributes TEXT NOT NULL, scope_name TEXT NOT NULL,
                    data TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS metric_points_time ON metric_points(time_ns DESC);
                CREATE INDEX IF NOT EXISTS metric_points_name_service_time ON metric_points(name,service,time_ns DESC);
                CREATE TABLE IF NOT EXISTS outcomes (
                    trace_id TEXT PRIMARY KEY, task_id TEXT NOT NULL,
                    passed INTEGER NOT NULL, scores TEXT NOT NULL,
                    error TEXT NOT NULL, provider_model TEXT NOT NULL,
                    source TEXT NOT NULL, details TEXT NOT NULL,
                    ingested_ns INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS trace_activity (
                    trace_id TEXT PRIMARY KEY, last_ns INTEGER NOT NULL);
                CREATE INDEX IF NOT EXISTS trace_activity_time ON trace_activity(last_ns DESC,trace_id DESC);
                CREATE TABLE IF NOT EXISTS endpoints (
                    endpoint_id TEXT PRIMARY KEY, identity_key TEXT NOT NULL,
                    identity_value TEXT NOT NULL, resource_attributes TEXT NOT NULL,
                    last_ns INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS endpoint_services (
                    endpoint_id TEXT NOT NULL, service TEXT NOT NULL, last_ns INTEGER NOT NULL,
                    PRIMARY KEY(endpoint_id,service));
                CREATE TABLE IF NOT EXISTS endpoint_traces (
                    endpoint_id TEXT NOT NULL, trace_id TEXT NOT NULL, last_ns INTEGER NOT NULL,
                    PRIMARY KEY(endpoint_id,trace_id));
                CREATE INDEX IF NOT EXISTS endpoint_traces_recent ON endpoint_traces(endpoint_id,last_ns DESC);
                CREATE TABLE IF NOT EXISTS trace_summaries (
                    trace_id TEXT PRIMARY KEY, session_id TEXT, summary_json TEXT NOT NULL,
                    activity_json TEXT NOT NULL DEFAULT '[]', agent_id TEXT);
                CREATE TABLE IF NOT EXISTS finding_cache (
                    finding_id TEXT PRIMARY KEY, trace_id TEXT NOT NULL,
                    time_ns INTEGER NOT NULL, finding_json TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS finding_cache_trace ON finding_cache(trace_id,time_ns DESC);
                CREATE INDEX IF NOT EXISTS finding_cache_time ON finding_cache(time_ns DESC,finding_id DESC);
                CREATE INDEX IF NOT EXISTS finding_cache_group ON finding_cache(
                    json_extract(finding_json,'$.kind'),json_extract(finding_json,'$.title'),
                    json_extract(finding_json,'$.detail'),json_extract(finding_json,'$.severity'),trace_id);
                CREATE TABLE IF NOT EXISTS schema_meta (
                    key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS agent_nodes (
                    agent_id TEXT PRIMARY KEY,
                    runtime TEXT NOT NULL,
                    source_namespace TEXT NOT NULL,
                    source_id TEXT,
                    native_session_id TEXT,
                    native_worker_id TEXT NOT NULL DEFAULT '',
                    parent_agent_id TEXT,
                    relationship_kind TEXT NOT NULL,
                    relationship_state TEXT NOT NULL,
                    relationship_provenance TEXT NOT NULL,
                    parent_claims TEXT NOT NULL DEFAULT '[]',
                    discovery_state TEXT NOT NULL,
                    coverage TEXT NOT NULL,
                    is_review INTEGER NOT NULL DEFAULT 0,
                    observed_ns INTEGER NOT NULL,
                    first_seen_ns INTEGER NOT NULL,
                    updated_ns INTEGER NOT NULL);
                CREATE INDEX IF NOT EXISTS agent_nodes_parent ON agent_nodes(parent_agent_id);
                CREATE INDEX IF NOT EXISTS agent_nodes_native
                    ON agent_nodes(runtime,source_namespace,native_session_id,native_worker_id);
                CREATE INDEX IF NOT EXISTS agent_nodes_observed
                    ON agent_nodes(observed_ns DESC,agent_id);
                CREATE TABLE IF NOT EXISTS agent_identity (
                    runtime TEXT NOT NULL,
                    source_namespace TEXT NOT NULL,
                    native_session_id TEXT NOT NULL,
                    native_worker_id TEXT NOT NULL DEFAULT '',
                    agent_id TEXT NOT NULL,
                    updated_ns INTEGER NOT NULL,
                    PRIMARY KEY(runtime,source_namespace,native_session_id,native_worker_id));
            """)
            finding_columns={row[1] for row in db.execute('PRAGMA table_info(finding_cache)')}
            for name in ('agent_id','session_id','producer','group_key'):
                if name not in finding_columns:db.execute(f'ALTER TABLE finding_cache ADD COLUMN {name} TEXT')
            db.execute('UPDATE finding_cache SET group_key=finding_id WHERE group_key IS NULL')
            db.execute('CREATE INDEX IF NOT EXISTS finding_owner_time_v1 ON finding_cache(agent_id,time_ns DESC,finding_id DESC)')
            db.execute('CREATE INDEX IF NOT EXISTS finding_group_owner_v1 ON finding_cache(group_key,agent_id,producer,session_id,trace_id)')
            db.execute('CREATE TABLE IF NOT EXISTS finding_dirty_v1(trace_id TEXT PRIMARY KEY)')
            for operation in ('INSERT','UPDATE'):
                db.execute(f"""CREATE TRIGGER IF NOT EXISTS finding_legacy_key_{operation.lower()}_v1 AFTER {operation} ON finding_cache
                    WHEN NEW.group_key IS NULL BEGIN
                    UPDATE finding_cache SET group_key=NEW.finding_id WHERE finding_id=NEW.finding_id; END""")
            for table in ('spans','logs','outcomes','progress'):
                for operation in ('INSERT','UPDATE','DELETE'):
                    alias='OLD' if operation=='DELETE' else 'NEW'
                    statements=f"INSERT INTO finding_dirty_v1 SELECT {alias}.trace_id WHERE {alias}.trace_id IS NOT NULL ON CONFLICT DO NOTHING; DELETE FROM finding_cache WHERE trace_id={alias}.trace_id;"
                    if operation=='UPDATE':statements+="INSERT INTO finding_dirty_v1 SELECT OLD.trace_id WHERE OLD.trace_id IS NOT NULL ON CONFLICT DO NOTHING; DELETE FROM finding_cache WHERE trace_id=OLD.trace_id;"
                    db.execute(f"""CREATE TRIGGER IF NOT EXISTS finding_{table}_{operation.lower()}_v1 AFTER {operation} ON {table}
                        BEGIN {statements} END""")
            from .storage_derived import initialize
            initialize(db)
            session_expr = _session_sql_expression()
            db.execute(f"CREATE INDEX IF NOT EXISTS logs_session_time "
                       f"ON logs ({session_expr},time_ns DESC,digest DESC) "
                       f"WHERE {session_expr} IS NOT NULL")
            columns = {row[1] for row in db.execute("PRAGMA table_info(spans)")}
            for name, declaration in (("links", "TEXT NOT NULL DEFAULT '[]'"),
                                      ("resource_attributes", "TEXT NOT NULL DEFAULT '{}'"),
                                      ("scope_name", "TEXT NOT NULL DEFAULT ''"),
                                      ("agent_id", "TEXT")):
                if name not in columns:
                    db.execute(f"ALTER TABLE spans ADD COLUMN {name} {declaration}")
            db.execute('CREATE INDEX IF NOT EXISTS spans_source ON spans(service,json_extract(resource_attributes,\'$."observatory.source_id"\'))')
            log_columns = {row[1] for row in db.execute("PRAGMA table_info(logs)")}
            if "agent_id" not in log_columns:
                db.execute("ALTER TABLE logs ADD COLUMN agent_id TEXT")
            db.execute("CREATE INDEX IF NOT EXISTS logs_agent_id ON logs(agent_id,time_ns DESC)")
            db.execute("INSERT OR IGNORE INTO schema_meta(key,value) VALUES('receiver_id',?)", (uuid.uuid4().hex,))
            self.receiver_id = db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            info = os.stat(self.path)
            self._receiver_file_identity = (info.st_dev, info.st_ino)
            agent_node_columns = {row[1] for row in db.execute("PRAGMA table_info(agent_nodes)")}
            if "is_review" not in agent_node_columns:
                db.execute("ALTER TABLE agent_nodes ADD COLUMN is_review INTEGER NOT NULL DEFAULT 0")
            for table, name in (("progress", "session_id"), ("progress", "service"), ("trace_summaries", "session_id")):
                table_columns = {row[1] for row in db.execute(f"PRAGMA table_info({table})")}
                if name not in table_columns:
                    db.execute(f"ALTER TABLE {table} ADD COLUMN {name} TEXT")
            summary_columns = {row[1] for row in db.execute("PRAGMA table_info(trace_summaries)")}
            for name, declaration in (("activity_json", "TEXT NOT NULL DEFAULT '[]'"),
                                      ("error_refs_json", "TEXT NOT NULL DEFAULT '[]'"),
                                      ("agent_id", "TEXT")):
                if name not in summary_columns:
                    db.execute(f"ALTER TABLE trace_summaries ADD COLUMN {name} {declaration}")
            db.execute("CREATE INDEX IF NOT EXISTS trace_summaries_session ON trace_summaries(session_id,trace_id)")
            db.execute("CREATE INDEX IF NOT EXISTS trace_summaries_agent ON trace_summaries(agent_id,trace_id)")
            db.execute("CREATE INDEX IF NOT EXISTS spans_agent_id ON spans(agent_id)")
            if not db.execute("SELECT 1 FROM schema_meta WHERE key='agent_hierarchy_v1'").fetchone():
                db.execute("""UPDATE spans SET agent_id=json_extract(attributes,'$."agent.id"')
                    WHERE agent_id IS NULL
                      AND json_extract(attributes,'$."agent.id"') GLOB 'ag1_[0-9a-f]*'""")
                db.execute("""UPDATE logs SET agent_id=json_extract(attributes,'$."agent.id"')
                    WHERE agent_id IS NULL
                      AND json_extract(attributes,'$."agent.id"') GLOB 'ag1_[0-9a-f]*'""")
                db.execute("""UPDATE trace_summaries SET agent_id=json_extract(summary_json,'$.agent_id')
                    WHERE agent_id IS NULL
                      AND json_extract(summary_json,'$.agent_id') GLOB 'ag1_[0-9a-f]*'""")
                db.execute("""UPDATE trace_summaries SET agent_id=(
                        SELECT s.agent_id FROM spans s WHERE s.trace_id=trace_summaries.trace_id
                          AND s.agent_id IS NOT NULL LIMIT 1)
                    WHERE agent_id IS NULL""")
                db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('agent_hierarchy_v1','1')")
            if not db.execute("SELECT 1 FROM schema_meta WHERE key='trace_activity_v1'").fetchone():
                db.execute("""INSERT INTO trace_activity(trace_id,last_ns)
                    SELECT trace_id,MAX(activity_ns) FROM (
                        SELECT trace_id,end_ns AS activity_ns FROM spans
                        UNION ALL SELECT trace_id,time_ns FROM progress
                        UNION ALL SELECT trace_id,time_ns FROM logs WHERE trace_id IS NOT NULL
                        UNION ALL SELECT trace_id,ingested_ns FROM outcomes
                    ) GROUP BY trace_id""")
                db.execute("INSERT INTO schema_meta(key,value) VALUES('trace_activity_v1','1')")
        os.chmod(self.path, 0o600)
        from .storage_activity import initialize as initialize_activity, drain
        with self._connect() as db:
            from .native_policy import initialize as initialize_native_policy
            initialize_native_policy(db)
            initialize_activity(db)
            available=db.execute("SELECT value FROM schema_meta WHERE key='investigation_available_v1'").fetchone()
            self.investigation_index_v1 = bool(available and available[0]=='1')
            if self.workflow_patterns and not db.execute("SELECT 1 FROM schema_meta WHERE key='workflow_patterns_v2'").fetchone():
                # Replace legacy heuristic observations before exposing them
                # under the stricter operation/usage contract. The durable
                # bounded repair also handles interrupted upgrades.
                db.execute('''INSERT OR IGNORE INTO finding_dirty_v1 SELECT trace_id FROM finding_cache
                    WHERE COALESCE(json_extract(finding_json,'$.workflow_pattern'),0)=1''')
                db.execute('''INSERT OR IGNORE INTO finding_dirty_v1 SELECT trace_id FROM trace_activity
                    ORDER BY last_ns DESC,trace_id DESC LIMIT 20''')
                db.execute("INSERT INTO schema_meta VALUES('workflow_patterns_v2','1')")
            from .storage_native_lifecycle import initialize as initialize_native_lifecycle
            initialize_native_lifecycle(db)
        with self._connect() as db:
            migrated=db.execute("SELECT 1 FROM schema_meta WHERE key='native_internal_policy_v1'").fetchone()
            legacy_sources=[] if migrated else [row[0] for row in db.execute('''SELECT DISTINCT source_id FROM (
                SELECT json_extract(resource_attributes,'$."observatory.source_id"') AS source_id FROM spans WHERE service='codex-review'
                UNION SELECT json_extract(resource_attributes,'$."observatory.source_id"') FROM logs WHERE service='codex-review')
                WHERE source_id IS NOT NULL''') if isinstance(row[0],str) and TRACE_ID.fullmatch(row[0])]
        for source in legacy_sources:self.redact_internal_source(source)
        if not migrated:
            with self._connect() as db:db.execute("INSERT OR REPLACE INTO schema_meta VALUES('native_internal_policy_v1','1')")
        if self._async_derived_refresh:
            self._migration_thread=threading.Thread(target=self._finish_migration,name='agenturm-history-migration',daemon=True)
            self._migration_thread.start()
        else:self._finish_migration()
        if self.workflow_patterns:
            with self._connect() as db:
                recent = [r[0] for r in db.execute("SELECT trace_id FROM trace_activity ORDER BY last_ns DESC LIMIT 20")]
            self._refresh_summaries(recent)
        if self._async_derived_refresh:
            self._derived_thread = threading.Thread(target=self._derived_refresh_worker,
                                                   name="observatory-derived-refresh", daemon=True)
            self._derived_thread.start()

    def _finish_migration(self):
        from .storage_activity import drain
        try:
            while not self._migration_stop.is_set():
                with self._write_db() as db:
                    count=drain(db)
                processed=self.migration_status['processed']+count
                self.migration_status={**self.migration_status,'processed':processed,'stage':f'Indexing source records · {processed:,} indexed'}
                if not count:break
                if self._migration_stop.wait(.025):return
            if self._migration_stop.is_set():return
            self.migration_status={**self.migration_status,'stage':'Refreshing ownership and run summaries'}
            self._backfill_summaries()
            if self._migration_stop.is_set():return
            self._backfill_task_outcomes()
            self._backfill_endpoints()
            # A prior process may have stopped after invalidating findings even
            # when the versioned historical backfill was already complete.
            while not self._migration_stop.is_set():
                with self._read() as db:
                    pending=[row[0] for row in db.execute('SELECT trace_id FROM finding_dirty_v1 ORDER BY trace_id LIMIT 16')]
                if not pending:break
                self.migration_status={**self.migration_status,'stage':'Refreshing incoming finding evidence'}
                self._refresh_summaries(pending, require_dirty=True)
                if self._migration_stop.wait(.025):return
            if self._migration_stop.is_set():return
            self.migration_status={**self.migration_status,'ready':True,'stage':'Ready'}
            # Compatibility queue for another local receiver version writing
            # this database. Work remains bounded and source transactions queue
            # invalidations, so a reader never serves stale materialized text.
            if self._async_derived_refresh:
                while not self._migration_stop.wait(.25):
                    self._drain_external_activity()

        except Exception as exc:
            self.last_derived_error=str(exc)
            self.migration_status={**self.migration_status,'ready':False,'stage':'History migration failed; restart to resume','error':str(exc)}
            self._notify_derived_progress()
            if not self._async_derived_refresh:raise

    def _drain_external_activity(self):
        # The usual empty probe must not repeatedly rebuild SQLite connection
        # state. Release the read lease before trying to acquire a writer;
        # another receiver may already have consumed the observed work.
        with self._read() as db:
            dirty=db.execute('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM finding_dirty_v1 UNION ALL SELECT 1 FROM native_lifecycle_dirty_v1'+
                (' UNION ALL SELECT 1 FROM investigation_dirty_v1' if self.investigation_index_v1 else '')+' LIMIT 1').fetchone()
        if not dirty:return 0
        from .storage_activity import drain
        try:
            with self._writer_gate,self._connect() as db:
                db.execute('BEGIN IMMEDIATE')
                count=drain(db,limit=200)
                traces=self._compat_traces(db)
            if traces:self._refresh_summaries(traces, require_dirty=True,defer_local=True)
            return count  # Preserve the Activity drain-count contract; derived repair is additional.
        finally:
            self._notify_derived_progress()

    def _locally_owned(self, trace_id):
        with self._derived_condition:
            thread=self._derived_thread
            return bool(self._async_derived_refresh and not self._derived_stopping and thread is not None
                and thread.is_alive() and (trace_id in self._derived_pending or trace_id in self._derived_inflight))

    def _compat_traces(self, db):
        # A bounded scheduling cursor avoids starving an external dirty trace
        # behind a hot prefix of locally owned jobs. It proves no source state.
        rows=db.execute('SELECT trace_id FROM finding_dirty_v1 WHERE trace_id>? ORDER BY trace_id LIMIT 64',
            (self._compat_cursor,)).fetchall()
        if not rows and self._compat_cursor:
            self._compat_cursor=''
            rows=db.execute('SELECT trace_id FROM finding_dirty_v1 ORDER BY trace_id LIMIT 64').fetchall()
        traces=[]
        for row in rows:
            trace_id=row[0];self._compat_cursor=trace_id
            if not self._locally_owned(trace_id):traces.append(trace_id)
            if len(traces)==16:break
        return traces

    def index_status(self):
        state=dict(self.migration_status)
        with self._read() as db:
            dirty=bool(db.execute('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM finding_dirty_v1 UNION ALL SELECT 1 FROM native_lifecycle_dirty_v1'+
                (' UNION ALL SELECT 1 FROM investigation_dirty_v1' if self.investigation_index_v1 else '')+' LIMIT 1').fetchone())
        if dirty:
            state['ready']=False
            if not state.get('error'):state['stage']='Indexing incoming source changes'
        return state

    def _incoming_status(self, deadline):
        """Bounded metadata only; never keep this connection while waiting."""
        state=dict(self.migration_status)
        if (not state.get('ready') or state.get('error') or self.last_derived_error or
                self._derived_stopping or not self._async_derived_refresh):
            if self.last_derived_error:
                state.update(error=self.last_derived_error,stage='Incoming derivation failed')
            elif self._derived_stopping:state['stage']='Receiver is stopping'
            state['ready']=False
            return state,False
        remaining=deadline-time.monotonic()
        if remaining<=0:return None,False
        path=Path(self.path).absolute()
        db=None
        try:
            before=path.stat();identity=(before.st_dev,before.st_ino)
            db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=remaining)
            db.set_progress_handler(lambda:int(time.monotonic()>=deadline),1000)
            def query(sql):
                remaining=deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('Incoming catch-up budget expired')
                # A successful earlier statement must not reset a later busy
                # handler to the original 75 ms budget.
                db.execute('PRAGMA busy_timeout='+str(int(remaining*1000)))
                return db.execute(sql).fetchone()
            db.execute('BEGIN')
            complete=query("SELECT 1 FROM schema_meta WHERE key='trace_derived_v15' AND value='1'")
            dirty=query('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM finding_dirty_v1 UNION ALL SELECT 1 FROM native_lifecycle_dirty_v1'+
                (' UNION ALL SELECT 1 FROM investigation_dirty_v1' if self.investigation_index_v1 else '')+' LIMIT 1')
            after=path.stat()
            if identity!=(after.st_dev,after.st_ino):
                state.update(ready=False,stage='Receiver identity changed during incoming catch-up')
                return state,False
            if time.monotonic()>=deadline:return None,False
            if not complete:
                state.update(ready=False,stage='Refreshing ownership and run summaries')
                return state,False
            if dirty:state.update(ready=False,stage='Indexing incoming source changes')
            return state,True
        except (OSError,sqlite3.Error,TimeoutError):
            state.update(ready=False,stage='Incoming index readiness is unavailable')
            return state,False
        finally:
            if db is not None:db.close()

    def catch_up_incoming(self, indexing):
        """One 75 ms demand budget; a fresh guarded read remains authoritative."""
        deadline=time.monotonic()+.075
        fallback=dict(indexing)
        if fallback.get('ready'):return fallback
        if (not self._async_derived_refresh or not self.migration_status.get('ready') or
                self.migration_status.get('error') or self.last_derived_error or self._derived_stopping or
                self._derived_thread is None or not self._derived_thread.is_alive()):return fallback
        status,eligible=self._incoming_status(deadline)
        if status is not None:fallback=status
        if not eligible or fallback.get('ready'):return fallback
        if not self._derived_condition.acquire(timeout=max(0,deadline-time.monotonic())):return fallback
        try:
            generation=self._derived_generation
            self._derived_demand_until=max(self._derived_demand_until,deadline)
            self._derived_condition.notify_all()
        finally:self._derived_condition.release()
        while time.monotonic()<deadline:
            status,eligible=self._incoming_status(deadline)
            if status is not None:fallback=status
            if not eligible or fallback.get('ready'):return fallback
            if not self._derived_condition.acquire(timeout=max(0,deadline-time.monotonic())):return fallback
            try:
                if self._derived_generation!=generation:
                    generation=self._derived_generation
                    continue
                remaining=deadline-time.monotonic()
                if remaining<=0:break
                self._derived_condition.wait(timeout=remaining)
            finally:self._derived_condition.release()
        return fallback

    def _notify_derived_progress(self):
        with self._derived_condition:
            self._derived_generation+=1
            self._derived_condition.notify_all()

    def _require_index_ready(self, db):
        # Certify this exact read snapshot, not an earlier HTTP preflight.
        # Cached readers use Activity and run/Findings projections; unrelated
        # FTS/native-inventory work retains its own independent readiness gate.
        if not db.in_transaction:
            raise RuntimeError('Derived readiness requires a read transaction')
        state=dict(self.migration_status)
        complete=db.execute("SELECT 1 FROM schema_meta WHERE key='trace_derived_v15' AND value='1'").fetchone()
        dirty=db.execute('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM finding_dirty_v1 LIMIT 1').fetchone()
        if state.get('error'):
            state['ready']=False
        elif not complete:
            state.update(ready=False,stage='Refreshing ownership and run summaries')
        elif dirty:
            state.update(ready=False,stage='Indexing incoming source changes')
        if not state.get('ready'):raise IndexNotReady(state)

    def receiver_namespace(self):
        """Keep health cheap; refresh identity after atomic database replacement."""
        info = os.stat(self.path)
        identity = (info.st_dev, info.st_ino)
        if identity != getattr(self, '_receiver_file_identity', None):
            with self._connect() as db:
                row = db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()
            if not row:
                raise ValueError('Receiver database has no stable identity')
            self.receiver_id = row[0]
            self._receiver_file_identity = identity
        return self.receiver_id

    @contextmanager
    def _connect(self):
        """Yield a SQLite connection and always release its file handle.

        ``sqlite3.Connection``'s context manager commits or rolls back a
        transaction, but deliberately does not close the connection. Store
        operations open a connection per query, so leaving closure to garbage
        collection can exhaust file descriptors in a long-running receiver.
        """
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _read(self):
        return self._read_connections.read()

    @contextmanager
    def _read_db(self, db=None):
        if db is not None:
            yield db
        else:
            with self._connect() as connection:yield connection

    @contextmanager
    def _write_db(self, db=None):
        """Own writer admission before SQLite, or inherit a caller's transaction.

        Borrowed connections may already own SQLite's writer. Acquiring the
        local gate here would invert gate -> SQLite ordering; their caller
        owns admission, commit and rollback instead.
        """
        if db is not None:
            yield db
        else:
            with self._writer_gate,self._connect() as connection:
                connection.execute('BEGIN IMMEDIATE')
                yield connection

    def _derived_snapshot(self, read, *, _db=None):
        if _db is not None:
            self._require_index_ready(_db)
            return read(_db)
        for attempt in range(2):
            try:
                with self._connect() as db:
                    db.execute('BEGIN')
                    self._require_index_ready(db)
                    return read(db)
            except IndexNotReady as exc:
                if not exc.repair_traces:raise
                # Never acquire a writer while retaining the old read snapshot.
                if self._async_derived_refresh:
                    self._refresh_after_write(exc.repair_traces)
                    raise
                if attempt:raise
                self._refresh_summaries(exc.repair_traces)

    @staticmethod
    def _trace_source_exists(db, trace_id):
        return bool(db.execute('SELECT 1 FROM spans WHERE trace_id=? UNION ALL '
            'SELECT 1 FROM logs WHERE trace_id=? UNION ALL '
            'SELECT 1 FROM progress WHERE trace_id=? UNION ALL '
            'SELECT 1 FROM outcomes WHERE trace_id=? LIMIT 1', (trace_id,)*4).fetchone())

    def register_connection(self, record):
        source_id = _id(record.get("source_id"), TRACE_ID, "source_id")
        service = record.get("service")
        integrations = record.get("integrations")
        runtime = record.get("runtime")
        state = record.get("state", "running")
        capture_content = record.get("capture_content", False)
        process_id = record.get("process_id")
        if not isinstance(service, str) or not 1 <= len(service.strip()) <= 128:
            raise ValueError("service must contain 1 to 128 characters")
        if not isinstance(runtime, str) or not 1 <= len(runtime) <= 80:
            raise ValueError("invalid runtime")
        if (not isinstance(integrations, list) or not 1 <= len(integrations) <= 20 or
                any(not isinstance(item, str) or not 1 <= len(item) <= 80 for item in integrations)):
            raise ValueError("invalid integrations")
        if state not in {"running", "stopped"} or not isinstance(capture_content, bool):
            raise ValueError("invalid connection state")
        if process_id is not None and (isinstance(process_id, bool) or not isinstance(process_id, int) or not 0 < process_id < 2**31):
            raise ValueError("invalid process_id")
        now = time.time_ns()
        with self._write_db() as db:
            db.execute("""INSERT INTO agent_connections VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_id) DO UPDATE SET last_seen_ns=excluded.last_seen_ns,
                state=excluded.state,service=excluded.service,runtime=excluded.runtime,integrations=excluded.integrations,
                capture_content=excluded.capture_content,process_id=excluded.process_id""", (source_id, service.strip(), runtime,
                json.dumps(integrations), int(capture_content), process_id, now, now, state))

    @staticmethod
    def _bump_hierarchy_revision(db):
        row = db.execute("SELECT value FROM schema_meta WHERE key='agent_hierarchy_revision'").fetchone()
        try:
            current = int(row[0]) if row else 0
        except (TypeError, ValueError, OverflowError):
            current = 0
        db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('agent_hierarchy_revision',?)",
                   (str(current + 1),))

    def upsert_agent_nodes(self, nodes, *, _db=None):
        """Idempotently persist normalized identities and bounded evidence.

        The canonical child identity is the conflict key.  A later observation
        cannot silently overwrite an existing confirmed parent with a different
        one: both bounded claims are retained and the node is marked conflicted.
        Raw arguments, environments, and transcript content are never stored.
        """
        nodes = list(nodes or ())
        if len(nodes) > 5000:
            raise ValueError("too many agent nodes")
        now = time.time_ns()
        changed = 0
        with self._write_db(_db) as db:
            for raw in nodes:
                try:
                    node = normalize_node(raw)
                except (ValueError, TypeError):
                    continue
                agent_id = node["agent_id"]
                runtime = str(node.get("runtime") or "unknown")[:80]
                namespace = str(node.get("source_namespace") or runtime)[:256]
                source_id = str(node.get("source_id") or "")[:128] or None
                native_session = str(node.get("native_session_id") or "")[:256] or None
                native_worker = str(node.get("native_worker_id") or "")[:256]
                existing = db.execute("SELECT * FROM agent_nodes WHERE agent_id=?", (agent_id,)).fetchone()
                row = self._merge_agent_node(existing, node, runtime, namespace, source_id,
                                              native_session, native_worker, now)
                structural = (existing is None or
                              existing["parent_agent_id"] != row[6] or
                              existing["relationship_kind"] != row[7] or
                              existing["relationship_state"] != row[8] or
                              existing["relationship_provenance"] != row[9] or
                              existing["parent_claims"] != row[10] or
                              existing["discovery_state"] != row[11] or
                              existing["is_review"] != row[13] or
                              existing["source_namespace"] != namespace or
                              existing["native_session_id"] != native_session or
                              existing["native_worker_id"] != native_worker)
                db.execute("""INSERT INTO agent_nodes
                    (agent_id,runtime,source_namespace,source_id,native_session_id,native_worker_id,
                     parent_agent_id,relationship_kind,relationship_state,relationship_provenance,
                     parent_claims,discovery_state,coverage,is_review,observed_ns,first_seen_ns,updated_ns)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(agent_id) DO UPDATE SET
                     runtime=excluded.runtime,source_namespace=excluded.source_namespace,
                     source_id=excluded.source_id,native_session_id=excluded.native_session_id,
                     native_worker_id=excluded.native_worker_id,parent_agent_id=excluded.parent_agent_id,
                     relationship_kind=excluded.relationship_kind,relationship_state=excluded.relationship_state,
                     relationship_provenance=excluded.relationship_provenance,parent_claims=excluded.parent_claims,
                     discovery_state=excluded.discovery_state,coverage=excluded.coverage,
                     is_review=excluded.is_review,
                     observed_ns=excluded.observed_ns,updated_ns=excluded.updated_ns""", row)
                changed += int(structural)
                if structural:
                    self._bump_hierarchy_revision(db)
                if native_session:
                    identity_ns = (int(node.get("observed_ns") or 0) or now)
                    db.execute("""INSERT INTO agent_identity
                        (runtime,source_namespace,native_session_id,native_worker_id,agent_id,updated_ns)
                        VALUES(?,?,?,?,?,?)
                        ON CONFLICT(runtime,source_namespace,native_session_id,native_worker_id)
                        DO UPDATE SET agent_id=excluded.agent_id,
                          updated_ns=MAX(updated_ns,excluded.updated_ns)""",
                        (runtime, namespace, native_session, native_worker, agent_id, identity_ns))
        return changed

    @staticmethod
    def _merge_agent_node(existing, node, runtime, namespace, source_id, native_session,
                          native_worker, now):
        claims = []
        if existing:
            try:
                claims = json.loads(existing["parent_claims"] or "[]")
            except (TypeError, ValueError):
                claims = []
        claims = [claim for claim in claims if isinstance(claim, dict)][-4:]
        new_parent = node.get("parent_agent_id")
        new_state = node.get("relationship_state") or "unresolved"
        new_kind = node.get("relationship_kind") or "unknown"
        new_provenance = node.get("relationship_provenance") or ""
        if new_parent and new_state == "confirmed":
            claims.append({"parent_agent_id": new_parent, "provenance": new_provenance,
                           "observed_ns": int(node.get("observed_ns") or 0)})
        parent = new_parent
        state = new_state
        kind = new_kind
        relationship_provenance = new_provenance
        discovery = node.get("discovery_state") or "observed"
        coverage = node.get("coverage") or "unknown"
        observed_ns = int(node.get("observed_ns") or 0)
        first_seen = min(now, existing["first_seen_ns"]) if existing else now
        if existing:
            old_parent = existing["parent_agent_id"]
            old_state = existing["relationship_state"]
            old_kind = existing["relationship_kind"]
            old_discovery = existing["discovery_state"]
            old_coverage = existing["coverage"]
            old_observed = int(existing["observed_ns"] or 0)
            old_provenance = existing["relationship_provenance"] or ""
            discovery = "observed" if "observed" in {old_discovery, discovery} else "announced"
            if old_discovery == "observed" and node.get("discovery_state") != "observed":
                # A stale announcement does not downgrade observed coverage.
                coverage = old_coverage
            elif discovery == "observed":
                # Coverage describes the latest observed window; a recovered
                # reader may upgrade partial/unknown, and a new schema error may
                # downgrade it.  It never changes the identity or edge.
                coverage = node.get("coverage") or coverage
            else:
                coverage = "unknown"
            observed_ns = max(old_observed, observed_ns)
            source_id = source_id or existing["source_id"]
            native_session = native_session or existing["native_session_id"]
            if existing["relationship_state"] in {"conflicted", "invalid"}:
                state = existing["relationship_state"]
                parent = None
                kind = old_kind
                relationship_provenance = old_provenance
            elif new_state in {"conflicted", "invalid"}:
                state = new_state
                parent = None if new_state in {"conflicted", "invalid"} else parent
                relationship_provenance = new_provenance
            elif (old_state == "confirmed" and old_parent and new_state == "confirmed" and
                  new_parent and old_parent != new_parent):
                state = "conflicted"
                parent = None
                relationship_provenance = (
                    f"conflicting parents: {old_parent} vs {new_parent}; " +
                    (old_provenance or new_provenance))[:512]
                kind = "delegated"
            elif old_state == "confirmed" and old_parent and not (new_state == "confirmed" and new_parent):
                # An unresolved/announced observation must not erase an exact claim.
                parent, state, kind = old_parent, "confirmed", old_kind
                relationship_provenance = old_provenance
            elif new_state == "confirmed" and new_parent:
                parent, state, kind = new_parent, "confirmed", new_kind
            elif old_state == "confirmed" and new_state != "confirmed":
                parent, state, kind = old_parent, "confirmed", old_kind
                relationship_provenance = old_provenance
            elif old_state == "unresolved" and new_state == "unresolved":
                parent, state, kind = old_parent, old_state, old_kind
            if existing["discovery_state"] == "observed":
                discovery = "observed"
        # Deduplicate claims by parent while retaining the newest provenance.
        unique = []
        for claim in claims:
            parent_claim = claim.get("parent_agent_id")
            if not isinstance(parent_claim, str) or not AGENT_ID.fullmatch(parent_claim):
                continue
            existing_claim = next((item for item in unique
                                   if item.get("parent_agent_id") == parent_claim), None)
            if existing_claim:
                existing_claim.update(claim)
            else:
                unique.append(dict(claim))
        unique = unique[-4:]
        review = (int(bool(node.get("review"))) if "review" in node
                  else (existing["is_review"] if existing else 0))
        return (node["agent_id"], runtime, namespace, source_id, native_session, native_worker,
                parent, kind, state, str(relationship_provenance)[:512],
                json.dumps(unique, separators=(",", ":")), discovery, coverage,
                review, observed_ns, first_seen, now)

    def hierarchy_revision(self, *, _db=None):
        with (self._read() if _db is None else nullcontext(_db)) as db:
            row = db.execute("SELECT value FROM schema_meta WHERE key='agent_hierarchy_revision'").fetchone()
        return "h" + (str(row[0]) if row else "0")

    def agent_nodes(self, limit=2000, include_reviews=True, *, _db=None):
        limit = max(1, min(10000, int(limit)))
        where = "" if include_reviews else " WHERE is_review=0"
        with (self._connect() if _db is None else nullcontext(_db)) as db:
            rows = db.execute("SELECT * FROM agent_nodes" + where +
                              " ORDER BY observed_ns DESC,agent_id LIMIT ?",
                              (limit,)).fetchall()
            known = {row["agent_id"] for row in rows}
        nodes = []
        for row in rows:
            try:
                claims = json.loads(row["parent_claims"] or "[]")
            except (TypeError, ValueError):
                claims = []
            nodes.append({
                "agent_id": row["agent_id"], "runtime": row["runtime"],
                "source_namespace": row["source_namespace"], "source_id": row["source_id"],
                "native_session_id": row["native_session_id"],
                "native_worker_id": row["native_worker_id"] or None,
                "parent_agent_id": row["parent_agent_id"],
                "relationship_kind": row["relationship_kind"],
                "relationship_state": row["relationship_state"],
                "relationship_provenance": row["relationship_provenance"],
                "parent_claims": claims if isinstance(claims, list) else [],
                "parent_available": bool(row["parent_agent_id"] in known),
                "discovery_state": row["discovery_state"], "coverage": row["coverage"],
                "review": bool(row["is_review"]),
                "observed_ns": row["observed_ns"], "first_seen_ns": row["first_seen_ns"],
                "updated_ns": row["updated_ns"]})
        return nodes

    def agent_node_contexts(self, agent_ids):
        """Exact, bounded identity lookup for parents outside the live window."""
        ids = []
        for agent_id in agent_ids or ():
            if isinstance(agent_id, str) and AGENT_ID.fullmatch(agent_id) and agent_id not in ids:
                ids.append(agent_id)
        ids = ids[:100]
        if not ids:
            return {}
        marks = ','.join('?' for _ in ids)
        with self._connect() as db:
            rows = db.execute(f"SELECT * FROM agent_nodes WHERE agent_id IN ({marks})",
                              ids).fetchall()
        result = {}
        for row in rows:
            result[row["agent_id"]] = {
                "agent_id": row["agent_id"], "runtime": row["runtime"],
                "relationship_state": row["relationship_state"],
                "relationship_kind": row["relationship_kind"],
                "relationship_provenance": row["relationship_provenance"],
                "discovery_state": row["discovery_state"],
                "observed_ns": row["observed_ns"], "retained": True,
                "outside_current_window": True,
            }
        return result

    def resolve_agent_scope(self, agent_id, include_subagents=True, *, _db=None):
        """Resolve canonical subtree membership for evidence queries.

        This is the only backend scope resolver.  It never guesses from service
        names, projects, or path prefixes.
        """
        if not isinstance(agent_id, str) or not AGENT_ID.fullmatch(agent_id):
            raise ValueError("invalid agent_id")
        if not isinstance(include_subagents, bool):
            raise ValueError("invalid subtree scope")
        nodes = self.agent_nodes(limit=10000,_db=_db)
        graph = HierarchyGraph(nodes)
        ids = graph.scope_ids(agent_id, include_subagents=include_subagents)
        by_id = {node["agent_id"]: node for node in nodes}
        session_ids = []
        for item in ids:
            node = by_id.get(item) or {}
            # A shared Claude/Codex root session ID must never pull sibling
            # workers into an exact evidence scope.  Worker IDs win when present.
            native = node.get("native_worker_id") or node.get("native_session_id")
            if native and native not in session_ids:
                session_ids.append(native)
        return {"agent_id": agent_id, "agent_ids": ids, "session_ids": session_ids,
                "include_subagents": include_subagents,
                "revision": self.hierarchy_revision(_db=_db),
                "nodes": len(ids), "known": agent_id in by_id,
                "coverage": "partial" if not ids or len(nodes) >= 10000 else "complete"}

    def redact_internal_source(self, source_id):
        """Keep internal approval reviews as metadata, including older captures."""
        source_id = _id(source_id, TRACE_ID, "source_id")
        from .native_policy import internal_review_attrs, internal_review_events
        affected = set()
        with self._source_write() as refresh:
            with self._connect() as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('INSERT OR REPLACE INTO native_source_policy_v1 VALUES(?,1)',(source_id,))
                rows = db.execute('''SELECT digest,trace_id,attributes FROM logs
                    WHERE json_extract(resource_attributes,'$."observatory.source_id"')=?''', (source_id,)).fetchall()
                for row in rows:
                    attrs = internal_review_attrs(json.loads(row["attributes"]))
                    db.execute("UPDATE logs SET body=?,attributes=?,service='codex-review' WHERE digest=?",
                               (json.dumps(""), json.dumps(attrs), row["digest"]))
                    if row["trace_id"]:
                        affected.add(row["trace_id"])
                rows = db.execute('''SELECT trace_id,span_id,attributes,name,events FROM spans
                    WHERE json_extract(resource_attributes,'$."observatory.source_id"')=?''', (source_id,)).fetchall()
                for row in rows:
                    attrs = internal_review_attrs(json.loads(row["attributes"]))
                    if row["name"] == "agent.run":
                        attrs["agent.task"] = "Approval review"
                    db.execute("UPDATE spans SET attributes=?,events=?,links='[]',name=?,service='codex-review' WHERE trace_id=? AND span_id=?",
                               (json.dumps(attrs),json.dumps(internal_review_events(json.loads(row['events']))),
                                'agent.run' if row['name']=='agent.run' else 'Approval review',row["trace_id"],row["span_id"]))
                    affected.add(row["trace_id"])
                # Raw source policy and derived content invalidate together; a
                # delayed/failed async rebuild cannot expose the previous prompt.
                db.executemany('DELETE FROM trace_summaries WHERE trace_id=?',((trace,) for trace in affected))
                db.executemany('DELETE FROM finding_cache WHERE trace_id=?',((trace,) for trace in affected))
            refresh.update(affected)

    def connections(self):
        now = time.time_ns()
        with self._read() as db:
            # Match the indexed TEXT expression, including numeric source IDs.
            rows = db.execute("""SELECT c.*,(SELECT COUNT(*) FROM spans s
                WHERE s.service=c.service AND
                CAST(json_extract(s.resource_attributes,'$."observatory.source_id"') AS TEXT)=c.source_id) AS span_count
                FROM agent_connections c
                ORDER BY c.last_seen_ns DESC LIMIT 50""").fetchall()
        return [{"source_id": r["source_id"], "service": r["service"], "runtime": r["runtime"],
                 "integrations": json.loads(r["integrations"]), "capture_content": bool(r["capture_content"]),
                 "process_id": r["process_id"], "started_ns": r["started_ns"], "last_seen_ns": r["last_seen_ns"],
                 "state": "offline" if r["state"] == "running" and now-r["last_seen_ns"]>35_000_000_000 else r["state"],
                 "span_count": r["span_count"]} for r in rows]

    def _backfill_summaries(self):
        with self._connect() as db:
            complete = db.execute("""SELECT 1 FROM schema_meta WHERE key='trace_derived_v15'
                AND EXISTS (SELECT 1 FROM schema_meta WHERE key='trace_derived_v11')""").fetchone()
        if not complete:
            with self._connect() as db:
                saved=db.execute("SELECT value FROM schema_meta WHERE key='trace_derived_v15_cursor'").fetchone()
            before=json.loads(saved[0]) if saved else None
            with self._connect() as db:
                progress=db.execute("SELECT value FROM schema_meta WHERE key='trace_derived_v15_done'").fetchone()
                total=db.execute('SELECT COUNT(*) FROM trace_activity').fetchone()[0]
            done=int(progress[0]) if progress else 0
            while True:
                if self._migration_stop.is_set():return
                sql = "SELECT trace_id,last_ns FROM trace_activity"
                params = []
                if before:
                    sql += " WHERE last_ns < ? OR (last_ns = ? AND trace_id < ?)"
                    params.extend((before[0], before[0], before[1]))
                sql += " ORDER BY last_ns DESC,trace_id DESC LIMIT 100"
                with self._connect() as db:
                    rows = db.execute(sql, params).fetchall()
                if not rows:
                    break
                self._refresh_summaries(row["trace_id"] for row in rows)
                before = (rows[-1]["last_ns"], rows[-1]["trace_id"])
                done+=len(rows)
                self.migration_status={**self.migration_status,'runs_refreshed':done,'total_runs':total,
                    'stage':f'Refreshing run evidence · {done:,}/{total:,} runs'}
                with self._write_db() as db:
                    db.execute("INSERT OR REPLACE INTO schema_meta VALUES('trace_derived_v15_cursor',?)",(json.dumps(before),))
                    db.execute("INSERT OR REPLACE INTO schema_meta VALUES('trace_derived_v15_done',?)",(str(done),))
                if len(rows) < 100:
                    break
        if not complete:
            with self._write_db() as db:
                db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('trace_derived_v15','1')")
                db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('trace_derived_v14','1')")
                db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('trace_derived_v13','1')")
                db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('trace_derived_v11','1')")
                db.execute("DELETE FROM schema_meta WHERE key IN ('trace_derived_v15_cursor','trace_derived_v15_done')")

    def _backfill_task_outcomes(self):
        # Upgrade only lifecycle metadata. Replaying all historical model/tool
        # spans here would make the first launch after an upgrade expensive.
        from .storage_derived import task_outcome_for_trace
        with self._connect() as db:
            if db.execute("SELECT 1 FROM schema_meta WHERE key='task_outcome_v1'").fetchone():
                return
        before = ''
        while not self._migration_stop.is_set():
            with self._write_db() as db:
                rows = db.execute("SELECT trace_id FROM trace_summaries WHERE trace_id>? "
                                  "ORDER BY trace_id LIMIT 100", (before,)).fetchall()
                if not rows:
                    db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('task_outcome_v1','1')")
                    return
                for row in rows:
                    state, stamp = task_outcome_for_trace(db, row['trace_id'])
                    db.execute("UPDATE trace_summaries SET summary_json=json_set(summary_json, "
                               "'$.task_outcome',?,'$.task_outcome_ns',?) WHERE trace_id=?",
                               (state, stamp, row['trace_id']))
                before = rows[-1]['trace_id']
            if self._migration_stop.wait(.025):return

    def _backfill_endpoints(self):
        with self._connect() as db:
            complete = db.execute("SELECT 1 FROM schema_meta WHERE key='endpoint_inventory_v1'").fetchone()
        if complete:
            return
        for table,stamp,has_trace in (('spans','end_ns',True),('logs','time_ns',True),
                                    ('metric_points','time_ns',False)):
            before=None
            group='trace_id,service,resource_attributes' if has_trace else 'service,resource_attributes'
            trace='trace_id' if has_trace else 'NULL AS trace_id'
            while not self._migration_stop.is_set():
                where='';params=[]
                if before is not None:
                    if has_trace and before[0] is None:
                        # SQLite sorts NULL trace IDs first; tuple comparison
                        # alone cannot advance out of this real log bucket.
                        where=' WHERE trace_id IS NOT NULL OR (trace_id IS NULL AND (service,resource_attributes)>(?,?))'
                        params=list(before[1:])
                    else:
                        where=' WHERE ('+group+')>('+','.join('?'for _ in before)+')'
                        params=list(before)
                with self._write_db() as db:
                    rows=db.execute(f'SELECT {trace},service,resource_attributes,MAX({stamp}) AS time_unix_nano '
                        f'FROM {table}'+where+f' GROUP BY {group} ORDER BY {group} LIMIT 500',params).fetchall()
                    if not rows:break
                    records = [{"trace_id": row["trace_id"], "service": row["service"],
                                "resource_attributes": json.loads(row["resource_attributes"]),
                                "time_unix_nano": row["time_unix_nano"]}
                               for row in rows]
                    self._update_endpoints(db, records)
                    last=rows[-1]
                    before=((last['trace_id'],last['service'],last['resource_attributes']) if has_trace else
                            (last['service'],last['resource_attributes']))
                # No live source cursor/read snapshot or writer lease crosses
                # admission of the next page or a native/health writer.
                if self._migration_stop.wait(.025):return
            if self._migration_stop.is_set():return
        with self._write_db() as db:
            db.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('endpoint_inventory_v1','1')")

    def _refresh_summaries(self, trace_ids, *, require_dirty=False, defer_local=False):
        with self._derived_lock:
            self._refresh_summaries_locked(trace_ids, require_dirty=require_dirty,defer_local=defer_local)

    def _refresh_summaries_locked(self, trace_ids, *, require_dirty=False, defer_local=False):
        active_pattern_runs = set()
        if self.workflow_patterns:
            with self._connect() as db:
                active_pattern_runs = {r[0] for r in db.execute(
                    "SELECT trace_id FROM trace_activity ORDER BY last_ns DESC,trace_id DESC LIMIT 20")}
        trace_ids = sorted(set(trace_ids))
        # Amortize connection/fsync costs without holding SQLite's writer lock
        # over an entire history rebuild. Each bounded chunk remains atomic
        # against ingestion, pruning and other receiver processes.
        for offset in range(0,len(trace_ids),16):
            with self._writer_gate,self._connect() as db:
                db.execute("BEGIN IMMEDIATE")
                receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
                for trace_id in trace_ids[offset:offset+16]:
                    # Recheck ownership after actual writer admission; raw
                    # commits publish their local queue before releasing it.
                    if defer_local and self._locally_owned(trace_id):continue
                    # Another local/background receiver may already have
                    # repaired this job while we waited for its writer. A
                    # missing cache is still repair work even without a dirty
                    # row (the read-side repair path can enqueue it directly).
                    if require_dirty and not db.execute('SELECT 1 FROM finding_dirty_v1 WHERE trace_id=? UNION ALL '
                            'SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM trace_summaries WHERE trace_id=?) LIMIT 1',
                            (trace_id,trace_id)).fetchone():continue
                    self._publish_trace_summary(db,trace_id,receiver,workflow_patterns=trace_id in active_pattern_runs)
            if offset+16<len(trace_ids):
                # SQLite's busy handler is not a fair writer queue. Give a
                # waiting native collector/other receiver a real acquisition
                # window instead of immediately reacquiring through history.
                time.sleep(.025)

    def _publish_trace_summary(self,db,trace_id,receiver,*,workflow_patterns=False):
        from .storage_derived import derive_trace
        db.execute('DELETE FROM finding_dirty_v1 WHERE trace_id=?',(trace_id,))
        from .operation_preparation import OperationPreparation
        with OperationPreparation() as preparation:
            derived = (derive_trace(db, trace_id, workflow_patterns=True,operation_preparation=preparation)
                       if workflow_patterns else derive_trace(db,trace_id,operation_preparation=preparation))
            if derived is None:
                db.execute("DELETE FROM trace_summaries WHERE trace_id=?", (trace_id,))
                db.execute("DELETE FROM finding_cache WHERE trace_id=?", (trace_id,))
                return
            summary, activity, findings, timestamp = derived
            from .error_reminders import trace_error_references
            errors = trace_error_references(activity,trace_id,receiver=receiver,operation_preparation=preparation)
        db.execute("INSERT INTO trace_summaries(trace_id,session_id,summary_json,activity_json,agent_id,error_refs_json) VALUES(?,?,?,?,?,?) "
                   "ON CONFLICT(trace_id) DO UPDATE SET session_id=excluded.session_id,"
                   "summary_json=excluded.summary_json,activity_json=excluded.activity_json,"
                   "agent_id=excluded.agent_id,error_refs_json=excluded.error_refs_json",
                   (trace_id, summary.get("session_id"), json.dumps(summary, separators=(",", ":")),
                    json.dumps(activity, separators=(",", ":")), summary.get("agent_id"),
                    json.dumps(errors, separators=(",", ":"))))
        db.execute("DELETE FROM finding_cache WHERE trace_id=?", (trace_id,))
        db.executemany("INSERT INTO finding_cache(finding_id,trace_id,time_ns,finding_json,agent_id,session_id,producer,group_key) VALUES(?,?,?,?,?,?,?,?)",
                       ((item["id"], trace_id, item.get("time_unix_nano") or timestamp,
                         json.dumps(item, separators=(",", ":")),item.get("agent_id"),item.get("session_id"),
                         item.get("producer"),item.get("group_key") or item["id"])
                        for item in findings))

    def _publish_native_summaries(self,db,records):
        """Publish small prepared native updates in their source transaction.

        Never acquire the derived lock here: the caller already owns SQLite's
        writer. Larger/cold/pattern-enabled work keeps normal async admission.
        """
        state=self.migration_status
        if (not self._async_derived_refresh or not records or len(records)>64 or
                not state.get('ready')or state.get('error')or self.last_derived_error or
                self._derived_stopping or self._migration_stop.is_set()or self.workflow_patterns or
                any(r.get('scope_name')not in {'observatory.local_agents','observatory.opencode'}for r in records)):
            return False
        traces=sorted({r.get('trace_id')for r in records if r.get('trace_id')})
        if not traces or len(traces)>4 or any(not r.get('trace_id')for r in records):return False
        markers=('trace_derived_v15','activity_sources_v2','activity_operation_facts_v2','live_stats_v3')
        actual=dict(db.execute("SELECT key,value FROM schema_meta WHERE key IN (?,?,?,?)",markers))
        if any(actual.get(key)!='1'for key in markers):return False
        payloads={'spans':('name','service','scope_name','attributes','events','links','resource_attributes'),
            'logs':('service','scope_name','event_name','severity_text','attributes','body','resource_attributes'),
            'progress':('stage','message','session_id','service'),
            'outcomes':('task_id','scores','error','provider_model','source','details')}
        selects=['SELECT bytes FROM (SELECT '+
            '+'.join('COALESCE(length(CAST('+column+' AS BLOB)),0)'for column in columns)+
            ' AS bytes FROM '+table+' WHERE trace_id=? LIMIT 257)'for table,columns in payloads.items()]
        total=0
        for trace in traces:
            sizes=[r[0]for r in db.execute(' UNION ALL '.join(selects)+' LIMIT 257',(trace,)*4)]
            size=sum(sizes);total+=size
            if len(sizes)>256 or size>512*1024 or total>1024*1024:return False
        db.execute('SAVEPOINT native_summary_publication')
        try:
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            for trace in traces:self._publish_trace_summary(db,trace,receiver)
        except Exception as exc:
            # Preserve accepted source and its invalidation, then let the
            # existing worker retry. Never expose partially published totals.
            db.execute('ROLLBACK TO native_summary_publication')
            db.execute('RELEASE native_summary_publication')
            self.last_derived_error=str(exc)
            return False
        db.execute('RELEASE native_summary_publication')
        return True

    @contextmanager
    def _source_write(self):
        """Fence accepted source commit through async job publication.

        Queue admission never derives. Synchronous fallback must run after
        releasing this gate, preserving derived-lock -> writer-gate ordering.
        """
        traces=set()
        with self._writer_gate:
            yield traces
            queued=self._queue_derived(traces)
        if traces and not queued:self._refresh_after_write(traces)

    def _queue_derived(self, trace_ids):
        trace_ids=set(trace_ids)
        if not trace_ids:return False
        with self._derived_condition:
            thread=self._derived_thread
            if (not self._async_derived_refresh or self._derived_stopping or thread is None or not thread.is_alive()):
                return False
            now=time.monotonic()
            for trace_id in trace_ids:
                pending=self._derived_pending.get(trace_id)
                self._derived_pending[trace_id]=(pending[0] if pending else now,now,pending[2] if pending else 0)
            self._derived_condition.notify()
        return True

    def _refresh_after_write(self, trace_ids):
        trace_ids=set(trace_ids)
        if trace_ids and not self._queue_derived(trace_ids):self._refresh_summaries(trace_ids)

    def _derived_refresh_worker(self):
        quiet_period = 0.25
        max_delay = 1.0
        while True:
            ready=[];pending={};backlog=False
            try:
                with self._derived_condition:
                    while not self._derived_pending and not self._derived_stopping:
                        self._derived_condition.wait()
                    if self._derived_stopping and not self._derived_pending:return
                    now=time.monotonic()
                    if not self._derived_stopping and now<self._derived_demand_until:
                        eligible=iter(self._derived_pending)
                        self._derived_demand_until=0.0
                    else:
                        eligible=(trace_id for trace_id,(first,last,_) in self._derived_pending.items()
                            if self._derived_stopping or now-last>=quiet_period or now-first>=max_delay)
                    ready=heapq.nsmallest(16,eligible,key=lambda trace:(self._derived_pending[trace][0],trace))
                    if not ready:
                        wait_for=min(min(quiet_period-(now-last),max_delay-(now-first))
                            for first,last,_ in self._derived_pending.values())
                        self._derived_condition.wait(timeout=max(0.01,wait_for))
                        continue
                    pending={trace_id:self._derived_pending.pop(trace_id) for trace_id in ready}
                    self._derived_inflight.update(ready)
                self._refresh_summaries(ready,require_dirty=True)
                self.last_derived_error=None
            except Exception as exc:
                self.last_derived_error=str(exc)
                if not ready:raise
                if not self._derived_stopping:
                    now=time.monotonic()
                    with self._derived_condition:
                        for trace_id,(first,_,attempts) in pending.items():
                            if attempts<4 and trace_id not in self._derived_pending:
                                self._derived_pending[trace_id]=(first,now,attempts+1)
                        self._derived_condition.notify()
            finally:
                if ready:
                    with self._derived_condition:
                        self._derived_inflight.difference_update(ready)
                        backlog=bool(self._derived_pending) and not self._derived_stopping
                    self._notify_derived_progress()
            if backlog:time.sleep(.025)

    def close(self):
        try:self._close_workers()
        finally:self._read_connections.close()

    def _close_workers(self):
        self._migration_stop.set()
        if self._migration_thread and self._migration_thread.is_alive():self._migration_thread.join(timeout=15)
        if self._derived_thread is None:
            return
        with self._derived_condition:
            self._derived_stopping = True
            self._derived_condition.notify_all()
        # Ctrl-C can land while waiting for the derived-refresh worker to
        # drain its bounded queue; the stop flag is set, so keep draining
        # instead of leaking a traceback through run_cockpit's finally block.
        deadline = time.monotonic() + 15
        while self._derived_thread.is_alive() and time.monotonic() < deadline:
            try:
                self._derived_thread.join(timeout=min(1, max(0, deadline - time.monotonic())))
            except KeyboardInterrupt:
                continue
        self._derived_thread = None

    def _finding_logs(self, trace_id):
        with self._connect() as db:
            rows = db.execute("SELECT digest,trace_id,time_ns,severity_number,body,event_name,attributes FROM logs "
                              "WHERE trace_id=? "
                              "ORDER BY time_ns",
                              (trace_id,)).fetchall()
        return [{"id": row["digest"], "trace_id": row["trace_id"],
                 "time_unix_nano": row["time_ns"], "severity_number": row["severity_number"],
                 "body": json.loads(row["body"]), "event_name": row["event_name"],
                 "attributes": json.loads(row["attributes"])} for row in rows]

    @staticmethod
    def _update_endpoints(db, records):
        endpoints = {}
        services = {}
        traces = {}
        for record in records:
            resource = record.get("resource_attributes") or {}
            identity = _endpoint_identity(resource)
            if identity is None:
                continue
            identity_key, identity_value = identity
            endpoint_id = hashlib.sha256(f"{identity_key}\0{identity_value}".encode()).hexdigest()[:32]
            timestamp = int(record.get("end_unix_nano") or record.get("time_unix_nano") or
                            record.get("start_unix_nano") or time.time_ns())
            attributes = {key: value for key, value in resource.items()
                          if key in ENDPOINT_RESOURCE_KEYS and isinstance(value, (str, int, float, bool))}
            current = endpoints.get(endpoint_id)
            if current is None or timestamp >= current[3]:
                endpoints[endpoint_id] = (endpoint_id, identity_key, identity_value,
                                          timestamp, json.dumps(attributes, separators=(",", ":")))
            service = str(record.get("service") or "unknown")
            services[(endpoint_id, service)] = max(timestamp, services.get((endpoint_id, service), 0))
            trace_id = record.get("trace_id")
            if trace_id:
                traces[(endpoint_id, str(trace_id))] = max(timestamp, traces.get((endpoint_id, str(trace_id)), 0))
        if endpoints:
            db.executemany("""INSERT INTO endpoints(endpoint_id,identity_key,identity_value,last_ns,resource_attributes)
                VALUES(?,?,?,?,?) ON CONFLICT(endpoint_id) DO UPDATE SET
                last_ns=MAX(last_ns,excluded.last_ns),
                resource_attributes=CASE WHEN excluded.last_ns>=last_ns
                    THEN excluded.resource_attributes ELSE resource_attributes END""",
                [(key, identity_key, identity_value, last_ns, attrs)
                 for key, identity_key, identity_value, last_ns, attrs in endpoints.values()])
            db.executemany("""INSERT INTO endpoint_services(endpoint_id,service,last_ns) VALUES(?,?,?)
                ON CONFLICT(endpoint_id,service) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
                [(endpoint_id, service, last_ns)
                 for (endpoint_id, service), last_ns in services.items()])
            db.executemany("""INSERT INTO endpoint_traces(endpoint_id,trace_id,last_ns) VALUES(?,?,?)
                ON CONFLICT(endpoint_id,trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
                [(endpoint_id, trace_id, last_ns)
                 for (endpoint_id, trace_id), last_ns in traces.items()])

    def endpoints(self, limit=100):
        if not 1 <= int(limit) <= 500:
            raise ValueError("limit must be between 1 and 500")
        with self._connect() as db:
            rows = db.execute("""SELECT e.*,
                (SELECT COUNT(*) FROM endpoint_traces t WHERE t.endpoint_id=e.endpoint_id) AS trace_count,
                (SELECT trace_id FROM endpoint_traces t WHERE t.endpoint_id=e.endpoint_id
                    ORDER BY last_ns DESC,trace_id DESC LIMIT 1) AS latest_trace_id
                FROM endpoints e ORDER BY e.last_ns DESC,e.endpoint_id LIMIT ?""", (int(limit),)).fetchall()
            endpoint_ids = [row["endpoint_id"] for row in rows]
            services = (db.execute("SELECT endpoint_id,service FROM endpoint_services WHERE endpoint_id IN (" +
                                   ",".join("?" for _ in endpoint_ids) + ") ORDER BY service", endpoint_ids).fetchall()
                        if endpoint_ids else [])
        service_map = {}
        for row in services:
            service_map.setdefault(row["endpoint_id"], []).append(row["service"])
        result = []
        for row in rows:
            attrs = json.loads(row["resource_attributes"])
            result.append({"endpoint_id": row["endpoint_id"],
                           "name": attrs.get("host.name") or attrs.get("device.id") or row["identity_value"],
                           "identity_key": row["identity_key"],
                           "identity_value": row["identity_value"],
                           "os_type": attrs.get("os.type") or attrs.get("os.name") or "",
                           "os_version": attrs.get("os.version") or "",
                           "architecture": attrs.get("host.arch") or "",
                           "user": attrs.get("user.name") or attrs.get("user.id") or "",
                           "environment": attrs.get("deployment.environment.name") or "",
                           "cloud_region": attrs.get("cloud.region") or "",
                           "services": service_map.get(row["endpoint_id"], []),
                           "trace_count": row["trace_count"],
                           "latest_trace_id": row["latest_trace_id"],
                           "last_seen_unix_nano": row["last_ns"]})
        return result

    def usage_series(self, days=7, step="day", service=None, session_id=None):
        days = int(days)
        if not 1 <= days <= 90:
            raise ValueError("days must be between 1 and 90")
        if step not in {"hour", "day"}:
            raise ValueError("step must be hour or day")
        step_ns = 3_600_000_000_000 if step == "hour" else 86_400_000_000_000
        now_ns = time.time_ns()
        cutoff_ns = now_ns - days * 86_400_000_000_000
        first_bucket = cutoff_ns // step_ns * step_ns
        last_bucket = now_ns // step_ns * step_ns
        buckets = {bucket: {"start_unix_nano": bucket, "runs": 0, "errors": 0,
                            "input_tokens": 0, "output_tokens": 0,
                            "cache_read_input_tokens": 0, "cache_write_input_tokens": 0,
                            "reasoning_output_tokens": 0,
                            "log_events": 0, "log_usage_events": 0, "log_errors": 0,
                            "input_tokens_reported": False, "output_tokens_reported": False,
                            "cache_read_input_tokens_reported": False,
                            "cache_write_input_tokens_reported": False,
                            "reasoning_output_tokens_reported": False,
                            "known_cost_usd": 0.0, "unknown_cost_runs": 0, "usage_complete": True}
                   for bucket in range(first_bucket, last_bucket + 1, step_ns)}
        with self._connect() as db:
            db.execute('BEGIN')
            self._require_index_ready(db)
            summary_filters = ["a.last_ns>=?"]
            summary_params = [cutoff_ns]
            if session_id:
                summary_filters.append("s.session_id=?")
                summary_params.append(session_id)
            rows = db.execute("""SELECT s.summary_json FROM trace_summaries s
                JOIN trace_activity a USING(trace_id) WHERE """ + " AND ".join(summary_filters),
                summary_params).fetchall()
            session_expr = _session_sql_expression("l")
            def json_values(keys):
                return [f"json_extract(l.attributes,'$.\"{key}\"')" for key in keys]
            def json_present(keys):
                return " OR ".join(f"json_type(l.attributes,'$.\"{key}\"') IS NOT NULL" for key in keys)
            input_expr = "COALESCE(" + ",".join(json_values(INPUT_TOKEN_KEYS)) + ",0)"
            output_expr = "COALESCE(" + ",".join(json_values(OUTPUT_TOKEN_KEYS)) + ",0)"
            usage_presence = " OR ".join(f"({json_present(keys)})" for keys in (
                INPUT_TOKEN_KEYS, OUTPUT_TOKEN_KEYS, *TOKEN_BREAKDOWN_KEYS.values()))
            breakdown_select = []
            for field, keys in TOKEN_BREAKDOWN_KEYS.items():
                expressions = json_values(keys)
                breakdown_select.extend((
                    f"COALESCE(SUM(MAX(0,CAST(COALESCE({','.join(expressions)},0) AS INTEGER))),0) AS {field}",
                    f"MAX(CASE WHEN {json_present(keys)} THEN 1 ELSE 0 END) AS {field}_reported",
                ))
            log_service_filter = " AND l.service=?" if service else ""
            log_session_filter = f" AND {session_expr}=?" if session_id else ""
            log_params = [step_ns, step_ns, cutoff_ns, now_ns]
            if service:
                log_params.append(service)
            if session_id:
                log_params.append(session_id)
            log_rows = db.execute(f"""SELECT CAST(l.time_ns / ? AS INTEGER) * ? AS bucket,
                    COUNT(*) AS log_events,
                    SUM(CASE WHEN l.severity_number>=17 OR lower(COALESCE(
                        json_extract(l.attributes,'$.\"agent.activity.result\"'),''))
                        IN ('error','failed','denied','blocked') THEN 1 ELSE 0 END) AS log_errors,
                    SUM(CASE WHEN {usage_presence} THEN 1 ELSE 0 END) AS log_usage_events,
                    COALESCE(SUM(MAX(0,CAST({input_expr} AS INTEGER))),0) AS input_tokens,
                    COALESCE(SUM(MAX(0,CAST({output_expr} AS INTEGER))),0) AS output_tokens,
                    MAX(CASE WHEN {json_present(INPUT_TOKEN_KEYS)} THEN 1 ELSE 0 END) AS input_tokens_reported,
                    MAX(CASE WHEN {json_present(OUTPUT_TOKEN_KEYS)} THEN 1 ELSE 0 END) AS output_tokens_reported,
                    {','.join(breakdown_select)}
                FROM logs l WHERE l.event_name='agent.activity'
                    AND l.time_ns>=? AND l.time_ns<=?
                    AND {session_expr} IS NOT NULL
                    AND NOT EXISTS (SELECT 1 FROM trace_summaries s WHERE s.session_id={session_expr})
                    {log_service_filter}{log_session_filter} GROUP BY bucket""", log_params).fetchall()
        for row in rows:
            summary = json.loads(row["summary_json"])
            if service and service not in summary.get("services", []):
                continue
            end_ns = int(summary.get("end_unix_nano") or 0)
            if end_ns < cutoff_ns or end_ns > now_ns:
                continue
            bucket = end_ns // step_ns * step_ns
            item = buckets.get(bucket)
            if item is None:
                continue
            item["runs"] += 1
            item["usage_complete"] &= summary.get("usage_complete", True)
            item["errors"] += summary.get("status") in {"ERROR", "FAILED"}
            item["input_tokens"] += int(summary.get("input_tokens") or 0)
            item["output_tokens"] += int(summary.get("output_tokens") or 0)
            item["cache_read_input_tokens"] += int(summary.get("cache_read_input_tokens") or 0)
            item["cache_write_input_tokens"] += int(summary.get("cache_write_input_tokens") or 0)
            item["reasoning_output_tokens"] += int(summary.get("reasoning_output_tokens") or 0)
            for field in ("cache_read_input_tokens", "cache_write_input_tokens", "reasoning_output_tokens"):
                item[f"{field}_reported"] |= bool(summary.get(f"{field}_reported"))
            item["input_tokens_reported"] |= bool(summary.get("input_tokens_reported"))
            item["output_tokens_reported"] |= bool(summary.get("output_tokens_reported"))
            item["known_cost_usd"] += float(summary.get("known_cost_usd") or 0)
            if (summary.get("models") or not summary.get("usage_complete", True)) and not summary.get("cost_complete", False):
                item["unknown_cost_runs"] += 1
        for row in log_rows:
            item = buckets.get(int(row["bucket"]))
            if item is None:
                continue
            item["log_events"] += int(row["log_events"] or 0)
            item["log_usage_events"] += int(row["log_usage_events"] or 0)
            item["log_errors"] += int(row["log_errors"] or 0)
            for field in ("input_tokens", "output_tokens", *TOKEN_BREAKDOWN_KEYS):
                item[field] += int(row[field] or 0)
                if f"{field}_reported" in row.keys():
                    item[f"{field}_reported"] |= bool(row[f"{field}_reported"])
        points = list(buckets.values())
        for item in points:
            item["known_cost_usd"] = round(item["known_cost_usd"], 8)
            from .storage_derived import finalize_usage
            finalize_usage(item)
        return {"days": days, "step": step, "service": service, "session_id": session_id,
                "points": points}

    def internal_source_ids(self,source_ids,*,_db=None):
        ids=sorted({value for value in source_ids if isinstance(value,str)})
        result=set()
        if not ids:return result
        with (self._read() if _db is None else nullcontext(_db)) as db:
            for offset in range(0,len(ids),200):
                chunk=ids[offset:offset+200];marks=','.join('?' for _ in chunk)
                result.update(row[0] for row in db.execute(f'SELECT source_id FROM native_source_policy_v1 WHERE internal=1 AND source_id IN ({marks})',chunk))
        return result

    def _policy_records(self,records,kind,db):
        from .native_policy import scrub_record
        source_ids=[(row.get('resource_attributes') or {}).get('observatory.source_id') for row in records]
        internal=self.internal_source_ids(source_ids,_db=db)
        return [scrub_record(row,kind) if isinstance(source,str) and source in internal else row for row,source in zip(records,source_ids)]

    @staticmethod
    def _stale_native_generation(records,native_retry,native_source_path):
        if not native_retry and native_source_path is None:return False
        try:
            info=Path(native_source_path).stat() if native_source_path is not None else None
            current=f'{info.st_dev}:{info.st_ino}' if info is not None else None
        except OSError:current=None
        versions={row.get('attributes',{}).get('observatory.native_file_id') for row in records}
        return current is None or versions!={current}

    @staticmethod
    def _write_ingest_rows(db,sql,records,rows,*,skip_unchanged_native=False):
        # Native ordering fences may deliberately ignore stale replacements.
        # Only accepted writes may update activity/endpoints or derived facts.
        if not skip_unchanged_native and not any(row.get('scope_name')=='observatory.local_agents' for row in records):
            db.executemany(sql,rows)
            return records
        return [record for record,row in zip(records,rows) if db.execute(sql,row).rowcount]

    @staticmethod
    def _native_noop_guard(table):
        # Exact stored bytes/NULLs only: watermark, membership and capture
        # metadata remain real changes. The final parameter is a same-writer
        # repair flag, not permission to discard an invalidation.
        columns=(('parent_span_id','name','start_ns','end_ns','status','service','attributes',
                  'events','links','resource_attributes','scope_name','agent_id')if table=='spans'else
                 ('trace_id','span_id','time_ns','service','severity_number','severity_text',
                  'event_name','body','attributes','resource_attributes','scope_name','agent_id'))
        changed=' OR '.join(f'{table}.{name} IS NOT excluded.{name}'for name in columns)
        legacy=''
        if table=='logs':
            record_id="json_extract(excluded.attributes,'$.\"observatory.record_id\"')"
            legacy=f""" OR (excluded.scope_name='observatory.local_agents'
                AND json_type(excluded.attributes,'$."observatory.record_id"')='text'
                AND length({record_id})=32 AND {record_id} NOT GLOB '*[^0-9a-f]*'
                AND EXISTS(SELECT 1 FROM logs legacy WHERE legacy.scope_name='observatory.local_agents'
                    AND json_extract(legacy.attributes,'$."observatory.record_id"')={record_id}
                    AND legacy.digest<>excluded.digest))"""
        return f" AND (excluded.scope_name IS NULL OR excluded.scope_name NOT IN ('observatory.local_agents','observatory.opencode') OR {changed} OR ?{legacy})"

    @staticmethod
    def _native_repair_flags(db,records,kind):
        # Inspect only small cached/scalar state once per trace. Do not scan
        # raw maxima for healthy replays; absent/stale caches still force work.
        traces=set()
        for row in records:
            if row.get('scope_name')in {'observatory.local_agents','observatory.opencode'}and row.get('trace_id'):
                traces.add(row['trace_id'])
        states={}
        for trace in traces:
            row=db.execute("""SELECT a.last_ns,s.trace_id,
                CASE WHEN json_valid(s.summary_json) THEN json_extract(s.summary_json,'$.end_unix_nano') END AS end_ns,
                EXISTS(SELECT 1 FROM finding_dirty_v1 WHERE trace_id=?) AS dirty
                FROM (SELECT ? AS trace_id) target
                LEFT JOIN trace_activity a USING(trace_id) LEFT JOIN trace_summaries s USING(trace_id)""",
                (trace,trace)).fetchone()
            missing_or_dirty=(row['last_ns']is None or row['trace_id']is None or row['dirty']or
                type(row['end_ns'])not in(int,float)or row['last_ns']<row['end_ns'])
            states[trace]=(bool(missing_or_dirty),row['last_ns'])
        flags=[]
        for row in records:
            state=states.get(row.get('trace_id'))if row.get('scope_name')in {'observatory.local_agents','observatory.opencode'}else None
            stamp=row['end_unix_nano']if kind=='span'else row['time_unix_nano']
            flags.append(bool(state and(state[0]or state[1]<stamp)))
        return flags

    @staticmethod
    def _repair_native_activity(db,traces):
        for trace in traces:
            # A missing/stale clock must recover the entire accepted source
            # maximum, not just the older record which happened to be replayed.
            latest=db.execute("""SELECT MAX(stamp) FROM (
                SELECT MAX(end_ns) AS stamp FROM spans WHERE trace_id=? UNION ALL
                SELECT MAX(time_ns) FROM logs WHERE trace_id=? UNION ALL
                SELECT MAX(time_ns) FROM progress WHERE trace_id=? UNION ALL
                SELECT MAX(ingested_ns) FROM outcomes WHERE trace_id=?)""",(trace,)*4).fetchone()[0]
            if latest is not None:
                db.execute("""INSERT INTO trace_activity(trace_id,last_ns) VALUES(?,?)
                    ON CONFLICT(trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",(trace,latest))

    def ingest(self, spans, *, native_retry=False, native_source_path=None,skip_unchanged_native=False):
        spans = list(spans)
        skip_unchanged_native=skip_unchanged_native is True
        published=False
        from .native_policy import native_update_guard
        with self._source_write() as refresh:
            with self._connect() as db:
                db.execute('BEGIN IMMEDIATE')
                spans=self._policy_records(spans,'span',db)
                flags=self._native_repair_flags(db,spans,'span')if skip_unchanged_native else []
                repair={row['trace_id']for row,flag in zip(spans,flags)if flag}
                stale_generation=self._stale_native_generation(spans,native_retry,native_source_path)
                sql=f"""INSERT INTO spans
                    (trace_id,span_id,parent_span_id,name,start_ns,end_ns,status,service,
                     attributes,events,links,resource_attributes,scope_name,agent_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(trace_id,span_id) DO UPDATE SET
                    parent_span_id=excluded.parent_span_id, name=excluded.name,
                    start_ns=excluded.start_ns, end_ns=excluded.end_ns,
                    status=excluded.status, service=excluded.service,
                    attributes=excluded.attributes, events=excluded.events,
                    links=excluded.links, resource_attributes=excluded.resource_attributes,
                    scope_name=excluded.scope_name,agent_id=excluded.agent_id WHERE {native_update_guard('spans',stale_generation)}"""
                rows=[(s["trace_id"], s["span_id"], s["parent_span_id"], s["name"],
                      s["start_unix_nano"], s["end_unix_nano"], s["status"], s["service"],
                      json.dumps(s["attributes"]), json.dumps(s["events"]),
                      json.dumps(s.get("links", [])), json.dumps(s.get("resource_attributes", {})),
                      s.get("scope_name", ""), _agent_id_from_attributes(s.get("attributes"),
                          s.get("resource_attributes"), s.get("service"))) for s in spans]
                if skip_unchanged_native:
                    sql+=self._native_noop_guard('spans')
                    rows=[(*row,flag)for row,flag in zip(rows,flags)]
                    spans=self._write_ingest_rows(db,sql,spans,rows,skip_unchanged_native=True)
                else:spans=self._write_ingest_rows(db,sql,spans,rows)
                db.executemany("""INSERT INTO trace_activity(trace_id,last_ns) VALUES(?,?)
                    ON CONFLICT(trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
                    [(s["trace_id"], s["end_unix_nano"]) for s in spans])
                if repair:self._repair_native_activity(db,repair&{s['trace_id']for s in spans})
                self._update_endpoints(db, spans)
                from .storage_activity import drain
                # Initial native discovery must not inherit an unrelated
                # retained-history rebuild while holding the source writer.
                # Durable dirty rows remain for the migration worker; readers
                # still certify readiness rather than serving partial history.
                drain(db,limit=200 if self._async_derived_refresh and not self.migration_status.get('ready') else 10000)
                self._ingest_agent_nodes_from_spans(spans,_db=db)
                published=self._publish_native_summaries(db,spans)
            if not published:refresh.update(s["trace_id"] for s in spans)
        if published:self._notify_derived_progress()
        return len(spans)

    def _ingest_agent_nodes_from_spans(self, spans, *, _db=None):
        nodes = []
        for span in spans:
            if span.get("scope_name") in {"observatory.local_agents", "observatory.opencode"}:
                continue
            node = _agent_node_from_attributes(
                span.get("attributes"), span.get("resource_attributes"),
                span.get("service"), span.get("end_unix_nano"),
                span.get("span_id"))
            if node:
                nodes.append(node)
        if nodes:
            self.upsert_agent_nodes(nodes[:5000],_db=_db)

    def add_progress(self, trace_id, stage, message, percent=None, session_id=None, service=None):
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        if service is not None and (not isinstance(service, str) or not 1 <= len(service.strip()) <= 128):
            raise ValueError("service must contain 1 to 128 characters")
        if percent is not None:
            try:
                if isinstance(percent, bool):
                    raise ValueError("percent must be numeric")
                percent = float(percent)
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError("percent must be between 0 and 100") from exc
            if not math.isfinite(percent) or not 0 <= percent <= 100:
                raise ValueError("percent must be between 0 and 100")
        session_id = _session_value(session_id)
        with self._source_write() as refresh:
            with self._connect() as db:
                timestamp = time.time_ns()
                db.execute("INSERT INTO progress(trace_id,time_ns,stage,message,percent,session_id,service) VALUES(?,?,?,?,?,?,?)",
                           (trace_id, timestamp, str(stage), str(message), percent, session_id, service.strip() if service else None))
                self._touch_activity(db, trace_id, timestamp)
            refresh.update([trace_id])

    @staticmethod
    def _touch_activity(db, trace_id, timestamp):
        db.execute("""INSERT INTO trace_activity(trace_id,last_ns) VALUES(?,?)
            ON CONFLICT(trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
            (trace_id, timestamp))

    def prune(self, retention_days, now_ns=None):
        """Delete complete old traces and uncorrelated telemetry before a cutoff."""
        with self._derived_lock:
            return self._prune_locked(retention_days, now_ns)

    def _prune_locked(self, retention_days, now_ns=None):
        if retention_days is None or not math.isfinite(float(retention_days)) or float(retention_days) <= 0:
            raise ValueError("retention_days must be positive")
        now_ns = time.time_ns() if now_ns is None else int(now_ns)
        cutoff_ns = now_ns - int(float(retention_days) * 86_400_000_000_000)
        deleted = {}
        with self._write_db() as db:
            stale = """WITH activity(trace_id,activity_ns) AS (
                    SELECT trace_id,end_ns FROM spans
                    UNION ALL SELECT trace_id,time_ns FROM progress
                    UNION ALL SELECT trace_id,time_ns FROM logs WHERE trace_id IS NOT NULL
                    UNION ALL SELECT trace_id,ingested_ns FROM outcomes
                ) SELECT trace_id FROM activity GROUP BY trace_id HAVING MAX(activity_ns) < ?"""
            db.execute("CREATE TEMP TABLE stale_traces(trace_id TEXT PRIMARY KEY)")
            db.execute(f"INSERT INTO stale_traces {stale}", (cutoff_ns,))
            for table in ("spans", "progress", "logs", "outcomes", "endpoint_traces"):
                cursor = db.execute(f"DELETE FROM {table} WHERE trace_id IN (SELECT trace_id FROM stale_traces)")
                deleted[table] = cursor.rowcount
            deleted["trace_activity"] = db.execute(
                "DELETE FROM trace_activity WHERE trace_id IN (SELECT trace_id FROM stale_traces)").rowcount
            deleted["trace_summaries"] = db.execute(
                "DELETE FROM trace_summaries WHERE trace_id IN (SELECT trace_id FROM stale_traces)").rowcount
            deleted["findings"] = db.execute(
                "DELETE FROM finding_cache WHERE trace_id IN (SELECT trace_id FROM stale_traces)").rowcount
            db.execute('DELETE FROM finding_dirty_v1 WHERE trace_id IN (SELECT trace_id FROM stale_traces)')
            cursor = db.execute("DELETE FROM logs WHERE trace_id IS NULL AND time_ns < ?", (cutoff_ns,))
            deleted["unlinked_logs"] = cursor.rowcount
            cursor = db.execute("DELETE FROM metric_points WHERE time_ns < ?", (cutoff_ns,))
            deleted["metric_points"] = cursor.rowcount
            cursor = db.execute("DELETE FROM endpoint_services WHERE last_ns < ?", (cutoff_ns,))
            deleted["endpoint_services"] = cursor.rowcount
            cursor = db.execute("DELETE FROM endpoints WHERE last_ns < ?", (cutoff_ns,))
            deleted["endpoints"] = cursor.rowcount
            cursor = db.execute("DELETE FROM agent_connections WHERE last_seen_ns < ?", (cutoff_ns,))
            deleted["agent_connections"] = cursor.rowcount
            cursor = db.execute("DELETE FROM agent_nodes WHERE observed_ns < ?", (cutoff_ns,))
            deleted["agent_nodes"] = cursor.rowcount
            cursor = db.execute("DELETE FROM agent_identity WHERE updated_ns < ?", (cutoff_ns,))
            deleted["agent_identity"] = cursor.rowcount
            if deleted["agent_nodes"] or deleted["agent_identity"]:
                self._bump_hierarchy_revision(db)
        deleted["cutoff_unix_nano"] = cutoff_ns
        return deleted

    def ingest_logs(self, records, *, native_retry=False, native_source_path=None, expected_receiver=None,skip_unchanged_native=False):
        records = list(records)
        skip_unchanged_native=skip_unchanged_native is True
        published=False
        from .native_policy import native_update_guard
        with self._source_write() as refresh:
            with self._connect() as db:
                db.execute('BEGIN IMMEDIATE')
                if expected_receiver is not None:
                    if not isinstance(expected_receiver,str) or not 0<len(expected_receiver)<=128:
                        raise ValueError('Invalid expected receiver identity')
                    actual=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
                    if actual!=expected_receiver:raise ValueError('Receiver namespace changed; no log records were written')
                records=self._policy_records(records,'log',db)
                flags=self._native_repair_flags(db,records,'log')if skip_unchanged_native else []
                repair={row['trace_id']for row,flag in zip(records,flags)if flag}
                stale_generation=self._stale_native_generation(records,native_retry,native_source_path)
                rows = []
                native_ids = []
                for log in records:
                    canonical = json.dumps(log, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                    digest = hashlib.sha256(canonical.encode()).hexdigest()
                    record_id = log['attributes'].get('observatory.record_id')
                    if log['scope_name']=='observatory.local_agents' and isinstance(record_id,str) and TRACE_ID.fullmatch(record_id):
                        digest = hashlib.sha256(('local-session:'+record_id).encode()).hexdigest()
                        native_ids.append((record_id,digest))
                    cursor_event_id = log['attributes'].get('cursor.event.id')
                    if isinstance(cursor_event_id, str) and cursor_event_id:
                        digest = hashlib.sha256(('cursor-event:'+cursor_event_id).encode()).hexdigest()
                    rows.append((digest, log["trace_id"], log["span_id"], log["time_unix_nano"],
                                 log["service"], log["severity_number"], log["severity_text"],
                                 log["event_name"], json.dumps(log["body"]),
                                 json.dumps(log["attributes"]), json.dumps(log["resource_attributes"]),
                                 log["scope_name"], _agent_id_from_attributes(
                                     log.get("attributes"), log.get("resource_attributes"), log.get("service"))))
                sql=f"""INSERT INTO logs
                    (digest,trace_id,span_id,time_ns,service,severity_number,severity_text,
                     event_name,body,attributes,resource_attributes,scope_name,agent_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(digest) DO UPDATE SET
                    trace_id=excluded.trace_id,span_id=excluded.span_id,time_ns=excluded.time_ns,
                    service=excluded.service,severity_number=excluded.severity_number,
                    severity_text=excluded.severity_text,event_name=excluded.event_name,
                    body=excluded.body,attributes=excluded.attributes,
                    resource_attributes=excluded.resource_attributes,scope_name=excluded.scope_name,
                    agent_id=excluded.agent_id WHERE {native_update_guard('logs',stale_generation)}"""
                if skip_unchanged_native:
                    sql+=self._native_noop_guard('logs')
                    rows=[(*row,flag)for row,flag in zip(rows,flags)]
                    records=self._write_ingest_rows(db,sql,records,rows,skip_unchanged_native=True)
                else:records=self._write_ingest_rows(db,sql,records,rows)
                accepted_ids={log['attributes'].get('observatory.record_id') for log in records
                              if log['scope_name']=='observatory.local_agents'
                              and isinstance(log['attributes'].get('observatory.record_id'),str)}
                db.executemany("""DELETE FROM logs WHERE scope_name='observatory.local_agents'
                    AND json_extract(attributes,'$."observatory.record_id"')=? AND digest<>?""",
                    [(record_id,digest) for record_id,digest in native_ids if record_id in accepted_ids])
                db.executemany("""INSERT INTO trace_activity(trace_id,last_ns) VALUES(?,?)
                    ON CONFLICT(trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
                    [(log["trace_id"], log["time_unix_nano"]) for log in records if log["trace_id"]])
                if repair:self._repair_native_activity(db,repair&{row['trace_id']for row in records if row['trace_id']})
                self._update_endpoints(db, records)
                from .storage_activity import drain
                drain(db,limit=200 if self._async_derived_refresh and not self.migration_status.get('ready') else 10000)
                published=self._publish_native_summaries(db,records)
            nodes = [_agent_node_from_attributes(log.get("attributes"), log.get("resource_attributes"),
                                                 log.get("service"), log.get("time_unix_nano"),
                                                 log.get("digest"))
                     for log in records
                     if log.get("scope_name") not in {"observatory.local_agents", "observatory.opencode"}]
            nodes = [node for node in nodes if node]
            if nodes:
                self.upsert_agent_nodes(nodes[:5000])
            if not published:refresh.update(log["trace_id"] for log in records if log["trace_id"])
        if published:self._notify_derived_progress()
        return len(records)

    def logs(self, trace_id=None, limit=100, *, _db=None):
        with self._read_db(_db) as db:
            if trace_id:
                rows = db.execute("SELECT * FROM logs WHERE trace_id=? ORDER BY time_ns DESC LIMIT ?",
                                  (_id(trace_id, TRACE_ID, "trace_id"), limit)).fetchall()
            else:
                rows = db.execute("SELECT * FROM logs ORDER BY time_ns DESC LIMIT ?", (limit,)).fetchall()
        return [{"id": r["digest"], "trace_id": r["trace_id"], "span_id": r["span_id"],
                 "time_unix_nano": r["time_ns"], "service": r["service"],
                 "severity_number": r["severity_number"], "severity_text": r["severity_text"],
                 "event_name": r["event_name"], "body": json.loads(r["body"]),
                 "attributes": json.loads(r["attributes"]),
                 "resource_attributes": json.loads(r["resource_attributes"]),
                 "scope_name": r["scope_name"]} for r in rows]

    @staticmethod
    def _event_cursor(cursor, *, max_key=512):
        if not cursor:
            return None
        try:
            stamp, key = json.loads(base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)))
            if not isinstance(stamp, int) or not isinstance(key, str) or len(key) > max_key:
                raise ValueError
            return stamp, key
        except (ValueError, TypeError, UnicodeDecodeError) as exc:
            raise ValueError("invalid cursor") from exc

    @staticmethod
    def _next_event_cursor(stamp, key):
        return base64.urlsafe_b64encode(json.dumps([stamp, key]).encode()).decode().rstrip("=")

    def recent_activity(self, limit=100, service=None, domain=None, query=None, session_id=None, action=None):
        return self.activity_page(limit, service, domain, query, session_id, action=action)["activity"]

    def activity_page(self, limit=100, service=None, domain=None, query=None, session_id=None,
                      cursor=None, include_reviews=True, errors_only=False, action=None,
                      agent_id=None, subtree=False, scope_revision=None, trace_id=None, turn_id=None, review=False,
                      *,_initial_receiver=None,_initial_file=None,_strict_read=False):
        """Read indexed source events; never expand historical trace-summary JSON."""
        from .storage_activity import drain
        limit=max(1,min(500,int(limit)));before=self._event_cursor(cursor)
        scope=None;clauses=[];params=[]
        if trace_id and turn_id:raise ValueError('Choose an exact trace or a recorded turn, not both')
        if trace_id is not None:trace_id=_id(trace_id,TRACE_ID,'trace_id')
        if turn_id is not None:turn_id=_id(turn_id,TRACE_ID,'turn_id')
        for key,value in (('trace_id',trace_id),('session_id',session_id),('service',service),('domain',domain),('turn_id',turn_id)):
            if value:clauses.append(key+'=?');params.append(value)
        if action:clauses.append('lower(action)=?');params.append(str(action).casefold())
        if not include_reviews:clauses.append("COALESCE(service,'')!='codex-review'")
        if errors_only:clauses.append("lower(result) IN ('error','failed','denied','blocked','policy_denied','incomplete')")
        if review:clauses.append("(domain IN ('message','file','shell','context') OR lower(result) IN ('error','failed','denied','blocked','policy_denied','incomplete'))")
        if query:
            clauses.append("(instr(lower(payload),lower(?))>0 OR EXISTS(SELECT 1 FROM logs raw WHERE kind='log' AND raw.digest=owner_key AND instr(lower(raw.body),lower(?))>0) OR EXISTS(SELECT 1 FROM spans raw WHERE kind='span' AND raw.trace_id=activity_index_v1.trace_id AND raw.trace_id||':'||raw.span_id=owner_key AND instr(lower(raw.attributes||raw.events),lower(?))>0))")
            params.extend((query,query,query))
        if before:clauses.append('(stamp,event_key)<(?,?)');params.extend(before)
        with (self._source_read('Activity')if _initial_file is not None else self._connect())as db:
            # Certified HTTP reads never repair: certify the same read-only
            # snapshot used for pagination, ownership and source hydration.
            db.execute('BEGIN')
            if _initial_file is not None:
                self._require_initial_activity(db,_initial_receiver,_initial_file,strict=_strict_read)
            # Repair older-writer changes transactionally and within a bounded
            # read budget. Large upgrades are resumed at receiver startup.
            if _initial_file is None and db.execute('SELECT 1 FROM activity_dirty_v1 LIMIT 1').fetchone():
                db.rollback()
                # Admission starts only after releasing the old read snapshot.
                # Finish the writer before releasing the gate, then bind the
                # repaired-index check and hydration to a fresh read snapshot.
                with self._writer_gate:
                    db.execute('BEGIN IMMEDIATE')
                    try:
                        drain(db,limit=1000)
                        db.commit()
                    except BaseException:
                        db.rollback()
                        raise
                db.execute('BEGIN')
            if db.execute('SELECT 1 FROM activity_dirty_v1 LIMIT 1').fetchone():
                db.commit()
                raise ValueError('Activity index is catching up; retry after receiver migration completes')
            if agent_id:
                scope=self.resolve_agent_scope(agent_id,include_subagents=bool(subtree),_db=db)
                if scope_revision and scope_revision!=scope['revision']:raise ValueError('hierarchy scope changed')
                agents=scope['agent_ids'] if subtree else [agent_id]
                if not agents:clauses.append('0')
                else:
                    clauses.append('agent_id IN ('+','.join('?' for _ in agents)+')');params.extend(agents)
            where=' WHERE '+' AND '.join(clauses) if clauses else ''
            rows=db.execute('SELECT payload,stamp,event_key FROM activity_index_v1'+where+' ORDER BY stamp DESC,event_key DESC LIMIT ?',[*params,limit+1]).fetchall()
            from .storage_activity import hydrate
            items=hydrate(db,[json.loads(row['payload']) for row in rows[:limit]])
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            bounded=[];size=0
            for item in items:
                item['receiver_id']=receiver
                amount=len(json.dumps(item,ensure_ascii=False).encode())
                if size+amount>(1536*1024 if review else 12*1024*1024):break
                bounded.append(item);size+=amount
            context=[]
            if review and not cursor and not (domain or action or query or errors_only):
                for message_action in ('user','assistant'):
                    context_where=where+(' AND ' if where else ' WHERE ')+"domain='message' AND lower(action)=?"
                    found=db.execute('SELECT payload FROM activity_index_v1'+context_where+' ORDER BY stamp DESC,event_key DESC LIMIT 1',[*params,message_action]).fetchone()
                    if found:context.append(json.loads(found[0]))
                context=hydrate(db,context)
                for item in context:item['receiver_id']=receiver
        result=dict(activity=bounded,review_context=context,
            next_cursor=self._next_event_cursor(rows[len(bounded)-1]['stamp'],rows[len(bounded)-1]['event_key']) if bounded and len(rows)>len(bounded) else None,
            scope='stored activity',receiver_id=receiver)
        if scope is not None:result.update(scope='agent subtree' if subtree else 'this agent',agent_scope=scope)
        return result

    def review_run(self, trace_id):
        """Bounded exact-run facts without span bodies or historical search text."""
        trace_id=_id(trace_id,TRACE_ID,'trace_id')
        with self._connect() as db:
            db.execute('BEGIN')
            self._require_index_ready(db)
            row=db.execute('SELECT summary_json FROM live_summaries_v1 WHERE trace_id=?',(trace_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def review_turn(self, trace_id, *, _db=None):
        """Authoritative OpenCode user-parent membership, preserving step traces.

        Only adapter-tagged assistant messages contribute usage. Each message
        owns its disjoint model/tool records; missing ownership keeps usage
        unavailable rather than borrowing session totals.
        """
        trace_id=_id(trace_id,TRACE_ID,'trace_id')
        from .opencode_turn_proof import proof_sql,usage_sql,_scalar,turn_coverage
        with (self._read() if _db is None else self._read_db(_db)) as db:
            if _db is None:db.execute('BEGIN')
            root=db.execute(f"SELECT {proof_sql('attributes')} AS attributes,{_scalar('attributes','agent.turn.id')} AS turn_id,{_scalar('attributes','session.id')} AS session_id,service,agent_id FROM spans WHERE trace_id=? AND name='agent.run' AND scope_name='observatory.opencode' LIMIT 1",(trace_id,)).fetchone()
            if not root or root['service']!='opencode':return None
            attrs=json.loads(root['attributes']);turn=root['turn_id']
            session=root['session_id'];agent=root['agent_id']
            if not turn or not session or not agent:return None
            cursor=db.execute(f"SELECT s.trace_id,{proof_sql('s.attributes')} AS attributes,{usage_sql('c.summary_json')} AS summary_json,EXISTS(SELECT 1 FROM finding_dirty_v1 f WHERE f.trace_id=s.trace_id) AS usage_pending FROM spans s LEFT JOIN live_summaries_v1 c USING(trace_id) WHERE s.service='opencode' AND s.name='agent.run' AND s.scope_name='observatory.opencode' AND json_extract(s.attributes,'$.\"agent.turn.id\"')=? AND s.agent_id=? AND json_extract(s.attributes,'$.\"session.id\"')=? ORDER BY s.start_ns,s.trace_id LIMIT 1001",(turn,agent,session))
            members=[];retained_bytes=0;payload_limited=False
            for row in cursor:
                entry=dict(row)
                size=len(entry['attributes'].encode('utf-8'))+len(entry['summary_json'].encode('utf-8'))
                if retained_bytes+size>2*1024*1024:
                    payload_limited=True;entry.update(attributes='{}',summary_json='{}')
                else:retained_bytes+=size
                members.append(entry)
        clipped=len(members)>1000
        members=members[:1000]
        rows=[json.loads(row['summary_json']) if row['summary_json'] else {} for row in members]
        owner=dict(producer='opencode',agent_id=agent,session_id=session)
        reasons=turn_coverage(attrs,[json.loads(row['attributes']) for row in members],
            [row['trace_id'] for row in members],clipped=clipped)
        if payload_limited:reasons.append('Turn proof and usage metadata exceed the retained byte limit')
        if any(row['usage_pending'] for row in members):reasons.append('Turn usage summaries are catching up with recorded source changes')
        owned=bool(rows) and all(row.get('review_owner')==owner and row.get('turn_id')==turn and row.get('usage_complete') is True for row in rows)
        if not owned:reasons.append('Turn step ownership, usage reporting or indexing is incomplete')
        if clipped and not reasons:reasons.append('Turn membership exceeds the retained member limit')
        complete=owned and not clipped and not reasons
        usage=dict(trace_id=trace_id,turn_id=turn,scope_owner=owner,turn_members_clipped=clipped,turn_usage_complete=complete,turn_coverage_reasons=reasons,turn_closed=attrs.get('observatory.opencode.turn.closed'),turn_membership='recorded idle-boundary interval' if attrs else 'recorded user parent',step_trace_ids=[row['trace_id'] for row in members],
            agent_count=1,agent_count_complete=complete,review_owner=owner if complete else {},
            usage_allocation='recorded turn interval; disjoint assistant step usage' if complete else 'turn source membership or step ownership incomplete; usage unavailable')
        if complete:
            for field in ('input_tokens','output_tokens','cache_read_input_tokens','cache_write_input_tokens','reasoning_output_tokens'):
                reported=all(row.get(field+'_reported') is True for row in rows)
                usage[field]=sum(row.get(field) or 0 for row in rows) if reported else None
                usage[field+'_reported']=reported
            costs=[row.get('known_cost_usd') for row in rows]
            usage.update(known_cost_usd=sum(value for value in costs if value is not None) if any(value is not None for value in costs) else None,
                cost_complete=all(row.get('cost_complete') for row in rows),usage_complete=all(usage.get(field+'_reported') for field in ('input_tokens','output_tokens')))
        return usage

    def mcp_calls(self, limit=100, service=None, session_id=None, query=None):
        return self.mcp_page(limit, service, session_id, query)['calls']

    def _source_file_identity(self,label):
        try:stat=Path(self.path).stat()
        except OSError as exc:
            raise IndexNotReady({**self.migration_status,'ready':False,
                'stage':f'Receiver identity is unavailable during {label} read'})from exc
        return stat.st_dev,stat.st_ino

    def _mcp_file_identity(self):
        return self._source_file_identity('MCP')

    @contextmanager
    def _source_read(self,label):
        # Use the existing exclusive read-only leases: a vanished path must
        # never be recreated by sqlite3.connect's default read/write mode.
        body_error=None
        try:
            with self._read()as db:
                try:yield db
                except BaseException as exc:
                    body_error=exc
                    raise
        except (OSError,sqlite3.Error)as exc:
            if exc is body_error:raise
            raise IndexNotReady({**self.migration_status,'ready':False,
                'stage':f'{label} preparation proof is unavailable'})from exc

    @contextmanager
    def _mcp_read(self):
        with self._source_read('MCP')as db:yield db

    def _require_initial_source(self,db,receiver,file_identity,*,label):
        """Certify initial preparation and identity in this read snapshot.

        Each caller adds its actual queue/semantic-marker dependencies. No
        source content, cached summary or scope is inferred by this proof.
        """
        if not db.in_transaction:raise RuntimeError(f'{label} certificate requires a read transaction')
        state=dict(self.migration_status)
        if state.get('error')or self.last_derived_error:
            state.update(ready=False,error=state.get('error')or self.last_derived_error)
            raise IndexNotReady(state)
        if self._derived_stopping or self._migration_stop.is_set():
            raise IndexNotReady({**state,'ready':False,'stage':'Receiver is stopping'})
        if state.get('ready')is not True:raise IndexNotReady({**state,'ready':False})
        try:metadata=dict(db.execute("SELECT key,value FROM schema_meta WHERE key IN ('trace_derived_v15','receiver_id')"))
        except sqlite3.Error as exc:
            raise IndexNotReady({**state,'ready':False,'stage':f'{label} preparation proof is unavailable'})from exc
        if metadata.get('trace_derived_v15')!='1':
            raise IndexNotReady({**state,'ready':False,'stage':'Preparing indexed history'})
        actual=metadata.get('receiver_id')
        if (not isinstance(actual,str)or not actual or actual!=receiver or
                self._source_file_identity(label)!=file_identity):
            raise IndexNotReady({**state,'ready':False,'stage':f'Receiver identity changed during {label} read'})

    def _require_initial_mcp(self,db,receiver,file_identity,*,strict=False):
        self._require_initial_source(db,receiver,file_identity,label='MCP')
        state=dict(self.migration_status)
        if strict:
            self._require_index_ready(db)
            extra='SELECT 1 FROM native_lifecycle_dirty_v1'
            if self.investigation_index_v1:extra+=' UNION ALL SELECT 1 FROM investigation_dirty_v1'
            if db.execute(extra+' LIMIT 1').fetchone():
                raise IndexNotReady({**state,'ready':False,'stage':'Indexing incoming source changes'})

    def certify_initial_mcp(self,receiver,*,strict=False):
        """Run before eligible cache lookup; raw misses certify again in BEGIN."""
        identity=self._mcp_file_identity()
        try:
            with self._mcp_read()as db:
                db.execute('BEGIN')
                self._require_initial_mcp(db,receiver,identity,strict=strict)
        except (OSError,sqlite3.Error)as exc:
            raise IndexNotReady({**self.migration_status,'ready':False,'stage':'MCP preparation proof is unavailable'})from exc
        return identity

    def _require_initial_activity(self,db,receiver,file_identity,*,strict=False):
        self._require_initial_source(db,receiver,file_identity,label='Activity')
        state=dict(self.migration_status)
        markers=dict(db.execute("SELECT key,value FROM schema_meta WHERE key IN ('activity_sources_v2','activity_operation_facts_v2')"))
        if any(markers.get(key)!='1'for key in ('activity_sources_v2','activity_operation_facts_v2')):
            raise IndexNotReady({**state,'ready':False,'stage':'Preparing indexed Activity'})
        if db.execute('SELECT 1 FROM activity_dirty_v1 LIMIT 1').fetchone():
            raise IndexNotReady({**state,'ready':False,'stage':'Indexing incoming source changes'})
        if strict:
            self._require_index_ready(db)
            extra='SELECT 1 FROM native_lifecycle_dirty_v1'
            if self.investigation_index_v1:extra+=' UNION ALL SELECT 1 FROM investigation_dirty_v1'
            if db.execute(extra+' LIMIT 1').fetchone():
                raise IndexNotReady({**state,'ready':False,'stage':'Indexing incoming source changes'})

    def certify_initial_activity(self,receiver,*,strict=False):
        """Certify current Activity before cache lookup, without queue repair."""
        identity=self._source_file_identity('Activity')
        try:
            with self._source_read('Activity')as db:
                db.execute('BEGIN')
                self._require_initial_activity(db,receiver,identity,strict=strict)
        except (OSError,sqlite3.Error)as exc:
            raise IndexNotReady({**self.migration_status,'ready':False,'stage':'Activity preparation proof is unavailable'})from exc
        return identity

    def _require_initial_metrics(self,db,receiver,file_identity):
        self._require_initial_rollup(db,receiver,file_identity,label='Metrics')

    def _require_initial_sessions(self,db,receiver,file_identity):
        self._require_initial_rollup(db,receiver,file_identity,label='Sessions')

    def _require_initial_rollup(self,db,receiver,file_identity,*,label):
        self._require_initial_source(db,receiver,file_identity,label=label)
        # Totals mix run summaries, log usage and raw counts. Both derived
        # queues must be clean in the very snapshot used for aggregation.
        self._require_index_ready(db)
        markers=('activity_sources_v2','activity_operation_facts_v2','live_stats_v3')
        actual=dict(db.execute("SELECT key,value FROM schema_meta WHERE key IN (?,?,?)",markers))
        if any(actual.get(key)!='1'for key in markers):
            raise IndexNotReady({**self.migration_status,'ready':False,'stage':f'Preparing indexed {label}'})

    def certify_initial_metrics(self,receiver):
        identity=self._source_file_identity('Metrics')
        try:
            with self._source_read('Metrics')as db:
                db.execute('BEGIN')
                self._require_initial_metrics(db,receiver,identity)
        except (OSError,sqlite3.Error)as exc:
            raise IndexNotReady({**self.migration_status,'ready':False,'stage':'Metrics preparation proof is unavailable'})from exc
        return identity

    def certify_initial_sessions(self,receiver):
        identity=self._source_file_identity('Sessions')
        try:
            with self._source_read('Sessions')as db:
                db.execute('BEGIN')
                self._require_initial_sessions(db,receiver,identity)
        except (OSError,sqlite3.Error)as exc:
            raise IndexNotReady({**self.migration_status,'ready':False,'stage':'Sessions preparation proof is unavailable'})from exc
        return identity

    def mcp_page(self, limit=100, service=None, session_id=None, query=None, cursor=None,
                 include_reviews=True, agent_id=None, subtree=False, scope_revision=None,
                 *,_initial_receiver=None,_initial_file=None,_strict_read=False):
        """Page complete MCP calls, keeping all evidence for each call together."""
        with (self._mcp_read()if _initial_file is not None else self._connect())as db:
            db.execute('BEGIN')
            if _initial_file is not None:self._require_initial_mcp(db,_initial_receiver,_initial_file,strict=_strict_read)
            if agent_id:self._require_index_ready(db)
            return self._mcp_page(db,limit,service,session_id,query,cursor,
                include_reviews,agent_id,subtree,scope_revision)

    def _mcp_page(self, db, limit, service, session_id, query, cursor,
                  include_reviews, agent_id, subtree, scope_revision):
        limit = max(1, min(200, int(limit)))
        # Scoped provider IDs may each occupy 512 characters. SQL JSON escapes
        # control characters, with the server/call tuple nested once more in
        # the outer ownership key; the decoded key can exceed 10 KiB.
        before = self._event_cursor(cursor,max_key=16384)
        scope = None
        mcp_method = "json_extract(attributes,'$.\"mcp.method.name\"')"
        # Keep all MCP protocol methods, not only tool execution. Discovery,
        # prompts, and resource reads are useful agent activity too.
        from .storage_activity import MCP_PREDICATE
        from .storage_mcp import call_key_sql, session_sql, execution_match_sql, text_sql, text_value, inventory_page
        # Both inventory errors and I/O enrichment require this exact recorded
        # execution type. Prove its absence in this same read snapshot before
        # constructing the much larger ownership/uniqueness joins. A positive
        # result still uses those joins unchanged; this is never association
        # evidence and no result survives the request.
        has_executions = db.execute("""SELECT 1 FROM spans
            WHERE lower(json_extract(attributes,'$."gen_ai.tool.type"'))='mcptool'
            LIMIT 1""").fetchone() is not None
        match = MCP_PREDICATE
        clauses, params = [match], []
        if service:
            clauses.append("service=?")
            params.append(service)
        if session_id:
            clauses.append(session_sql()+'=?')
            params.append(session_id)
        if agent_id:
            scope = self.resolve_agent_scope(agent_id, include_subagents=bool(subtree),_db=db)
            if scope_revision and scope_revision != scope["revision"]:
                raise ValueError("hierarchy scope changed")
            if not scope["agent_ids"]:
                return {'calls': [], 'next_cursor': None, 'summary': {}, 'agent_scope': scope}
            marks = ','.join('?' for _ in scope["agent_ids"])
            clauses.append(f"agent_id IN ({marks})")
            params.extend(scope['agent_ids'])
        if not include_reviews:
            clauses.append("service!='codex-review'")
        where = ' AND '.join(clauses)
        span_key,log_key=call_key_sql('span'),call_key_sql('log')
        def mcp_identity(alias):
            def value(key):
                return text_sql(alias,key)
            if alias == 'spans':
                tool_from_name = (
                    f"CASE WHEN {value('mcp.method.name')}='tools/call' "
                    f"AND lower({alias}.name) LIKE 'mcp send tools/call %' "
                    f"THEN trim(substr({alias}.name, "
                    f"instr(lower({alias}.name),'tools/call')+length('tools/call'))) END"
                )
            else:
                tool_from_name = "NULL"
            return (f"COALESCE({value('mcp.server.name')},{value('server.address')},'Not reported')",
                    f"COALESCE({value('mcp.tool.name')},{value('gen_ai.tool.name')},"
                    f"{value('tool.name')},{value('agent.activity.action')},"
                    f"{tool_from_name},'Not reported')")
        server,tool=mcp_identity('logs')
        # A timestamp/tool match cannot establish that two source calls are
        # duplicates. Explicit scoped call keys already merge linked I/O.
        unique_log='1'
        span_server, span_tool = mcp_identity('spans')
        mcp_result_error_sql = " OR ".join(
            f"(json_type(execution.attributes,'$.\"{flag}\"')='true')"
            for flag in ("mcp.tool.is_error", "mcp.is_error")
        )
        for result_key in ("gcp.vertex.agent.tool_response", "gen_ai.tool.call.result",
                           "tool.result", "output.value"):
            result_value = f"json_extract(execution.attributes,'$.\"{result_key}\"')"
            # MCP tool results are often stored as JSON strings. Guard nested
            # extraction so arbitrary plain-text tool output cannot make the
            # inventory query fail with malformed JSON.
            mcp_result_error_sql += (
                f" OR CASE WHEN json_valid({result_value}) THEN "
                f"(json_type({result_value},'$.isError')='true' "
                f"OR json_type({result_value},'$.is_error')='true') ELSE 0 END"
            )
        mcp_tool_failed = (f"EXISTS (SELECT 1 FROM spans execution WHERE {execution_match_sql()} AND ({mcp_result_error_sql}))"
                           if has_executions else '0')
        body_value="json_extract(body,'$')"
        direction_sql="json_extract(attributes,'$.\"observatory.mcp.io.direction\"')"
        no_output_attributes=' AND '.join(
            f"json_type(attributes,'$.\"{key}\"') IS NULL"
            for key in ('output.value','gen_ai.tool.call.result','gcp.vertex.agent.tool_response','tool.result'))
        chosen_body_result=f"""CASE WHEN {direction_sql}='result' THEN {body_value}
            WHEN COALESCE({direction_sql},'')='' AND json_valid({body_value})
            THEN json_extract({body_value},'$.result') END"""
        body_errors=' OR '.join(f"json_type(({chosen_body_result}),'$.{key}')='true'" for key in ('isError','is_error'))
        log_body_error=f"""CASE WHEN ({no_output_attributes}) AND json_valid(({chosen_body_result}))
            THEN ({body_errors}) ELSE 0 END"""
        span_search='attributes || name || service' if query else 'NULL'
        log_search='attributes || body || service' if query else 'NULL'
        evidence_sql = f"""
            SELECT {span_key} AS call_key, {span_server} AS server, {span_tool} AS tool,
                   (status IN ('ERROR','FAILED') OR COALESCE(({mcp_result_error_sql.replace('execution.','spans.')}),0) OR {mcp_tool_failed}) AS failed,
                   end_ns AS stamp,{span_search} AS search_evidence
            FROM spans WHERE {where}
            UNION ALL
            SELECT {log_key}, {server}, {tool},
                   COALESCE(json_extract(attributes,'$."agent.activity.result"') IN ('error','failed','denied','blocked')
                     OR ({mcp_result_error_sql.replace('execution.','logs.')}) OR ({log_body_error}),0),
                   time_ns AS stamp,{log_search} AS search_evidence
            FROM logs WHERE {where} AND {unique_log}"""
        inventory,candidates=inventory_page(db,evidence_sql,[*params,*params],
            query=query,before=before,limit=limit)
        metric_servers = []
        if not session_id and not agent_id:
            metric_filter = "" if not service else " AND service=?"
            metric_params = [] if not service else [service]
            metric_rows = db.execute(f"""SELECT digest,time_ns,temporality,attributes,
                    resource_attributes,scope_name,data,
                    COALESCE(NULLIF(json_extract(attributes,'$.\"cursor.mcp.server.name\"'),''),'Not reported') AS server
                FROM metric_points
                WHERE name='cursor.tool.calls' AND service='cursor'
                  AND kind='sum' AND temporality IN (1,2)
                  AND json_extract(data,'$.isMonotonic')=1
                  AND json_extract(attributes,'$.\"cursor.tool.kind\"')='mcp'{metric_filter}
                ORDER BY time_ns,digest""", metric_params).fetchall()
            # DELTA (1) values cover disjoint collection intervals, so add
            # every point. CUMULATIVE (2) values are running totals; retain
            # only the latest point in each attribute/resource time series.
            cumulative = {}
            totals = {}

            def add_metric_point(row):
                attributes = json.loads(row['attributes'])
                data = json.loads(row['data'])
                try:
                    if int(data.get('flags', 0)) & 1:
                        return
                    calls = max(0, int(float(data.get('value', 0))))
                except (TypeError, ValueError, OverflowError):
                    return
                server = row['server']
                bucket = totals.setdefault(server, {'server':server,'calls':0,'errors':0,'tools':set()})
                bucket['calls'] += calls
                if str(attributes.get('cursor.tool.status','')).casefold() in {'failure','failed','error'}:
                    bucket['errors'] += calls
                tool = attributes.get('cursor.tool.name')
                if tool:
                    bucket['tools'].add(str(tool))

            for row in metric_rows:
                if row['temporality'] == 1:
                    add_metric_point(row)
                    continue
                identity = (row['server'],
                    json.dumps(json.loads(row['attributes']),sort_keys=True,separators=(',',':')),
                    json.dumps(json.loads(row['resource_attributes']),sort_keys=True,separators=(',',':')),
                    row['scope_name'])
                previous = cumulative.get(identity)
                if previous is None or (row['time_ns'],row['digest']) > (previous['time_ns'],previous['digest']):
                    cumulative[identity] = row
            for row in cumulative.values():
                add_metric_point(row)
            metric_servers = [{**row,'tools':len(row['tools'])}
                              for row in sorted(totals.values(),key=lambda item:item['server'].casefold())]
        summary = {'calls': sum(row['calls'] for row in inventory),
                   'errors': sum(row['errors'] for row in inventory),
                   'tools': sum(row['tools'] for row in inventory),
                   'servers': [row for row in inventory if row['server'] != 'Not reported'],
                   'unknown_server_calls': sum(row['calls'] for row in inventory if row['server'] == 'Not reported'),
                   'unknown_server_errors': sum(row['errors'] for row in inventory if row['server'] == 'Not reported'),
                   'unknown_server_tools': sum(row['tools'] for row in inventory if row['server'] == 'Not reported'),
                   'metric_calls': sum(row['calls'] for row in metric_servers),
                   'metric_servers': metric_servers,
                   'metric_scope': 'all sessions; Cursor metrics have no session IDs'}
        selected_keys = [row['call_key'] for row in candidates[:limit]]
        if not selected_keys:
            result = {'calls': [], 'next_cursor': None, 'summary': summary}
            if scope is not None:
                result.update(scope='agent subtree' if subtree else 'this agent', agent_scope=scope)
            return result
        placeholders = ','.join('?' for _ in selected_keys)
        spans = db.execute(f"SELECT *,{span_key} AS mcp_key,{session_sql()} AS mcp_session FROM spans WHERE {span_key} IN ({placeholders}) AND {where}",[*selected_keys,*params]).fetchall()
        logs = db.execute(f"SELECT *,{log_key} AS mcp_key,{session_sql()} AS mcp_session FROM logs WHERE {log_key} IN ({placeholders}) AND {where} ORDER BY time_ns DESC,digest DESC",[*selected_keys,*params]).fetchall()
        def decode_tool_payload(value):
            if not isinstance(value, str):
                return value
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value

        def recorded_payload(attrs,keys):
            return next((decode_tool_payload(attrs[key]) for key in keys if key in attrs), '')

        argument_keys=('input.value','gen_ai.tool.call.arguments','gcp.vertex.agent.tool_call_args')
        output_keys=('output.value','gen_ai.tool.call.result','gcp.vertex.agent.tool_response','tool.result')

        calls = {}
        for span in spans:
            attrs = json.loads(span['attributes'])
            key = span['mcp_key']
            tool = text_value(attrs,'mcp.tool.name','gen_ai.tool.name','tool.name')
            method = text_value(attrs,'mcp.method.name','rpc.method',default='tools/call')
            if not tool and method == 'tools/call':
                name_prefix = 'mcp send tools/call '
                if span['name'].lower().startswith(name_prefix):
                    tool = span['name'][len(name_prefix):].strip()
            elif not tool:
                tool = text_value(attrs,'agent.activity.action',default='Not reported')
            calls[key] = {'id': key, 'trace_id': span['trace_id'], 'span_id': span['span_id'],
                'session_id': span['mcp_session'],'agent_id':span['agent_id'],
                'service': span['service'],
                'server': text_value(attrs,'mcp.server.name','server.address',default='Not reported'),
                'tool': tool or text_value(attrs,'agent.activity.action',default=span['name']),
                'method': method, 'status': 'ERROR' if mcp_result_error(attrs) else span['status'],
                'time_unix_nano': span['end_ns'],
                'duration_ms': None if attrs.get('observatory.duration_unknown') else max(0, (span['end_ns']-span['start_ns'])/1e6),
                'arguments': recorded_payload(attrs,argument_keys),
                'arguments_reported': any(name in attrs for name in argument_keys),
                'output': recorded_payload(attrs,output_keys),
                'output_reported': any(name in attrs for name in output_keys),
                'source': 'span', 'log_id': None}
        for log in reversed(logs):
            attrs = json.loads(log['attributes'])
            call_id = attrs.get('observatory.mcp.call_id')
            key = log['mcp_key']
            body = json.loads(log['body'])
            try:
                details = json.loads(body) if isinstance(body, str) else body
            except ValueError:
                details = {}
            if not isinstance(details, dict):
                details = {}
            old = calls.get(key, {})
            result = str(attrs.get('agent.activity.result') or '').lower()
            state = 'ERROR' if result in {'error','failed','denied','blocked'} else 'RUNNING' if result=='started' else 'OK' if result in {'success','completed'} else old.get('status') or 'OK'
            if old.get('time_unix_nano', 0) > log['time_ns']:
                state = old.get('status') or state
            own_arguments=any(name in attrs for name in argument_keys)
            own_output=any(name in attrs for name in output_keys)
            direction=attrs.get('observatory.mcp.io.direction')
            envelope=direction is None or direction==''
            calls[key] = {**old, 'id': key, 'trace_id': log['trace_id'], 'span_id': log['span_id'],
                'session_id': log['mcp_session'],'agent_id':log['agent_id'],
                'service': log['service'],
                'server': text_value(attrs,'mcp.server.name','server.address',default=old.get('server') or 'Not reported'),
                'tool': text_value(attrs,'mcp.tool.name','gen_ai.tool.name','tool.name',default=old.get('tool') or text_value(attrs,'agent.activity.action',default='Not reported')),
                'method': text_value(attrs,'mcp.method.name','rpc.method',default=old.get('method') or 'tools/call'),
                'status': state,
                'time_unix_nano': max(log['time_ns'],old.get('time_unix_nano',0)), 'duration_ms': attrs.get('duration_ms', old.get('duration_ms')),
                'arguments': (recorded_payload(attrs,argument_keys) if own_arguments else
                              decode_tool_payload(body) if direction=='arguments' else
                              details['arguments'] if envelope and 'arguments' in details else old.get('arguments','')),
                'arguments_reported': own_arguments or direction=='arguments' or (envelope and 'arguments' in details) or old.get('arguments_reported',False),
                'output': (recorded_payload(attrs,output_keys) if own_output else
                           decode_tool_payload(body) if direction=='result' else
                           details['result'] if envelope and 'result' in details else old.get('output','')),
                'output_reported': own_output or direction=='result' or (envelope and 'result' in details) or old.get('output_reported',False),
                'metadata': {**old.get('metadata', {}), **{
                    name: value for name, value in attrs.items()
                    if name.startswith('cursor.') and not name.startswith('cursor.user.')
                    and name != 'cursor.team.id' and value is not None}},
                'source': 'session log + span' if 'span' in old.get('source', '') else 'session log', 'log_id': log['digest']}
            if mcp_result_error(attrs) or mcp_result_error({'tool.result':calls[key]['output']}):
                calls[key]['status']='ERROR'
        # Some agent frameworks emit the MCP transport and the agent's tool
        # execution as separate spans. Join those records so the MCP view can
        # show arguments and results that the transport span itself omits.
        execution_spans = []
        span_keys=[row['mcp_key'] for row in spans]
        if span_keys and has_executions:
            placeholders=','.join('?' for _ in span_keys)
            execution_spans=db.execute(f"""SELECT {call_key_sql('span','spans')} AS call_key,
                execution.trace_id,execution.span_id,execution.attributes,
                CASE WHEN execution.parent_span_id=spans.span_id OR spans.parent_span_id=execution.span_id
                    THEN 'explicit span linkage' ELSE 'single compatible recorded pair' END AS basis
                FROM spans JOIN spans execution ON {execution_match_sql()}
                WHERE {call_key_sql('span','spans')} IN ({placeholders})""",span_keys).fetchall()
        executions_by_call = {}
        for execution in execution_spans:
            executions_by_call.setdefault(execution['call_key'],[]).append(execution)

        for key, call in calls.items():
            candidates_for_call=executions_by_call.get(key,[])
            if len(candidates_for_call)!=1:
                call['execution_basis']='Not associated; execution evidence is missing or ambiguous'
                continue
            execution=candidates_for_call[0]
            attrs=json.loads(execution['attributes'])
            call['execution_basis']=execution['basis']
            call['execution_source']={'trace_id':execution['trace_id'],'span_id':execution['span_id']}
            arguments_reported=any(name in attrs for name in argument_keys)
            output_reported=any(name in attrs for name in output_keys)
            if not call.get('arguments_reported') and arguments_reported:
                call['arguments'] = recorded_payload(attrs,argument_keys)
                call['arguments_reported']=True
            if not call.get('output_reported') and output_reported:
                call['output'] = recorded_payload(attrs,output_keys)
                call['output_reported']=True
            if mcp_result_error(attrs):
                call['status'] = 'ERROR'
            if arguments_reported or output_reported:
                call['source'] = 'agent + MCP spans' if call.get('source') == 'span' else call.get('source')
        items = sorted(calls.values(),key=lambda item:item['time_unix_nano'],reverse=True)
        by_id = {item['id']: item for item in items}
        items = [by_id[key] for key in selected_keys if key in by_id]
        next_cursor = self._next_event_cursor(candidates[limit-1]['stamp'],candidates[limit-1]['call_key']) if len(candidates)>limit else None
        result = {'calls': items, 'next_cursor': next_cursor, 'summary': summary}
        if scope is not None:
            result.update(scope='agent subtree' if subtree else 'this agent', agent_scope=scope)
        return result

    def ingest_metrics(self, points):
        # We traverse points again to update endpoint inventory; accept one-shot
        # iterators just as ingest() and ingest_logs() do.
        points = list(points)
        rows = []
        for point in points:
            canonical = json.dumps(point, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            digest = hashlib.sha256(canonical.encode()).hexdigest()
            rows.append((digest, point["time_unix_nano"], point["start_unix_nano"],
                         point["service"], point["name"], point["description"],
                         point["unit"], point["kind"], point["temporality"],
                         json.dumps(point["attributes"]), json.dumps(point["resource_attributes"]),
                         point["scope_name"], json.dumps(point["data"])))
        with self._write_db() as db:
            db.executemany("""INSERT OR IGNORE INTO metric_points
                (digest,time_ns,start_ns,service,name,description,unit,kind,
                 temporality,attributes,resource_attributes,scope_name,data)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", rows)
            self._update_endpoints(db, points)
        return len(rows)

    def metric_points(self, limit=100, service=None, name=None, kind=None,
                      temporality=None, scope_name=None, unit=None, description=None):
        where = []
        values = []
        if service:
            where.append("service=?")
            values.append(service)
        if name:
            where.append("name=?")
            values.append(name)
        if kind:
            where.append("kind=?")
            values.append(kind)
        if temporality is not None:
            where.append("temporality=?")
            values.append(int(temporality))
        if scope_name is not None:
            where.append("scope_name=?")
            values.append(scope_name)
        if unit is not None:
            where.append("unit=?")
            values.append(unit)
        if description is not None:
            where.append("description=?")
            values.append(description)
        clause = " WHERE " + " AND ".join(where) if where else ""
        with self._connect() as db:
            rows = db.execute("SELECT * FROM metric_points" + clause +
                              " ORDER BY time_ns DESC LIMIT ?", (*values, limit)).fetchall()
        return [{"id": r["digest"], "time_unix_nano": r["time_ns"],
                 "start_unix_nano": r["start_ns"], "service": r["service"],
                 "name": r["name"], "description": r["description"],
                 "unit": r["unit"], "kind": r["kind"], "temporality": r["temporality"],
                 "attributes": json.loads(r["attributes"]),
                 "resource_attributes": json.loads(r["resource_attributes"]),
                 "scope_name": r["scope_name"], "data": json.loads(r["data"])} for r in rows]

    def metric_latest_points(self, limit=500, service=None):
        """Return the newest point for each catalog instrument descriptor."""
        limit = max(1, min(500, int(limit)))
        where = " WHERE service=?" if service else ""
        values = (service,) if service else ()
        with self._connect() as db:
            rows = db.execute(f"""WITH ranked AS (
                SELECT *, ROW_NUMBER() OVER (
                    PARTITION BY service,name,description,unit,kind,temporality,scope_name
                    ORDER BY time_ns DESC,digest DESC
                ) AS rank
                FROM metric_points{where}
            ) SELECT * FROM ranked WHERE rank=1 ORDER BY time_ns DESC,digest DESC LIMIT ?""",
                              (*values, limit)).fetchall()
        return [{"id": r["digest"], "time_unix_nano": r["time_ns"],
                 "start_unix_nano": r["start_ns"], "service": r["service"],
                 "name": r["name"], "description": r["description"],
                 "unit": r["unit"], "kind": r["kind"], "temporality": r["temporality"],
                 "attributes": json.loads(r["attributes"]),
                 "resource_attributes": json.loads(r["resource_attributes"]),
                 "scope_name": r["scope_name"], "data": json.loads(r["data"])} for r in rows]

    def metric_catalog(self, limit=200):
        if not 1 <= int(limit) <= 500:
            raise ValueError("limit must be between 1 and 500")
        with self._connect() as db:
            rows = db.execute("SELECT service,name,description,unit,kind,temporality,scope_name,"
                              "COUNT(*) AS point_count,MAX(time_ns) AS last_ns FROM metric_points "
                              "GROUP BY service,name,description,unit,kind,temporality,scope_name "
                              "ORDER BY last_ns DESC,service,name LIMIT ?", (int(limit),)).fetchall()
        return [dict(row) for row in rows]

    def ingest_outcomes(self, records, source="api"):
        records = list(records)
        now = time.time_ns()
        rows = []
        for record in records:
            trace_id = _id(record.get("trace_id"), TRACE_ID, "trace_id")
            passed = record.get("passed")
            if not isinstance(passed, bool):
                raise ValueError("outcome passed must be a boolean")
            scores = record.get("scores") or []
            if not isinstance(scores, list):
                raise ValueError("outcome scores must be an array")
            rows.append((trace_id, str(record.get("task_id") or ""), int(passed),
                         json.dumps(scores), str(record.get("error") or ""),
                         str(record.get("provider_model") or ""), str(source),
                         json.dumps(record), now))
        with self._source_write() as refresh:
            with self._connect() as db:
                db.executemany("""INSERT INTO outcomes VALUES (?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(trace_id) DO UPDATE SET task_id=excluded.task_id,
                    passed=excluded.passed,scores=excluded.scores,error=excluded.error,
                    provider_model=excluded.provider_model,source=excluded.source,
                    details=excluded.details,ingested_ns=excluded.ingested_ns""", rows)
                db.executemany("""INSERT INTO trace_activity(trace_id,last_ns) VALUES(?,?)
                    ON CONFLICT(trace_id) DO UPDATE SET last_ns=MAX(last_ns,excluded.last_ns)""",
                    [(row[0], now) for row in rows])
            refresh.update(row[0] for row in rows)
        return len(rows)

    def outcomes(self):
        with self._connect() as db:
            rows = db.execute("SELECT * FROM outcomes").fetchall()
        return {r["trace_id"]: self._outcome_row(r) for r in rows}

    @staticmethod
    def _outcome_row(row):
        return {"trace_id": row["trace_id"], "task_id": row["task_id"],
                "passed": bool(row["passed"]), "scores": json.loads(row["scores"]),
                "error": row["error"], "provider_model": row["provider_model"],
                "source": row["source"], "details": json.loads(row["details"]),
                "ingested_ns": row["ingested_ns"]}

    def _outcome(self, trace_id, *, _db=None):
        with self._read_db(_db) as db:
            row = db.execute("SELECT * FROM outcomes WHERE trace_id=?", (trace_id,)).fetchone()
        return self._outcome_row(row) if row else None

    def _spans(self, trace_id=None, *, _db=None):
        with self._read_db(_db) as db:
            if trace_id:
                rows = db.execute("SELECT * FROM spans WHERE trace_id=? ORDER BY start_ns,span_id", (trace_id,)).fetchall()
            else:
                rows = db.execute("SELECT * FROM spans ORDER BY start_ns,span_id").fetchall()
        return [{"trace_id": r["trace_id"], "span_id": r["span_id"],
                 "parent_span_id": r["parent_span_id"], "name": r["name"],
                 "start_unix_nano": r["start_ns"], "end_unix_nano": r["end_ns"],
                 "status": r["status"], "service": r["service"],
                 "attributes": json.loads(r["attributes"]), "events": json.loads(r["events"]),
                 "links": json.loads(r["links"]),
                 "resource_attributes": json.loads(r["resource_attributes"]),
                 "scope_name": r["scope_name"]} for r in rows]

    def span_page(self, trace_id, limit=200, cursor=None, query="", span_filter="all", *, _db=None):
        """Return a bounded, searchable page of spans for one trace."""
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        limit = int(limit)
        if not 1 <= limit <= 500:
            raise ValueError("limit must be between 1 and 500")
        if span_filter not in {"all", "errors", "models", "tools", "agents"}:
            raise ValueError("invalid span filter")
        before = None
        if cursor:
            try:
                decoded = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)).decode()
                start_ns, span_id = decoded.split(",", 1)
                before = (int(start_ns), _id(span_id, SPAN_ID, "span_id"))
                if before[0] < 0:
                    raise ValueError
            except (ValueError, UnicodeDecodeError) as exc:
                raise ValueError("invalid span cursor") from exc
        clauses = ["trace_id=?"]
        params = [trace_id]
        if query:
            clauses.append("(lower(span_id) LIKE ? ESCAPE '\\' OR lower(name) LIKE ? ESCAPE '\\' OR lower(service) LIKE ? ESCAPE '\\' OR lower(attributes) LIKE ? ESCAPE '\\')")
            needle = "%" + query.casefold().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            params.extend((needle, needle, needle, needle))
        if span_filter == "errors":
            errors = ["status='ERROR'", "attributes LIKE '%\"error.type\"%'",
                      "attributes LIKE '%\"exception.type\"%'", "attributes LIKE '%\"tool.error\"%'",
                      "lower(attributes) LIKE '%\"tool.result_status\": \"error%'"]
            errors.extend(f"json_extract(attributes,'$.\"{key}\"')=1"
                          for key in ("mcp.tool.is_error", "mcp.is_error"))
            for key in ("gcp.vertex.agent.tool_response", "gen_ai.tool.call.result"):
                value = f"json_extract(attributes,'$.\"{key}\"')"
                errors.append(f"CASE WHEN json_valid({value}) THEN "
                              f"(json_extract({value},'$.isError')=1 OR "
                              f"json_extract({value},'$.is_error')=1) ELSE 0 END")
            clauses.append("(" + " OR ".join(errors) + ")")
        elif span_filter == "models":
            clauses.append("(attributes LIKE '%\"gen_ai.request.model\"%' OR attributes LIKE '%\"llm.response.model_name\"%' OR attributes LIKE '%\"llm.request.model_name\"%' OR attributes LIKE '%\"llm.model_name\"%' OR attributes LIKE '%\"embedding.model_name\"%' OR attributes LIKE '%\"llm.model\"%' OR attributes LIKE '%\"openinference.span.kind\": \"LLM\"%' OR attributes LIKE '%\"openinference.span.kind\": \"EMBEDDING\"%' OR lower(attributes) LIKE '%\"gen_ai.operation.name\": \"chat%' OR lower(attributes) LIKE '%\"gen_ai.operation.name\": \"text_completion%' OR lower(attributes) LIKE '%\"gen_ai.operation.name\": \"embeddings%')")
        elif span_filter == "tools":
            clauses.append("(attributes LIKE '%\"tool.name\"%' OR attributes LIKE '%\"gen_ai.tool.name\"%' OR attributes LIKE '%\"mcp.tool.name\"%' OR attributes LIKE '%\"openinference.span.kind\": \"TOOL\"%' OR lower(attributes) LIKE '%\"gen_ai.operation.name\": \"execute_tool%' OR lower(name) LIKE '%tool%')")
        elif span_filter == "agents":
            clauses.append("(attributes LIKE '%\"openinference.span.kind\": \"AGENT\"%' OR lower(name) LIKE 'agent.%' OR lower(name) LIKE 'agent-%' OR lower(name) LIKE 'agent_%')")
        where = " AND ".join(clauses)
        cursor_clause = ""
        cursor_params = []
        if before:
            cursor_clause = " AND (start_ns>? OR (start_ns=? AND span_id>?))"
            cursor_params.extend((before[0], before[0], before[1]))
        with self._read_db(_db) as db:
            total = db.execute(f"SELECT COUNT(*) FROM spans WHERE {where}", params).fetchone()[0]
            rows = db.execute(f"SELECT * FROM spans WHERE {where}{cursor_clause} ORDER BY start_ns,span_id LIMIT ?",
                              [*params, *cursor_params, limit + 1]).fetchall()
            trace_total = db.execute("SELECT COUNT(*) FROM spans WHERE trace_id=?", (trace_id,)).fetchone()[0]
            bounds = db.execute("SELECT MIN(start_ns),MAX(end_ns) FROM spans WHERE trace_id=?", (trace_id,)).fetchone()
        has_more = len(rows) > limit
        visible = rows[:limit]
        next_cursor = None
        if has_more and visible:
            last = visible[-1]
            next_cursor = base64.urlsafe_b64encode(f"{last['start_ns']},{last['span_id']}".encode()).decode().rstrip("=")
        spans = [{"trace_id": r["trace_id"], "span_id": r["span_id"],
                  "parent_span_id": r["parent_span_id"], "name": r["name"],
                  "start_unix_nano": r["start_ns"], "end_unix_nano": r["end_ns"],
                  "status": r["status"], "service": r["service"],
                  "attributes": json.loads(r["attributes"]), "events": json.loads(r["events"]),
                  "links": json.loads(r["links"]),
                  "resource_attributes": json.loads(r["resource_attributes"]),
                  "scope_name": r["scope_name"]} for r in visible]
        return {"spans": spans, "total": total, "next_cursor": next_cursor,
                "trace_total": trace_total,
                "start_unix_nano": bounds[0] or 0, "end_unix_nano": bounds[1] or 0}

    def trace(self, trace_id, *, _db=None):
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        return self._derived_snapshot(lambda db:self._trace(trace_id,_db=db),_db=_db)

    def _trace(self, trace_id, *, _db):
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        spans = self._spans(trace_id,_db=_db)
        with self._read_db(_db) as db:
            log_count=db.execute('SELECT COUNT(*) FROM logs WHERE trace_id=?',(trace_id,)).fetchone()[0]
            rows = db.execute("SELECT time_ns,stage,message,percent,session_id,service FROM progress WHERE trace_id=? ORDER BY time_ns,id", (trace_id,)).fetchall()
            indexed_agents={row[0] for row in db.execute(
                "SELECT agent_id FROM spans WHERE trace_id=? AND agent_id IS NOT NULL UNION "
                "SELECT agent_id FROM logs WHERE trace_id=? AND agent_id IS NOT NULL",(trace_id,trace_id))}
        progress = [dict(r) for r in rows]
        logs = self.logs(trace_id, limit=1000,_db=_db)
        activity = _activity_for(spans, logs)
        outcome = self._outcome(trace_id,_db=_db)
        for log in logs:
            progress_event = _progress_from_log(log)
            if progress_event is not None:
                progress.append(progress_event)
        progress.sort(key=lambda x: x["time_ns"])
        timeline = progress or [{"time_ns": log["time_unix_nano"]} for log in reversed(logs)]
        summary = summarize(spans) if spans else summarize_progress(trace_id, timeline) if timeline else None
        if summary and not spans and logs:
            summary["services"] = sorted(set(summary["services"]) | {log["service"] for log in logs})
        if outcome:
            summary = apply_outcome(summary or summarize_progress(trace_id, [{"time_ns": outcome["ingested_ns"]}]), outcome)
        lifecycle = [event for event in progress if event.get("status") in {"RUNNING", "OK"}]
        if summary and lifecycle and not outcome and lifecycle[-1]['time_ns'] >= summary.get('task_outcome_ns', 0):
            summary['task_outcome'] = 'running' if lifecycle[-1]['status'] == 'RUNNING' else 'completed'
            summary['task_outcome_ns'] = lifecycle[-1]['time_ns']
        if summary and not outcome:
            for log in sorted(logs, key=lambda event: (event['time_unix_nano'],event['id'])):
                signal = _task_outcome_from_log(log.get('attributes') or {}, log.get('event_name'))
                if signal and (summary.get('task_outcome') == 'unknown' or log['time_unix_nano'] >= summary.get('task_outcome_ns', 0)):
                    summary.update(task_outcome=signal, task_outcome_ns=log['time_unix_nano'])
        if summary and lifecycle and summary.get("status") not in {"ERROR", "FAILED", "INCOMPLETE"}:
            summary["status"] = lifecycle[-1]["status"]
            summary["active"] = summary["status"] == "RUNNING"
        session_id = _session_for(spans, progress, logs)
        if summary:
            summary['agent_count']=len(indexed_agents | _recorded_activity_agents(spans,logs))
            summary['agent_count_complete']=True
            summary['review_owner']=_review_owner(spans,logs,activity,
                complete=summary['agent_count']==1 and log_count==len(logs) and not rows)
            summary["session_id"] = session_id
            summary["activity_terms"] = sorted({str(value)[:200] for item in activity
                for value in (item["domain"], item["action"], item["subject"], item["actor"]) if value})
            searchable_attributes = ("tool.name", "tool.type", "gen_ai.tool.name", "gen_ai.tool.type",
                                    "exception.type", "error.type", "gen_ai.provider.name",
                                    "gen_ai.operation.name",
                                    "openai_agents.workflow", "mcp.method.name", "mcp.server.name",
                                    "db.system", "http.request.method")
            summary["span_terms"] = sorted({str(value)[:200] for span in spans
                for value in (span["name"], *(span["attributes"].get(key)
                    for key in searchable_attributes))
                if isinstance(value, (str, int, float)) and str(value).strip()})
            summary["log_terms"] = sorted({str(value)[:200] for log in logs
                for value in (log.get("event_name"), log.get("severity_text")) if value})
        return {"trace_id": trace_id, "spans": spans, "progress": progress, "logs": logs,
                "activity": activity,
                "outcome": outcome, "findings": self._trace_findings(trace_id,_db=_db),
                "session_id": session_id, "summary": summary}

    def trace_overview(self, trace_id, *, _db=None):
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        return self._derived_snapshot(lambda db:self._trace_overview(trace_id,_db=db),_db=_db)

    def _trace_overview(self, trace_id, *, _db):
        """Load trace panels from derived indexes without decoding every span."""
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        with self._read_db(_db) as db:
            row = db.execute("SELECT summary_json,activity_json FROM trace_summaries WHERE trace_id=?",
                             (trace_id,)).fetchone()
        if row is None and self._trace_source_exists(_db,trace_id):
            raise IndexNotReady(dict(ready=False,stage='Run summary is catching up'),repair_traces=(trace_id,))
        with self._read_db(_db) as db:
            rows = db.execute("SELECT time_ns,stage,message,percent,session_id,service FROM progress "
                              "WHERE trace_id=? ORDER BY time_ns,id", (trace_id,)).fetchall()
        progress = [dict(item) for item in rows]
        logs = self.logs(trace_id, limit=1000,_db=_db)
        for log in logs:
            event = _progress_from_log(log)
            if event is not None:
                progress.append(event)
        progress.sort(key=lambda item: item["time_ns"])
        summary = json.loads(row["summary_json"]) if row else None
        outcome = self._outcome(trace_id,_db=_db)
        if outcome:
            summary = apply_outcome(summary or summarize_progress(trace_id,
                [{"time_ns": outcome["ingested_ns"]}]), outcome)
        return {"trace_id": trace_id, "spans": [], "progress": progress, "logs": logs,
                "activity": json.loads(row["activity_json"]) if row else [],
                "outcome": outcome, "findings": self._trace_findings(trace_id,_db=_db),
                "session_id": summary.get("session_id") if summary else None,
                "summary": summary}

    def investigation_page(self, kind, query, *, limit=50, cursor=None, service=None,
                           failed=False, agent_id=None, subtree=False, scope_revision=None):
        from .storage_investigation import read_page
        with self._connect() as db:
            db.execute('BEGIN')
            self._investigation_ready(db)
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            scope=self.resolve_agent_scope(agent_id,include_subagents=bool(subtree),_db=db) if agent_id else None
            if scope_revision and (scope is None or scope_revision!=scope['revision']):
                raise ValueError('hierarchy scope changed')
            result=read_page(db,kind,query,limit=limit,cursor=cursor,receiver=receiver,
                service=service,failed=failed,agent_ids=scope['agent_ids'] if scope else None)
            if scope is not None:result['agent_scope']=scope
            return result

    def _investigation_ready(self, db):
        available=db.execute("SELECT value FROM schema_meta WHERE key='investigation_available_v1'").fetchone()
        if not available or available[0]!='1':
            raise ValueError('Typed investigations require SQLite FTS5; no history-scan fallback is available.')
        if db.execute('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM investigation_dirty_v1 LIMIT 1').fetchone():
            raise ValueError('Investigation index is catching up; retry after receiver migration completes')

    def investigation_source(self, event_id, receiver_id, reference):
        from .investigation import decode_reference, reference_matches, source_reference
        from .finding_sources import read_sources
        expected=decode_reference(reference)
        if expected['event_id']!=event_id or expected['receiver_id']!=receiver_id:
            raise ValueError('Source reference differs from the selected event/receiver')
        with self._connect() as db:
            db.execute('BEGIN')
            self._investigation_ready(db)
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            if receiver!=receiver_id:raise ValueError('Receiver identity changed; source is withheld')
            row=db.execute('SELECT * FROM activity_index_v1 WHERE event_key=?',(event_id,)).fetchone()
            if not row:raise ValueError('Source is no longer retained')
            event=json.loads(row['payload'])
            event.update({key:row[key] for key in ('trace_id','turn_id','service','agent_id','session_id')})
            current=source_reference({**event,'id':event_id},receiver)
            if not reference_matches(expected,current):raise ValueError('Source execution changed; evidence is withheld')
            result=read_sources(db,dict(trace_id=current['trace_id'],evidence=[dict(type=current['source'],id=current['source_id'])]))
            keys=('service','agent_id','session_id','trace_id','span_id','turn_id')
            if any(any(key not in source.get('scope',{}) or source['scope'][key]!=current.get(key) for key in keys)
                   for source in result['sources']):
                raise ValueError('Actual source execution differs from the pinned reference')
            return dict(receiver_id=receiver,event_id=event_id,source_reference=current,**result)
    def native_lifecycle_inventory(self):
        from .storage_native_lifecycle import read_inventory
        with self._connect() as db:
            db.execute('BEGIN')
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            if db.execute('SELECT 1 FROM activity_dirty_v1 UNION ALL SELECT 1 FROM native_lifecycle_dirty_v1 LIMIT 1').fetchone():
                return dict(receiver_id=receiver,observations=[],complete=False,warning='Native source index is catching up.')
            return read_inventory(db,receiver)

    def findings(self, limit=100):
        return self.finding_page(limit=limit)["findings"]

    def finding_page(self, limit=100, cursor=None, agent_id=None, subtree=False,
                     scope_revision=None):
        if not 1 <= int(limit) <= 500:raise ValueError('limit must be between 1 and 500')
        before=None
        if cursor:
            try:
                decoded=base64.urlsafe_b64decode(cursor+'='*(-len(cursor)%4)).decode()
                stamp,identity=decoded.split(',',1);before=(int(stamp),identity)
                if before[0]<0 or not re.fullmatch(r'[0-9a-f]{16}',identity):raise ValueError
            except (ValueError,UnicodeDecodeError) as exc:raise ValueError('invalid cursor') from exc
        with self._connect() as db:
            db.execute('BEGIN')
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            if not db.execute("SELECT 1 FROM schema_meta WHERE key='trace_derived_v15'").fetchone() or db.execute('SELECT 1 FROM finding_dirty_v1 LIMIT 1').fetchone():
                raise ValueError('Findings index is catching up; retry after receiver migration completes')
            agent_scope=None;filters=[];params=[]
            if not self.workflow_patterns:filters.append("COALESCE(json_extract(finding_json,'$.workflow_pattern'),0)!=1")
            if agent_id:
                agent_scope=self.resolve_agent_scope(agent_id,include_subagents=bool(subtree),_db=db)
                if scope_revision and scope_revision!=agent_scope['revision']:raise ValueError('hierarchy scope changed')
                ids=agent_scope['agent_ids']
                filters.append('agent_id IN ('+','.join('?' for _ in ids)+')' if ids else '0')
                params.extend(ids)
            # Use identical owner filters for page rows and aggregate counts.
            where=' AND '.join(filters) or '1'
            page_where=where;page_params=list(params)
            if before:
                page_where+=' AND (time_ns<? OR (time_ns=? AND finding_id<?))'
                page_params.extend((before[0],before[0],before[1]))
            rows=db.execute('SELECT * FROM finding_cache WHERE '+page_where+
                ' ORDER BY time_ns DESC,finding_id DESC LIMIT ?',[*page_params,int(limit)+1]).fetchall()
            visible=rows[:int(limit)];findings=[]
            keys=list(dict.fromkeys(row['group_key'] or row['finding_id'] for row in visible))
            stats={}
            if keys:
                marks=','.join('?' for _ in keys)
                for row in db.execute('''SELECT group_key AS signature,COUNT(*) AS occurrences,
                    COUNT(DISTINCT trace_id) AS traces,
                    COUNT(DISTINCT CASE WHEN producer IS NOT NULL AND session_id IS NOT NULL
                        THEN json_array(producer,session_id) END) AS sessions
                    FROM finding_cache WHERE '''+where+' AND group_key IN ('+marks+') GROUP BY signature',
                    [*params,*keys]):
                    stats[row['signature']]=dict(occurrence_count=row['occurrences'],trace_count=row['traces'],session_count=row['sessions'])
            for row in visible:
                item=json.loads(row['finding_json'])
                # Legacy rows remain readable globally, without inferred root context.
                item.update(agent_id=row['agent_id'],session_id=row['session_id'],producer=row['producer'],
                    service=row['producer'],receiver_id=receiver,services=[row['producer']] if row['producer'] else [],
                    task='',run_status='UNKNOWN',time_unix_nano=row['time_ns'])
                item.update(stats.get(row['group_key'] or row['finding_id'],
                    dict(occurrence_count=1,trace_count=1,session_count=int(bool(row['producer'] and row['session_id'])))))
                findings.append(item)
            next_cursor=None
            if len(rows)>int(limit) and visible:
                last=visible[-1]
                next_cursor=base64.urlsafe_b64encode(f"{last['time_ns']},{last['finding_id']}".encode()).decode().rstrip('=')
            result=dict(findings=findings,next_cursor=next_cursor,has_more=len(rows)>int(limit),
                receiver_id=receiver,count_basis='retained finding occurrences; not unique executions',
                ownership_ready=bool(db.execute("SELECT 1 FROM schema_meta WHERE key='trace_derived_v15'").fetchone()))
            if agent_scope is not None:result['agent_scope']=agent_scope
            return result

    def finding_source(self, finding_id):
        if not isinstance(finding_id,str) or not re.fullmatch(r'[0-9a-f]{16}',finding_id):raise ValueError('invalid finding_id')
        from .finding_sources import read_sources
        with self._connect() as db:
            db.execute('BEGIN')
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            if db.execute('SELECT 1 FROM finding_dirty_v1 LIMIT 1').fetchone():
                raise ValueError('Findings index is catching up; retry after receiver migration completes')
            row=db.execute('SELECT finding_json,agent_id,session_id,producer FROM finding_cache WHERE finding_id=?',(finding_id,)).fetchone()
            if not row:return dict(receiver_id=receiver,finding_id=finding_id,sources=[],unavailable=True)
            finding=json.loads(row['finding_json'])
            finding.update(agent_id=row['agent_id'],session_id=row['session_id'],service=row['producer'])
            identity={key:finding.get(key) for key in ('service','agent_id','session_id','trace_id','turn_id')}
            return dict(receiver_id=receiver,finding_id=finding_id,finding_scope=identity,**read_sources(db,finding))

    def _trace_findings(self, trace_id, *, _db=None):
        with self._read_db(_db) as db:
            rows = db.execute("SELECT finding_json FROM finding_cache WHERE trace_id=? "
                              + ("" if self.workflow_patterns else "AND COALESCE(json_extract(finding_json,'$.workflow_pattern'),0)!=1 ") +
                              "ORDER BY time_ns DESC,finding_id", (trace_id,)).fetchall()
        return [json.loads(row["finding_json"]) for row in rows]

    def sessions(self, limit=100,*,_initial_receiver=None,_initial_file=None):
        if not 1 <= int(limit) <= 500:
            raise ValueError("limit must be between 1 and 500")
        if _initial_file is not None:
            try:
                with self._source_read('Sessions')as db:
                    db.execute('BEGIN')
                    self._require_initial_sessions(db,_initial_receiver,_initial_file)
                    return self._sessions(limit,_db=db)
            except (OSError,sqlite3.Error)as exc:
                raise IndexNotReady({**self.migration_status,'ready':False,'stage':'Sessions preparation proof is unavailable'})from exc
        return self._derived_snapshot(lambda db:self._sessions(limit,_db=db))

    def _sessions(self, limit=100, *, _db):
        with self._read_db(_db) as db:
            receiver=db.execute("SELECT value FROM schema_meta WHERE key='receiver_id'").fetchone()[0]
            from .storage_sessions import session_projection
            rows,session_totals,initial_tasks=session_projection(db,int(limit))
            legacy_latest=[];seen_sessions=set()
            for row in rows:
                key=(row['session_id'],row['agent_id'])
                if key in seen_sessions:continue
                seen_sessions.add(key)
                if len(legacy_latest)<500 and 'agent_count' not in json.loads(row['summary_json']):legacy_latest.append(row['trace_id'])
            legacy_agent_counts={trace:0 for trace in legacy_latest}
            for offset in range(0,len(legacy_latest),200):
                selected=legacy_latest[offset:offset+200];marks=','.join('?' for _ in selected)
                counts=db.execute(f"SELECT trace_id,COUNT(DISTINCT agent_id) FROM ("
                    f"SELECT trace_id,agent_id FROM spans WHERE trace_id IN ({marks}) UNION ALL "
                    f"SELECT trace_id,agent_id FROM logs WHERE trace_id IN ({marks})) GROUP BY trace_id",
                    [*selected,*selected]).fetchall()
                legacy_agent_counts.update((row[0],row[1]) for row in counts)
            session_expr = _session_sql_expression("l")
            log_sessions = db.execute(f"""SELECT {session_expr} AS session_id,MAX(l.time_ns) AS last_ns
                FROM logs l WHERE {session_expr} IS NOT NULL
                GROUP BY {session_expr} ORDER BY last_ns DESC,session_id DESC LIMIT ?""",
                (int(limit),)).fetchall()
            log_rows = []
            log_usage_rows = []
            if log_sessions:
                session_ids = [session["session_id"] for session in log_sessions]
                placeholders = ",".join("?" for _ in session_ids)
                fields=('input_tokens','output_tokens','cache_read_input_tokens','cache_write_input_tokens','reasoning_output_tokens')
                selected=[]
                for field in fields:selected.extend([f'COALESCE(SUM(l.{field}),0) AS {field}',f'MAX(l.{field}_reported) AS {field}_reported'])
                log_usage_rows=db.execute('SELECT l.session_id,'+','.join(selected)+' FROM live_log_usage_v1 l WHERE l.session_id IN ('+placeholders+') AND NOT EXISTS(SELECT 1 FROM live_summaries_v1 s WHERE s.session_id=l.session_id) GROUP BY l.session_id',session_ids).fetchall()
            if log_sessions:
                # Filter scalar source identities before reading any captured
                # payload. Native logs already covered by a run summary need
                # neither JSON parsing nor another preview of their bodies.
                # Both joined tables have trace_id primary keys: each retained
                # owner/cutoff has one row, so aggregation cannot add evidence.
                requested_values=','.join(f'(?,{index})' for index in range(len(log_sessions)))
                log_rows.extend(db.execute(f"""WITH requested(session_id,session_position) AS (
                    VALUES {requested_values}), covered AS (
                    SELECT summary.trace_id,summary.agent_id,activity.last_ns AS last_ns
                    FROM live_summaries_v1 summary JOIN trace_activity activity USING(trace_id)
                    WHERE summary.agent_id IS NOT NULL), candidates AS (
                    SELECT requested.session_id,activity.owner_key AS digest,activity.stamp AS stamp
                    FROM activity_index_v1 activity JOIN requested ON requested.session_id=activity.session_id
                    LEFT JOIN covered ON covered.trace_id=activity.trace_id
                        AND activity.agent_id IS NOT NULL AND covered.agent_id=activity.agent_id
                        AND covered.last_ns>=activity.stamp
                    WHERE activity.kind='log' AND covered.trace_id IS NULL
                    UNION ALL
                    SELECT requested.session_id,l.digest,l.time_ns AS stamp FROM logs l
                    JOIN requested ON requested.session_id={session_expr}
                    WHERE l.event_name!='agent.activity'), ranked AS (
                    SELECT *,ROW_NUMBER() OVER(PARTITION BY session_id ORDER BY stamp DESC,digest DESC) AS position
                    FROM candidates)
                    SELECT l.digest,l.span_id,l.trace_id,l.time_ns,l.service,l.event_name,l.severity_number,
                        l.attributes,l.resource_attributes,l.body,{session_expr} AS session_id
                    FROM ranked JOIN requested USING(session_id) JOIN logs l USING(digest)
                    WHERE ranked.position<=50
                    ORDER BY requested.session_position,ranked.stamp DESC,ranked.digest DESC""",
                    [session['session_id'] for session in log_sessions]).fetchall())
            # Error reminders use bounded concrete evidence, never lifetime totals.
            # Read only the newest two traces for each execution identity.
            recent_traces = set()
            trace_counts = {}
            for row in rows:
                key = (row['session_id'], row['agent_id'])
                trace_counts[key] = trace_counts.get(key, 0) + 1
                if trace_counts[key] <= 2:
                    recent_traces.add(row['trace_id'])
            reminder_events = []
            selected_traces = sorted(recent_traces)
            for offset in range(0, len(selected_traces), 200):
                selected = selected_traces[offset:offset + 200]
                marks = ','.join('?' for _ in selected)
                for row in db.execute(f'SELECT error_refs_json FROM trace_summaries WHERE trace_id IN ({marks})', selected):
                    reminder_events.extend(json.loads(row['error_refs_json']))
        grouped = {}
        for row in rows:
            summary = json.loads(row["summary_json"])
            agent_key = row["agent_id"] or summary.get("agent_id")
            key = (row["session_id"], agent_key)
            item = grouped.setdefault(key, {
                "session_id": row["session_id"], "agent_id": agent_key,
                "trace_count": 0, "errors": 0,
                "failed": 0, "incomplete": 0, "issues": 0,
                "input_tokens": 0, "output_tokens": 0, "span_count": 0,
                "cache_read_input_tokens": 0, "cache_write_input_tokens": 0,
                "reasoning_output_tokens": 0,
                "input_tokens_reported": False, "output_tokens_reported": False,
                "cache_read_input_tokens_reported": False,
                "cache_write_input_tokens_reported": False,
                "reasoning_output_tokens_reported": False,
                "known_cost_usd": 0.0, "unknown_cost_runs": 0, "cost_complete": True,
                "services": set(), "models": set(), "latest_trace_id": row["trace_id"],
                "last_unix_nano": row["last_ns"], "latest_status": "UNKNOWN",
                "latest_task": None, "latest_waiting_for": None, "project": None})
            item["usage_complete"] = item.get("usage_complete", True) and summary.get("usage_complete", True)
            item["status_complete"] = item.get("status_complete", True) and summary.get("status_complete", True)
            if item["trace_count"] == 0:
                usage_fields=("trace_id","task","input_tokens","output_tokens",
                              "cache_read_input_tokens","cache_write_input_tokens","reasoning_output_tokens",
                              "input_tokens_reported","output_tokens_reported","cache_read_input_tokens_reported",
                              "cache_write_input_tokens_reported","reasoning_output_tokens_reported",
                              "known_cost_usd","cost_complete","usage_complete","task_outcome","task_outcome_ns",
                              "agent_id","agent_count","agent_count_complete","review_owner","waiting_for","turn_id")
                item["latest_run"]={key:summary[key] for key in usage_fields if key in summary}
                item["latest_run"]["trace_id"]=row["trace_id"]
                if row['trace_id'] in legacy_agent_counts:
                    item['latest_run'].update(agent_count=legacy_agent_counts[row['trace_id']],agent_count_complete=False)
                item["latest_status"] = summary.get("status") or "UNKNOWN"
                item["latest_task_outcome"] = summary.get("task_outcome") or "unknown"
                item["task_outcome_ns"] = summary.get("task_outcome_ns") or 0
                item["task_waiting_for"] = summary.get("waiting_for")
                item["latest_task"] = summary.get("task")
                item["latest_waiting_for"] = summary.get("waiting_for")
                item["project"] = summary.get("project")
                for key in ("agent_id", "agent_native_id", "parent_agent_native_id",
                            "agent_namespace", "agent_worker_id", "relationship_kind",
                            "relationship_state", "relationship_provenance"):
                    if summary.get(key):
                        item[key] = summary[key]
            if summary.get("initial_task") and not item.get("initial_task"):
                item["initial_task"] = summary["initial_task"]
            item["trace_count"] += 1
            item["span_count"] += int(summary.get("span_count") or 0)
            status = summary.get("status")
            item["errors"] += status == "ERROR"
            item["failed"] += status == "FAILED" or summary.get("outcome_passed") is False
            item["incomplete"] += status == "INCOMPLETE"
            item["issues"] += status in {"ERROR", "FAILED", "INCOMPLETE"} or summary.get("outcome_passed") is False
            item["input_tokens"] += int(summary.get("input_tokens") or 0)
            item["output_tokens"] += int(summary.get("output_tokens") or 0)
            item["cache_read_input_tokens"] += int(summary.get("cache_read_input_tokens") or 0)
            item["cache_write_input_tokens"] += int(summary.get("cache_write_input_tokens") or 0)
            item["reasoning_output_tokens"] += int(summary.get("reasoning_output_tokens") or 0)
            for field in ("cache_read_input_tokens", "cache_write_input_tokens", "reasoning_output_tokens"):
                item[f"{field}_reported"] |= bool(summary.get(f"{field}_reported"))
            item["input_tokens_reported"] |= bool(summary.get("input_tokens_reported"))
            item["output_tokens_reported"] |= bool(summary.get("output_tokens_reported"))
            item["known_cost_usd"] += float(summary.get("known_cost_usd") or 0)
            cost_complete = bool(summary.get("cost_complete", False))
            item["unknown_cost_runs"] += not cost_complete
            item["cost_complete"] &= cost_complete
            from .storage_derived import merge_labels
            merge_labels(item, "services", summary.get("services", []), summary.get("services_complete", True))
            merge_labels(item, "models", summary.get("models", []), summary.get("models_complete", True))

        for key,totals in session_totals.items():
            if key in grouped:
                grouped[key].update(totals)
                # Recover the most recent recorded original task even if the
                # latest two runs did not repeat that optional metadata.
                if not grouped[key].get('initial_task'):
                    if key in initial_tasks:grouped[key]['initial_task']=initial_tasks[key]

        # Some runtimes emit session-tagged events without trace context. Keep
        # those sessions visible in the roster instead of making Activity the
        # only place their work can be found.
        from .error_reminders import failure
        for row in log_rows:
            session_id = _session_value(row["session_id"])
            if not session_id:
                continue
            attrs = json.loads(row["attributes"])
            resource = json.loads(row["resource_attributes"])
            try:
                body = json.loads(row["body"])
            except (TypeError, ValueError):
                body = ""
            if row['event_name'] == 'agent.activity':
                event = _activity_row(attrs, row['time_ns'], 'log', row['digest'],
                                      row['span_id'],row['service'],body,
                                      resource_attributes=resource)
                # Unqualified nonfailure labels cannot supply input identity or
                # a terminal failure, so projecting/hashing their output again
                # cannot contribute reminder or recovery evidence. All typed
                # roles and recorded failures retain the full conservative path.
                if event.get('detail_role')=='operation_v1' or failure(event):
                    reminder_events.append({**event, 'trace_id': row['trace_id'],
                        'id': (row['trace_id'] or 'log') + ':' + row['digest'],'receiver_id':receiver})
            log_agent_id = _agent_id_from_attributes(attrs, resource, row["service"])
            key = (session_id, log_agent_id)
            item = grouped.get(key)
            if item is None:
                item = grouped[key] = {
                    "session_id": session_id, "trace_count": 0, "errors": 0,
                    "agent_id": log_agent_id,
                    "agent_native_id": attrs.get("agent.id"),
                    "parent_agent_native_id": attrs.get("agent.parent_id"),
                    "agent_namespace": attrs.get("agent.namespace"),
                    "agent_worker_id": attrs.get("agent.worker_id"),
                    "relationship_kind": attrs.get("agent.relationship.kind"),
                    "relationship_state": attrs.get("agent.relationship.state"),
                    "relationship_provenance": attrs.get("agent.relationship.provenance"),
                    "failed": 0, "incomplete": 0, "issues": 0,
                    "input_tokens": 0, "output_tokens": 0, "span_count": 0,
                    "cache_read_input_tokens": 0, "cache_write_input_tokens": 0,
                    "reasoning_output_tokens": 0,
                    "cache_read_input_tokens_reported": False,
                    "cache_write_input_tokens_reported": False,
                    "reasoning_output_tokens_reported": False,
                    "input_tokens_reported": False, "output_tokens_reported": False,
                    "known_cost_usd": 0.0, "unknown_cost_runs": 0, "cost_complete": True,
                    "services": set(), "models": set(), "latest_trace_id": row["trace_id"],
                    "last_unix_nano": row["time_ns"], "latest_status": "RUNNING",
                    "latest_task_outcome": "unknown", "task_outcome_ns": 0,
                    "latest_task": None, "latest_waiting_for": None, "project": None,
                    "_latest_log_ns": row["time_ns"]}
            item.setdefault("_latest_log_ns", 0)
            trace_last_ns = item.get("last_unix_nano", 0) if item["trace_count"] else 0
            item.setdefault("_trace_last_ns", trace_last_ns)
            item.setdefault("_latest_signal_ns", trace_last_ns)
            item.setdefault("_latest_task_ns", trace_last_ns if item["trace_count"] else 0)
            item["services"].add(row["service"])
            item["last_unix_nano"] = max(item["last_unix_nano"], row["time_ns"])
            if row["time_ns"] >= item.get("_latest_log_ns", 0):
                item["_latest_log_ns"] = row["time_ns"]
                if row["trace_id"]:
                    item["latest_trace_id"] = row["trace_id"]
                if row["time_ns"] >= item.get("_trace_last_ns", 0):
                    item["latest_waiting_for"] = _waiting_for(attrs)
            initial_task = attrs.get("agent.session.task")
            if initial_task and not item.get("initial_task"):
                from .session_text import task_description
                item["initial_task"] = task_description(initial_task)[:500]
            task = attrs.get("agent.task") or attrs.get("task")
            source_event = attrs.get("observatory.source.event_name") or row["event_name"]
            if (not task and source_event == "cursor.conversation.user_message"
                    and isinstance(body, str)):
                task = body
            if task and row["time_ns"] >= item.get("_latest_task_ns", 0):
                item["_latest_task_ns"] = row["time_ns"]
                item["latest_task"] = str(task)[:2000]
            model = (attrs.get("gen_ai.request.model") or attrs.get("model") or
                     attrs.get("model_name"))
            if model:
                item["models"].add(str(model))
            if not item["project"]:
                item["project"] = next((resource.get(key) for key in
                    ("vcs.repository.name", "project.name", "repository.name")
                    if resource.get(key)), None)
                if not item["project"]:
                    repo_url = attrs.get("vcs.repository.url") or resource.get("vcs.repository.url")
                    if isinstance(repo_url, str) and repo_url.strip():
                        item["project"] = repo_url.rstrip("/").removesuffix(".git").rsplit("/", 1)[-1]

            result = str(attrs.get("agent.activity.result") or "").casefold()
            is_error = (source_event == "gemini_cli.api_error" or result in
                        {"error", "failed", "denied", "blocked"} or row["severity_number"] >= 17)
            is_lifecycle = source_event in {"gemini_cli.agent.start", "gemini_cli.agent.finish"}
            waiting_for = _waiting_for(attrs)
            # Tool failures remain error evidence. Only lifecycle/explicit input
            # signals can change the task outcome, including log-only sessions.
            task_signal = _task_outcome_from_log(attrs, source_event)
            if task_signal and (row["time_ns"] > item.get("task_outcome_ns", 0) or
                                (row["time_ns"] == item.get("task_outcome_ns", 0) and
                                 not item["trace_count"] and not item.get("_task_signal_seen"))):
                item["latest_task_outcome"] = task_signal
                item["task_outcome_ns"] = row["time_ns"]
                item["task_waiting_for"] = waiting_for if task_signal == "waiting" else ""
                item["_task_signal_seen"] = True
            if is_error and not item["trace_count"]:
                item["_log_error"] = True
            if is_lifecycle or is_error or waiting_for or row["time_ns"] > item.get("_trace_last_ns", 0):
                if row["time_ns"] >= item.get("_latest_signal_ns", 0):
                    item["_latest_signal_ns"] = row["time_ns"]
                    item["latest_waiting_for"] = waiting_for
                    if waiting_for:
                        item["latest_status"] = "WAITING"
                    elif source_event == "gemini_cli.agent.finish":
                        item["latest_status"] = "OK"
                    elif source_event == "gemini_cli.agent.start":
                        item["latest_status"] = "RUNNING"
                    elif source_event == "cursor.grok_bot.routine_run":
                        item["latest_status"] = ("ERROR" if result == "error" else
                            "INCOMPLETE" if result == "cancelled" else "OK")
                    elif source_event == "gemini_cli.agent.start":
                        item["latest_status"] = "RUNNING"
                    elif is_error:
                        item["latest_status"] = "ERROR"
                    else:
                        item["latest_status"] = "RUNNING"

        # Aggregate every log-only usage event. The visible event preview above
        # is intentionally bounded to 50 rows per session and must not cap the
        # session's cumulative token totals.
        for usage in log_usage_rows:
            candidates = [item for key, item in grouped.items()
                          if key[0] == usage["session_id"] and item["trace_count"] == 0]
            if not candidates:
                continue
            if len(candidates) > 1:
                # Shared session IDs are not sufficient to split log-only usage
                # across workers. Do not invent a division.
                for item in candidates:
                    item["usage_complete"] = False
                continue
            item = candidates[0]
            for field in ("input_tokens", "output_tokens", "cache_read_input_tokens",
                          "cache_write_input_tokens", "reasoning_output_tokens"):
                item[field] += int(usage[field] or 0)
                if f"{field}_reported" in usage.keys():
                    item[f"{field}_reported"] |= bool(usage[f"{field}_reported"])
        for item in grouped.values():
            if item["trace_count"] == 0 and item.pop("_log_error", False):
                item["errors"] = 1
                item["issues"] = 1
            item.pop("_latest_log_ns", None)
            item.pop("_latest_signal_ns", None)
            item.pop("_trace_last_ns", None)
            item.pop("_latest_task_ns", None)
            item.pop("_task_signal_seen", None)
            latest_wait = item.pop("latest_waiting_for", None) or ""
            task_wait = item.pop("task_waiting_for", None)
            item["waiting_for"] = (task_wait or latest_wait
                                   if item.get("latest_task_outcome") == "waiting" else latest_wait)
        from .error_reminders import error_reference, pending_failures
        errors_by_owner = {}
        for event in reminder_events:
            key = (event.get('session_id'), event.get('agent_id'))
            errors_by_owner.setdefault(key, []).append(event)
        result = []
        for item in grouped.values():
            # Metadata references only; full captured errors stay in Activity.
            item['recent_errors'] = [error_reference(event)
                for event in pending_failures(errors_by_owner.get((item['session_id'],item.get('agent_id')),[]),
                                              receiver=receiver)]
            item["known_cost_usd"] = round(item["known_cost_usd"], 8)
            from .storage_derived import finalize_usage
            finalize_usage(item)
            item["services"] = sorted(item["services"])
            item["models"] = sorted(item["models"])
            result.append(item)
        result.sort(key=lambda item: (item["last_unix_nano"], item["session_id"]), reverse=True)
        for item in result[:int(limit)]:
            latest=item.get('latest_run') or {}
            if latest.get('turn_id'):
                latest['turn_usage']=self.review_turn(latest['trace_id'],_db=db)
        return result[:int(limit)]

    def related_traces(self, trace_id):
        trace_id = _id(trace_id, TRACE_ID, "trace_id")
        relations = {}
        groups = {}
        for span in self._spans():
            groups.setdefault(span["trace_id"], []).append(span)
            for link in span["links"]:
                target = link["trace_id"]
                if span["trace_id"] == trace_id and target != trace_id:
                    relations.setdefault((target, "outgoing"), []).append({
                        "source_span_id": span["span_id"], "linked_span_id": link["span_id"]})
                if target == trace_id and span["trace_id"] != trace_id:
                    relations.setdefault((span["trace_id"], "incoming"), []).append({
                        "source_span_id": span["span_id"], "linked_span_id": link["span_id"]})
        return [{"trace_id": target, "direction": direction, "edges": edges,
                 "summary": summarize(groups[target]) if target in groups else None}
                for (target, direction), edges in sorted(relations.items())]

    def trace_page(self, limit=100, service=None, status=None, cursor=None, session_id=None,
                   search=None, endpoint_id=None, include_reviews=True, agent_id=None,
                   subtree=False, scope_revision=None):
        return self._derived_snapshot(lambda db:self._trace_page(limit,service,status,cursor,
            session_id,search,endpoint_id,include_reviews,agent_id,subtree,scope_revision,_db=db))

    def _trace_page(self, limit=100, service=None, status=None, cursor=None, session_id=None,
                   search=None, endpoint_id=None, include_reviews=True, agent_id=None,
                   subtree=False, scope_revision=None, *, _db):
        if not 1 <= int(limit) <= 500:
            raise ValueError("limit must be between 1 and 500")
        if session_id is not None:
            session_id = _session_value(session_id)
            if session_id is None:
                raise ValueError("invalid session_id")
        agent_scope = None
        if agent_id:
            agent_scope = self.resolve_agent_scope(agent_id, include_subagents=bool(subtree),_db=_db)
            if scope_revision and scope_revision != agent_scope["revision"]:
                raise ValueError("hierarchy scope changed")
            if not agent_scope["agent_ids"]:
                return {"traces": [], "next_cursor": None, "has_more": False,
                        "agent_scope": agent_scope}
        search = str(search or "").strip()[:200].casefold()
        if endpoint_id is not None:
            if not isinstance(endpoint_id, str) or not re.fullmatch(r"[0-9a-fA-F]{32}", endpoint_id):
                raise ValueError("invalid endpoint_id")
            endpoint_id = endpoint_id.lower()
        before = None
        if cursor:
            try:
                decoded = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)).decode()
                before_ns, before_id = decoded.split(",", 1)
                before = (int(before_ns), _id(before_id, TRACE_ID, "cursor trace_id"))
            except (ValueError, UnicodeDecodeError) as exc:
                raise ValueError("invalid cursor") from exc

        selected = []
        page_cursor = before
        batch_size = max(50, min(250, int(limit) * 2))
        exhausted = False
        while len(selected) <= int(limit):
            sql = "SELECT a.trace_id,a.last_ns,s.summary_json FROM trace_activity AS a " \
                  "LEFT JOIN trace_summaries AS s ON s.trace_id=a.trace_id"
            conditions = []
            params = []
            if page_cursor:
                conditions.append("(a.last_ns < ? OR (a.last_ns = ? AND a.trace_id < ?))")
                params.extend((page_cursor[0], page_cursor[0], page_cursor[1]))
            if session_id is not None:
                conditions.append("s.session_id=?")
                params.append(session_id)
            if agent_scope is not None:
                marks = ','.join('?' for _ in agent_scope["agent_ids"])
                conditions.append(f"s.agent_id IN ({marks})")
                params.extend(agent_scope["agent_ids"])
            if endpoint_id is not None:
                conditions.append("EXISTS (SELECT 1 FROM endpoint_traces et "
                                  "WHERE et.trace_id=a.trace_id AND et.endpoint_id=?)")
                params.append(endpoint_id)
            if conditions:
                sql += " WHERE " + " AND ".join(conditions)
            sql += " ORDER BY a.last_ns DESC,a.trace_id DESC LIMIT ?"
            params.append(batch_size)
            with self._read_db(_db) as db:
                rows = db.execute(sql, params).fetchall()
            if not rows:
                exhausted = True
                break
            for row in rows:
                activity = (row["last_ns"], row["trace_id"])
                page_cursor = activity
                if row["summary_json"] is None:
                    if self._trace_source_exists(_db,row['trace_id']):
                        missing=tuple(item['trace_id'] for item in rows if item['summary_json'] is None)
                        raise IndexNotReady(dict(ready=False,stage='Run summaries are catching up'),repair_traces=missing)
                    summary=None
                else:
                    summary = json.loads(row["summary_json"])
                if not summary:
                    continue
                if session_id is not None and summary.get("session_id") != session_id:
                    continue
                if service and service not in summary["services"]:
                    continue
                if not include_reviews and 'codex-review' in summary['services']:
                    continue
                if status and summary["status"] != status:
                    continue
                if search:
                    searchable = " ".join(str(value) for value in (
                        summary.get("trace_id"), summary.get("name"), summary.get("task"),
                        summary.get("session_id"), *summary.get("services", []),
                        *summary.get("models", []), *summary.get("activity_terms", []),
                        *summary.get("span_terms", []), *summary.get("log_terms", [])))
                    if search not in searchable.casefold():
                        continue
                selected.append((summary, activity))
                if len(selected) > int(limit):
                    break
            if len(selected) > int(limit):
                break
            if len(rows) < batch_size:
                exhausted = True
                break
        has_more = len(selected) > int(limit)
        visible = selected[:int(limit)]
        next_cursor = None
        if has_more and visible:
            ns, trace_id = visible[-1][1]
            next_cursor = base64.urlsafe_b64encode(f"{ns},{trace_id}".encode()).decode().rstrip("=")
        result = {"traces": [item[0] for item in visible],
                  "next_cursor": next_cursor, "has_more": has_more or not exhausted}
        if agent_scope is not None:
            result["agent_scope"] = agent_scope
        return result

    def traces(self, limit=100, service=None, status=None, cursor=None, session_id=None,
               search=None, endpoint_id=None):
        return self.trace_page(limit, service, status, cursor, session_id, search,
                               endpoint_id)["traces"]

    def metrics(self,*,_initial_receiver=None,_initial_file=None):
        if _initial_file is not None:
            try:
                with self._source_read('Metrics')as db:
                    db.execute('BEGIN')
                    self._require_initial_metrics(db,_initial_receiver,_initial_file)
                    return self._metrics(db)
            except (OSError,sqlite3.Error)as exc:
                raise IndexNotReady({**self.migration_status,'ready':False,'stage':'Metrics preparation proof is unavailable'})from exc
        return self._derived_snapshot(self._metrics)

    def _metrics(self, db):
        totals = {"runs": 0, "errors": 0, "incomplete": 0, "running": 0,
                  "spans": 0, "input_tokens": 0, "output_tokens": 0,
                  "cache_read_input_tokens": 0, "cache_write_input_tokens": 0,
                  "reasoning_output_tokens": 0,
                  "cache_read_input_tokens_reported": False,
                  "cache_write_input_tokens_reported": False,
                  "reasoning_output_tokens_reported": False,
                  "input_tokens_reported": False, "output_tokens_reported": False,
                  "known_cost_usd": 0.0, "unknown_cost_runs": 0,
                  "completed_tasks": 0, "costed_tasks": 0, "completed_task_cost_usd": 0.0,
                  "usage_complete": True, "status_complete": True}
        fields=('input_tokens','output_tokens','cache_read_input_tokens','cache_write_input_tokens','reasoning_output_tokens')
        selected=["COUNT(*) AS runs","COALESCE(SUM(status='ERROR'),0) AS errors","COALESCE(SUM(status='INCOMPLETE'),0) AS incomplete","COALESCE(SUM(status='RUNNING'),0) AS running","COALESCE(SUM(span_count),0) AS spans","COALESCE(MIN(usage_complete),1) AS usage_complete","COALESCE(MIN(status_complete),1) AS status_complete","SUM(known_cost_usd) AS known_cost_usd","COALESCE(SUM(NOT cost_complete),0) AS unknown_cost_runs","COALESCE(SUM(NOT active AND status NOT IN ('RUNNING','UNKNOWN')),0) AS completed_tasks","COALESCE(SUM(NOT active AND status NOT IN ('RUNNING','UNKNOWN') AND cost_complete AND known_cost_usd IS NOT NULL),0) AS costed_tasks","COALESCE(SUM(CASE WHEN NOT active AND status NOT IN ('RUNNING','UNKNOWN') AND cost_complete THEN known_cost_usd ELSE 0 END),0) AS completed_task_cost_usd"]
        for field in fields:selected.extend([f'COALESCE(SUM({field}),0) AS {field}',f'COALESCE(MAX({field}_reported),0) AS {field}_reported'])
        with self._read_db(db) as db:totals.update(dict(db.execute('SELECT '+','.join(selected)+' FROM live_run_stats_v1').fetchone()))
        for field in (*[name+'_reported' for name in fields],'usage_complete','status_complete'):totals[field]=bool(totals[field])
        if totals['known_cost_usd'] is not None:totals['known_cost_usd']=round(totals['known_cost_usd'],8)
        totals["completed_task_cost_usd"] = round(totals["completed_task_cost_usd"], 8)
        totals["average_task_cost_usd"] = (round(totals["completed_task_cost_usd"] / totals["costed_tasks"], 8)
                                           if totals["costed_tasks"] else None)
        with self._read_db(db) as db:
            totals["failed_outcomes"] = db.execute(
                "SELECT COUNT(*) FROM outcomes WHERE passed=0").fetchone()[0]
            selected=[]
            for field in fields:selected.extend([f'COALESCE(SUM(l.{field}),0) AS {field}',f'MAX(l.{field}_reported) AS {field}_reported'])
            log_usage=db.execute('SELECT '+','.join(selected)+" FROM live_log_usage_v1 l WHERE l.session_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM live_summaries_v1 s WHERE s.session_id=l.session_id)").fetchone()
            totals["log_only_input_tokens"] = int(log_usage["input_tokens"] or 0)
            totals["log_only_output_tokens"] = int(log_usage["output_tokens"] or 0)
            totals["input_tokens"] += totals["log_only_input_tokens"]
            totals["output_tokens"] += totals["log_only_output_tokens"]
            totals["input_tokens_reported"] |= bool(log_usage["input_tokens_reported"])
            totals["output_tokens_reported"] |= bool(log_usage["output_tokens_reported"])
            for field in TOKEN_BREAKDOWN_KEYS:
                totals[field] += int(log_usage[field] or 0)
                totals[f"{field}_reported"] |= bool(log_usage[f"{field}_reported"])
        totals.update({
                "logs": self._log_count(_db=db),
                "metric_points": self._metric_count(_db=db),
                "services": self._services(_db=db)}
        )
        from .storage_derived import finalize_usage
        finalize_usage(totals)
        return totals

    def _log_count(self, *, _db=None):
        with self._read_db(_db) as db:
            return db.execute("SELECT COUNT(*) FROM logs").fetchone()[0]

    def _metric_count(self, *, _db=None):
        with self._read_db(_db) as db:
            return db.execute("SELECT COUNT(*) FROM metric_points").fetchone()[0]

    def _services(self, *, _db=None):
        with self._read_db(_db) as db:
            rows = db.execute("""SELECT service FROM spans UNION
                SELECT service FROM logs UNION SELECT service FROM metric_points UNION
                SELECT service FROM progress WHERE service IS NOT NULL""").fetchall()
        return sorted(row[0] for row in rows)


def summarize_progress(trace_id, progress):
    start, end = progress[0]["time_ns"], progress[-1]["time_ns"]
    state = progress[-1].get("status") or "RUNNING"
    return {"trace_id": trace_id, "name": "agent.run", "task": None,
            "outcome": None, "steps": None, "summary": None,
            "task_outcome": {"RUNNING": "running", "OK": "completed"}.get(progress[-1].get("status"), "unknown"),
            "task_outcome_ns": end,
            "services": sorted({p["service"] for p in progress if p.get("service")}),
            "start_unix_nano": start, "end_unix_nano": end,
            "duration_ms": round((end - start) / 1e6, 3), "status": state,
            "active": state == "RUNNING",
            "span_count": 0, "input_tokens": 0, "output_tokens": 0,
            "cache_read_input_tokens": 0, "cache_write_input_tokens": 0,
            "reasoning_output_tokens": 0,
            "cache_read_input_tokens_reported": False,
            "cache_write_input_tokens_reported": False,
            "reasoning_output_tokens_reported": False,
            "input_tokens_reported": False, "output_tokens_reported": False,
            "known_cost_usd": 0.0, "cost_complete": False, "models": []}


def apply_outcome(summary, outcome):
    summary["task_id"] = outcome["task_id"]
    summary["outcome_passed"] = outcome["passed"]
    summary["task_outcome"] = "completed" if outcome["passed"] else "failed"
    summary["task_outcome_ns"] = outcome.get("ingested_ns") or summary.get("end_unix_nano") or 0
    if not outcome["passed"] and summary["status"] != "ERROR":
        summary["status"] = "FAILED"
    elif outcome["passed"] and summary["status"] == "RUNNING":
        summary["status"] = "OK"
    return summary


def summarize(spans):
    from .session_status import task_outcome
    roots = [s for s in spans if not s["parent_span_id"]]
    root = min(roots or spans, key=lambda s: s["start_unix_nano"])
    starts = [s["start_unix_nano"] for s in spans]
    ends = [s["end_unix_nano"] for s in spans]
    # Framework wrappers can repeat a child model span's usage (Google ADK's
    # call_llm -> generate_content is one example). Deduplicate usage and cost
    # independently: one wrapper may carry cost while its child carries tokens.
    span_by_id = {s["span_id"]: s for s in spans}

    def leaf_spans(candidates):
        candidate_ids = {s["span_id"] for s in candidates}
        wrappers = set()
        for span in candidates:
            parent_id = span.get("parent_span_id")
            visited = set()
            while parent_id and parent_id not in visited:
                visited.add(parent_id)
                if parent_id in candidate_ids:
                    wrappers.add(parent_id)
                parent = span_by_id.get(parent_id)
                if parent is None:
                    break
                parent_id = parent.get("parent_span_id")
        return [s for s in candidates if s["span_id"] not in wrappers]

    model_spans = [s for s in spans if s["name"] != "agent.run"]
    input_usage_spans = leaf_spans([
        s for s in model_spans
        if any(key in s["attributes"] for key in INPUT_TOKEN_KEYS)
    ])
    output_usage_spans = leaf_spans([
        s for s in model_spans
        if any(key in s["attributes"] for key in OUTPUT_TOKEN_KEYS)
    ])
    breakdown_spans = {
        field: leaf_spans([s for s in model_spans
                           if any(key in s["attributes"] for key in keys)])
        for field, keys in TOKEN_BREAKDOWN_KEYS.items()
    }
    # A wrapper may report input while its child reports only output (or vice
    # versa). Deduplicating the two directions as one bundle drops the unique
    # direction from the wrapper, so keep usage leaves independently by kind.
    usage_spans_by_id = {span["span_id"]: span
                         for span in (*input_usage_spans, *output_usage_spans)}
    usage_spans = list(usage_spans_by_id.values())
    cost_spans = leaf_spans([
        s for s in model_spans
        if any(key.startswith("llm.cost.") for key in s["attributes"])
        or "llm.cost_usd" in s["attributes"]
        or "gen_ai.usage.cost" in s["attributes"]
    ])
    def numeric(a, key):
        try:
            value = float(a[key])
            return value if math.isfinite(value) else None
        except (KeyError, TypeError, ValueError, OverflowError):
            return None
    def num(a, keys):
        for key in keys:
            if key in a:
                value = numeric(a, key)
                return value if value is not None else 0
        return 0
    def cost_info(attrs):
        for key in ("llm.cost.total", "llm.cost_usd", "gen_ai.usage.cost"):
            if key in attrs:
                value = numeric(attrs, key)
                return value, value is not None and attrs.get("llm.cost_known", True)
        component_keys = ("llm.cost.prompt", "llm.cost.completion")
        if any(key in attrs for key in component_keys):
            values = [numeric(attrs, key) for key in component_keys]
            valid = [value for value in values if value is not None]
            return (sum(valid) if valid else None,
                    len(valid) == len(component_keys) and attrs.get("llm.cost_known", True))
        return None, False
    input_tokens_reported = bool(input_usage_spans)
    output_tokens_reported = bool(output_usage_spans)
    input_tokens = sum(num(s["attributes"], INPUT_TOKEN_KEYS) for s in input_usage_spans)
    output_tokens = sum(num(s["attributes"], OUTPUT_TOKEN_KEYS) for s in output_usage_spans)
    token_breakdown_totals = {}
    for field, keys in TOKEN_BREAKDOWN_KEYS.items():
        candidates = breakdown_spans[field]
        token_breakdown_totals[field] = int(sum(num(s["attributes"], keys) for s in candidates))
        token_breakdown_totals[f"{field}_reported"] = bool(candidates)
    call_costs = [cost_info(s["attributes"]) for s in cost_spans]
    cost_complete = (bool(usage_spans) and len(call_costs) == len(usage_spans)
                     and all(complete for _, complete in call_costs))
    outcome = root["attributes"].get("agent.stopped_reason")
    waiting_for = (_waiting_for(root["attributes"]) or
                   _waiting_for(root.get("resource_attributes", {})))
    state = ("ERROR" if any(s["status"] == "ERROR" or
                            s["attributes"].get("tool.result_status") == "error" or
                            bool(s["attributes"].get("tool.error")) or
                            mcp_result_error(s["attributes"]) for s in spans) else
             "INCOMPLETE" if outcome and outcome != "completed" else
             "RUNNING" if any(s["name"] == "agent.run" and s["attributes"].get("agent.run.state") == "running" for s in spans) else "OK")
    def hierarchy_attr(key):
        for span in (root, *spans):
            value = span["attributes"].get(key) or span.get("resource_attributes", {}).get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()[:256]
        return None
    native_agent = hierarchy_attr("agent.id")
    agent_id = native_agent if native_agent and AGENT_ID.fullmatch(native_agent) else None
    if native_agent and not agent_id:
        try:
            agent_id = canonical_agent_id(
                hierarchy_attr("agent.runtime") or root["service"],
                hierarchy_attr("agent.namespace") or
                root.get("resource_attributes", {}).get("service.name") or root["service"],
                native_agent)
        except ValueError:
            agent_id = None
    return {"trace_id": root["trace_id"], "name": root["name"],
            "agent_id": agent_id,
            "agent_count": len(_recorded_activity_agents(spans)), "agent_count_complete": True,
            "agent_native_id": hierarchy_attr("agent.id"),
            "parent_agent_native_id": hierarchy_attr("agent.parent_id"),
            "agent_namespace": hierarchy_attr("agent.namespace"),
            "agent_worker_id": hierarchy_attr("agent.worker_id"),
            "relationship_kind": hierarchy_attr("agent.relationship.kind"),
            "relationship_state": hierarchy_attr("agent.relationship.state"),
            "relationship_provenance": hierarchy_attr("agent.relationship.provenance"),
            "active": any(s['name']=='agent.run' and s['attributes'].get('agent.run.state')=='running' for s in spans),
            "task": root["attributes"].get("agent.task"),
            "initial_task": root["attributes"].get("agent.session.task"),
            "waiting_for": waiting_for,
            "project": next((root.get("resource_attributes", {}).get(key)
                             for key in ("vcs.repository.name", "project.name", "repository.name")
                             if root.get("resource_attributes", {}).get(key)), None),
            "outcome": outcome, "steps": root["attributes"].get("agent.steps"),
            "summary": root["attributes"].get("agent.summary"),
            "services": sorted({s["service"] for s in spans}),
            "start_unix_nano": min(starts), "end_unix_nano": max(ends),
            "duration_ms": round((max(ends) - min(starts)) / 1e6, 3),
            "status": state,
            "task_outcome": task_outcome(root), "task_outcome_ns": root["end_unix_nano"],
            "span_count": len(spans), "input_tokens": int(input_tokens),
            "output_tokens": int(output_tokens),
            **token_breakdown_totals,
            "input_tokens_reported": input_tokens_reported,
            "output_tokens_reported": output_tokens_reported,
            "known_cost_usd": round(sum(value for value, _ in call_costs if value is not None), 8),
            "cost_complete": cost_complete,
            "models": sorted({str(model) for s in spans
                              if (model := s["attributes"].get("gen_ai.request.model") or
                                  s["attributes"].get("llm.response.model_name") or
                                  s["attributes"].get("llm.request.model_name") or
                                  s["attributes"].get("llm.model_name") or
                                  s["attributes"].get("embedding.model_name") or
                                  s["attributes"].get("llm.model")) is not None})}
