"""Bounded, redacted activity extracted from native agent session records."""
from __future__ import annotations

import json
import re
import shlex
from itertools import islice
from pathlib import Path

from .findings import _safe_text, _SENSITIVE_FIELD, _TOKEN_FIELD
from .native_json import loads
from .session_text import remember_task

CONTENT_LIMIT = 8000


def safe(value, limit=CONTENT_LIMIT):
    def clean(item, depth=0):
        if depth>=12:return '[nested payload omitted]'
        if isinstance(item,dict):
            result={str(key): '[REDACTED]' if _SENSITIVE_FIELD.search(str(key)) or _TOKEN_FIELD.search(str(key))
                else '[opaque payload omitted]' if str(key) in {'encrypted_content','signature','raw_content'} or str(key)=='data' and isinstance(child,str) and len(child)>1000
                else clean(child,depth+1) for key,child in islice(item.items(),60)}
            if len(item)>60:result['[truncated]']=f'{len(item)-60} fields omitted'
            return result
        if isinstance(item,list):
            result=[clean(child,depth+1) for child in item[:60]]
            if len(item)>60:result.append(f'[truncated: {len(item)-60} items omitted]')
            return result
        if item is None or isinstance(item,(int,float,bool)):return item
        text=_safe_text(str(item))
        return text[:2000]+('[truncated]' if len(text)>2000 else '')
    if isinstance(value,(dict,list)):
        value=json.dumps(clean(value),ensure_ascii=False,indent=2)
    text = _safe_text(value)
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    text = "".join(char for char in text if char in "\n\t" or ord(char) >= 32 and ord(char) != 127)
    return text[:limit] + ("\n[truncated]" if len(text) > limit else "")


def plaintext(content):
    if isinstance(content, str):
        return safe(content)
    if not isinstance(content, list):
        return ""
    return safe("\n".join(str(block.get("text") or "") for block in content
                         if isinstance(block, dict) and str(block.get("type") or "").casefold() in {"text", "input_text", "output_text"}))


def mcp_attributes(name):
    """Recognize qualified MCP names without guessing from ordinary tool names."""
    parts = str(name).split("__", 2)
    if len(parts) == 3 and parts[0] == "mcp" and parts[1] and parts[2]:
        return {"mcp.server.name": parts[1], "mcp.tool.name": parts[2],
                "mcp.method.name": "tools/call"}
    return {}


def mcp_failed(value):
    if isinstance(value, str):
        try:
            value = loads(value)
        except (ValueError, OverflowError, RecursionError):
            return False
    return isinstance(value,dict) and (value.get('isError') is True or value.get('is_error') is True)


def emit(session, row, stamp, domain, action, subject, detail="", result="observed", extra=None,
         *, call_id=None, turn=None):
    if not stamp:
        return None
    from .local_agents import identity
    identity_subject=subject  # Preserve existing native occurrence/seen IDs.
    if domain=='shell':
        from .operation_facts import safe_value
        subject=safe_value(subject)[0]
    attrs = {"session.id": session.session_id, "observatory.project": session.project,
             "agent.id": session.agent_id, "agent.runtime": session.runtime,
             "agent.discovery_state": session.discovery_state,
             "agent.relationship.kind": session.relationship_kind,
             "agent.relationship.state": session.relationship_state,
             "observatory.data_source": "local-session-log", "agent.activity.domain": domain,
             "observatory.operation.capture_version": 1,
             "agent.activity.action": action, "agent.activity.subject": safe(subject, 500),
             "agent.activity.result": result, "agent.activity.actor": session.runtime,
             "observatory.record_id": identity(session.source_id, row.get("ordinal") or row.get("uuid") or stamp,
                                                domain, action, str(identity_subject)[:500], *([call_id] if call_id else [])), **(extra or {})}
    if session.capture_details and not session.internal and session.task_description:
        attrs['agent.session.task'] = session.task_description
    if session.parent_agent_id:
        attrs["agent.parent_id"] = session.parent_agent_id
    payload = row.get("payload") or {}
    item = payload.get("item") or {} if isinstance(payload, dict) else {}
    span_id = None
    if isinstance(item, dict) and item.get("type") in {"CommandExecution", "FileChange", "McpToolCall", "Extension"}:
        span_id = identity(session.source_id, ("tool", item.get("id") or row.get("ordinal") or stamp), size=16)
    if call_id:
        span_id = identity(session.source_id, ("tool", call_id), size=16)
    return {"trace_id": identity(session.source_id, turn or session.turn), "span_id": span_id,
            "time_unix_nano": stamp, "service": session.service,
            "severity_number": 17 if result in {"error", "failed", "denied"} else 9,
            "severity_text": "ERROR" if result in {"error", "failed", "denied"} else "INFO",
            "event_name": "agent.activity", "body": safe(detail) if session.capture_details else "",
            "attributes": attrs, "resource_attributes": {"observatory.source_id": session.source_id,
                "observatory.capture": "local-session-log"}, "scope_name": "observatory.local_agents"}


def duration(item):
    value = item.get("duration")
    if isinstance(value, dict):
        try:
            return float(value.get("secs", 0)) * 1000 + float(value.get("nanos", 0))/1e6
        except (ValueError, TypeError):
            pass
    return None


def codex_activity(session, row, stamp):
    payload = row.get("payload") or {}
    if not isinstance(payload, dict):
        return []
    kind = row.get("type")
    event = payload.get("type")
    out = []
    if kind == "token_usage_record":
        usage = payload.get("usage") or {}
        out.append(emit(session, row, stamp, "model", "usage", session.model or "Model not reported", usage,
                        "reported", {"gen_ai.request.model": str(session.model or "unknown")}))
    elif kind == "response_item" and event in {"function_call", "custom_tool_call"}:
        name = str(payload.get("name") or "Tool")
        args = payload.get("arguments") or payload.get("input") or ""
        try:
            parsed = loads(args) if isinstance(args, str) else args
        except (ValueError, TypeError, OverflowError, RecursionError):
            parsed = {}
        # Results only need the tool name, not another retained argument payload.
        session.tool_inputs[str(payload.get("call_id") or payload.get("id"))] = (name, "", session.turn)
        subject = name
        domain = "tool"
        mcp = mcp_attributes(name)
        if mcp:
            domain, subject = "mcp", mcp["mcp.server.name"]
        elif isinstance(parsed, dict):
            command = parsed.get("cmd") or parsed.get("command")
            if command:
                domain, subject = "shell", str(command)
            elif parsed.get("url"):
                domain, subject = "browser", str(parsed["url"])
            elif parsed.get("path"):
                domain, subject = "file", str(parsed["path"])
        out.append(emit(session, row, stamp, domain, "call", subject if session.capture_details else name,
                        {"arguments": parsed or args} if mcp else args, "started", {"tool.name": name, **mcp},
                        call_id=payload.get("call_id") or payload.get("id") if mcp else None))
    elif kind == "response_item" and event in {"function_call_output", "custom_tool_call_output"}:
        key = str(payload.get("call_id") or payload.get("id"))
        pending = session.calls.get(key)
        fallback = (pending[0], "", pending[2]) if pending else ("Tool", "", session.turn)
        name, _, call_turn = session.tool_inputs.pop(key, fallback)
        mcp = mcp_attributes(name)
        output = payload.get("output") or ""
        pending = session.calls.pop(key, None) if mcp else None
        out.append(emit(session, row, stamp, "mcp" if mcp else "tool", "result", name,
                        {"result": output} if mcp else output,
                        "error" if mcp_failed(output) else "success" if mcp else "observed", mcp,
                        call_id=key if mcp else None, turn=pending[2] if pending else call_turn))
    elif kind == 'event_msg' and event in {'approval_request', 'request_user_input'}:
        # Request identities and generic labels remain available in metadata-only mode.
        out.append(emit(session, row, stamp, 'agent', event,
                        'Approval requested' if event == 'approval_request' else 'Reply requested',
                        result='waiting'))
    elif kind == "event_msg" and event in {"task_started", "task_complete", "task_aborted", "turn_aborted"}:
        action = "started" if event == "task_started" else "completed" if event == "task_complete" else "interrupted"
        detail = {"event": event, **{key: payload[key] for key in
                  ("duration_ms", "time_to_first_token_ms") if key in payload}}
        if isinstance(payload.get("reason"), str):
            # Bound the field before encoding so a long reason cannot clip the
            # surrounding JSON and make otherwise valid evidence unreadable.
            detail["reason"] = safe(payload["reason"], 1000)
        out.append(emit(session, row, stamp, "agent", action, session.project or session.runtime, detail, action))
    elif kind == "turn_context":
        # Only selected settings, never the system instructions or environment.
        settings = {key: payload[key] for key in ("model", "effort", "approval_policy", "sandbox_policy") if key in payload}
        out.append(emit(session, row, stamp, "context", "settings", session.model or "Agent settings", settings))
    elif kind == "event_msg" and event == "item_completed":
        item = payload.get("item") or {}
        if not isinstance(item, dict):
            return []
        item_type = item.get("type")
        extra = {"observatory.item_type": item_type}
        elapsed = duration(item)
        if elapsed is not None:
            extra["duration_ms"] = elapsed
        failed = str(item.get("status", "")).lower() in {"failed", "error", "declined", "denied"}
        result = "error" if failed else "success"
        if item_type == "CommandExecution":
            command = item.get("command") or []
            command = shlex.join(map(str, command)) if isinstance(command, list) else str(command)
            code = item.get("exit_code")
            if 'exit_code' in item:extra['process.exit.code']=code
            if type(code) is int:
                extra["process.exit.code"] = code
                if code:
                    result = "error"
            from .operation_facts import evidence_detail
            output=item.get('aggregated_output','')
            captured_output=safe(output,2000) if isinstance(output,str) else output
            evidence=dict(version=1,inputs=[('native.input',{'command':command,'cwd':item.get('cwd')})],
                commands=[('native.command',command)],cwd=item.get('cwd'),tool='CommandExecution',server=None,
                exits=[('native.exit_code',code)] if 'exit_code' in item else [],
                outputs=[('native.aggregated_output','output',captured_output)],
                output_clipped=isinstance(output,str) and len(output)>2000)
            extra['observatory.operation.schema']=1
            out.append(emit(session,row,stamp,'shell','execute',command if session.capture_details else 'Shell command',
                evidence_detail(evidence),result,extra))
        elif item_type == "FileChange":
            if not failed and str(item.get("status", "")).lower() not in {"completed","success","ok"}:result="unknown"
            changes = item.get("changes") or {}
            if isinstance(changes, dict):
                for path, change in list(changes.items())[:60]:
                    operation = change.get("type") or change.get("kind") or "change" if isinstance(change, dict) else "change"
                    if isinstance(operation, dict):
                        operation = next(iter(operation), "change")
                    operation = str(operation)
                    out.append(emit(session, row, stamp, "file", operation[:40], path if session.capture_details else Path(path).name,
                                    change, result, extra))
        elif item_type == "Extension":
            action = item.get("action") or {}
            name = str(action.get("type") or item.get("kind") or "activity") if isinstance(action, dict) else str(item.get("kind") or "activity")
            subject = action.get("url") or item.get("query") or name if isinstance(action, dict) else name
            out.append(emit(session, row, stamp, "browser", name, subject if session.capture_details else name,
                {"action": action, "query": item.get("query"), "results": item.get("results")}, result, extra))
        elif item_type == "McpToolCall":
            name = str(item.get("tool") or "MCP tool")
            extra["mcp.server.name"] = str(item.get("server") or "")[:128]
            extra["mcp.tool.name"] = name
            extra["mcp.method.name"] = "tools/call"
            details = {"arguments": item.get("arguments"), "result": item.get("result")}
            if isinstance(item.get("result"),dict) and item['result'].get('isError') is True:
                result = "error"
            out.append(emit(session, row, stamp, "mcp", name, str(item.get("server") or "MCP"), details, result, extra))
        elif item_type in {"UserMessage", "AgentMessage"}:
            text = "" if session.internal else plaintext(item.get("content"))
            role = "user" if item_type == "UserMessage" else "assistant"
            if role == "user" and text and session.capture_details:
                remember_task(session, item.get("content"))
            out.append(emit(session, row, stamp, "message", role,
                "Approval review" if session.internal else text.splitlines()[0][:300] if text and session.capture_details else role + " message", text,
                "observed", {"message.role": role, "message.phase": item.get("phase") or ""}))
        elif item_type in {"Reasoning", "ContextCompaction"}:
            out.append(emit(session, row, stamp, "agent", "processing" if item_type == "Reasoning" else "compaction",
                            "Model processing" if item_type == "Reasoning" else "Context compacted"))
    return [entry for entry in out if entry]


def claude_activity(session, row, stamp):
    message = row.get("message") or {}
    if not isinstance(message, dict):
        return []
    content = message.get("content") or []
    blocks = content if isinstance(content, list) else []
    out = []
    if row.get("type") == "assistant" and isinstance(message.get("usage"), dict):
        out.append(emit(session, row, stamp, "model", "usage", session.model or "Model not reported", message["usage"], "reported"))
    text = plaintext(content)
    if text and row.get("type") in {"assistant", "user"}:
        role = row["type"]
        if role == "user" and session.capture_details:
            remember_task(session, content)
        out.append(emit(session, row, stamp, "message", role, text.splitlines()[0][:300] if session.capture_details else role+" message", text))
    for block in blocks:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "tool_use":
            name, args = str(block.get("name") or "Tool"), block.get("input") or {}
            domain = "shell" if name.lower() in {"bash", "shell", "terminal"} else "file" if name.lower() in {"read", "write", "edit", "glob", "grep", "multiedit"} else "browser" if name.lower() in {"webfetch", "websearch"} else "tool"
            subject = args.get("command") or args.get("file_path") or args.get("path") or args.get("url") or args.get("query") or name if isinstance(args, dict) else name
            mcp = mcp_attributes(name)
            if mcp:
                domain, subject = "mcp", mcp["mcp.server.name"]
            session.tool_inputs[str(block.get("id"))] = (name, safe(subject, 500) if session.capture_details else "", session.turn)
            out.append(emit(session, row, stamp, domain, name, subject if session.capture_details else name,
                {"arguments": args} if mcp else args, "started", {"tool.name": name, **mcp},
                call_id=block.get("id") if mcp else None))
        elif block.get("type") == "tool_result":
            name, subject, call_turn = session.tool_inputs.pop(str(block.get("tool_use_id")), ("Tool", "Tool result", session.turn))
            mcp = mcp_attributes(name)
            pending = session.calls.pop(block.get("tool_use_id"), None)
            output = block.get("content") or ""
            out.append(emit(session, row, stamp, "mcp" if mcp else "tool", name+" result", subject if session.capture_details else name,
                {"result": output} if mcp else output, "error" if block.get("is_error") else "success", mcp,
                call_id=block.get("tool_use_id") if mcp else None, turn=pending[2] if pending else call_turn))
        elif block.get("type") == "thinking":
            out.append(emit(session, row, stamp, "agent", "processing", "Model processing"))
    if row.get("type") == "system":
        out.append(emit(session, row, stamp, "context", str(row.get("subtype") or "event"), "Session event",
                        {key:row[key] for key in ("durationMs", "messageCount", "isMeta") if key in row}))
    return [entry for entry in out if entry]


def pi_activity(session, row, stamp):
    """Extract bounded activity from Pi's append-only session records."""
    message = row.get("message") or {}
    if row.get("type") != "message" or not isinstance(message, dict):
        return []
    role = message.get("role")
    out = []
    if role == "user":
        text = plaintext(message.get("content")) if session.capture_details else ""
        if text:
            remember_task(session, message.get("content"))
        out.append(emit(session, row, stamp, "message", "user",
                        text.splitlines()[0][:300] if text else "user message", text,
                        "observed", {"message.role": "user"}, turn=session.turn))
    elif role == "assistant":
        for block in message.get("content") or []:
            if not isinstance(block, dict) or block.get("type") != "toolCall":
                continue
            call_id = str(block.get("id") or "")
            name = str(block.get("name") or "Tool")
            if not call_id:
                continue
            session.calls[call_id] = (name, stamp, session.turn)
            session.tool_inputs[call_id] = (name, "", session.turn)
            out.append(emit(session, row, stamp, "tool", "call", name,
                            block.get("arguments") if session.capture_details else "",
                            "started", {"tool.name": name}, call_id=call_id, turn=session.turn))
    elif role == "toolResult":
        call_id = str(message.get("toolCallId") or "")
        name = str(message.get("toolName") or "Tool")
        pending = session.calls.get(call_id)
        start = pending[1] if pending else stamp
        turn = pending[2] if pending else session.turn
        failed = bool(message.get("isError"))
        detail = plaintext(message.get("content")) if session.capture_details else ""
        out.append(emit(session, row, stamp, "tool", "result", name, detail,
                        "error" if failed else "success", {"tool.name": name},
                        call_id=call_id or None, turn=turn))
    if role == "assistant" and isinstance(message.get("usage"), dict):
        out.append(emit(session, row, stamp, "model", "usage", session.model or "Model not reported",
                        message["usage"], "reported", {"gen_ai.request.model": session.model or "unknown"}))
    return [entry for entry in out if entry]
